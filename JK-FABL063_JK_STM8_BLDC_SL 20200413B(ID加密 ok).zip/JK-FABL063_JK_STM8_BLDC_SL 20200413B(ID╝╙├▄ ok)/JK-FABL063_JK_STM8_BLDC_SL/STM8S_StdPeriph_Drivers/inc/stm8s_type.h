/**
  ******************************************************************************
  * @file stm8s_type.h
  * @brief This file contains all common data types.
  * @author STMicroelectronics - MCD Application Team
  * @version V1.1.0
  * @date 02/27/2009
  ******************************************************************************
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
    * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
  * @image html logo.bmp
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef STM8S_TYPE_H
#define STM8S_TYPE_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

/**
 * IO definitions
 *
 * define access restrictions to peripheral registers
 */
#define     __I     volatile const   /*!< defines 'read only' permissions     */
#define     __O     volatile         /*!< defines 'write only' permissions    */
#define     __IO    volatile         /*!< defines 'read / write' permissions  */

/*!< Signed integer types  */
typedef   signed char     int8_t;
typedef   signed short    int16_t;
typedef   signed long     int32_t;

typedef   signed long  s32;
typedef   signed short s16;
typedef   signed char  s8;

/*!< Unsigned integer types  */
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned long  uint32_t;

typedef unsigned long  u32;
typedef unsigned short u16;
typedef unsigned char  u8;


typedef signed long  const sc32;  /* Read Only */
typedef signed short const sc16;  /* Read Only */
typedef signed char  const sc8;   /* Read Only */

typedef volatile signed long  const vsc32;  /* Read Only */
typedef volatile signed short const vsc16;  /* Read Only */
typedef volatile signed char  const vsc8;   /* Read Only */

typedef unsigned long  const uc32;  /* Read Only */
typedef unsigned short const uc16;  /* Read Only */
typedef unsigned char  const uc8;   /* Read Only */

typedef volatile unsigned long  const vuc32;  /* Read Only */
typedef volatile unsigned short const vuc16;  /* Read Only */
typedef volatile unsigned char  const vuc8;   /* Read Only */

typedef volatile signed long  vs32;
typedef volatile signed short vs16;
typedef volatile signed char  vs8;

typedef volatile unsigned long  vu32;
typedef volatile unsigned short vu16;
typedef volatile unsigned char  vu8;

/*
#define TRUE          1     
#define FALSE         0
*/
typedef enum
{
  FALSE = 0,
  TRUE =  1
}
bool;

typedef enum {
  RESET = 0,
  SET = !RESET
}
FlagStatus, ITStatus, BitStatus;

typedef enum {
  DISABLE = 0,
  ENABLE = !DISABLE
}
FunctionalState;

#define IS_FUNCTIONALSTATE_OK(VALUE) ( (VALUE == ENABLE) || (VALUE == DISABLE) )

typedef enum {
  ERROR = 0,
  SUCCESS = !ERROR
}
ErrorStatus;


typedef void (* FPTR)(void);
typedef _Bool             BOOL;
typedef unsigned char     U8;
typedef unsigned int      U16;
typedef unsigned long     U32;
typedef signed char       S8;
typedef signed int        S16;
typedef signed long       S32;

typedef U8*               PU8;
typedef S8*               PS8;
typedef U16*              PU16;
typedef S16*              PS16;
typedef U32*              PU32;
typedef S32*              PS32;

typedef union  { S16 W; struct{ U8 H; U8 L; }B; } SWORD; 
typedef union  { U16 W; struct{ U8 H; U8 L; }B; } WORD;  
typedef union  { U32 DW; struct { WORD H; WORD L; } W; } DWORD;

typedef union 
{
  U8 _byte;
  struct 
  {
    U8 b0:1;
    U8 b1:1;
    U8 b2:1;
    U8 b3:1;
    U8 b4:1;
    U8 b5:1;
    U8 b6:1;
    U8 b7:1;
  } _bit;
} BYTE;

#define WU16(X)   (X.W)
#define WHSB(X)   (X.B.H)
#define WLSB(X)   (X.B.L)
#define DU32(X)   (X.DW)
#define DHSW(X)   (X.W.H.W)
#define DLSW(X)   (X.W.L.W)
#define DTSB(X)   (X.W.H.B.H)
#define DMSB(X)   (X.W.H.B.L)
#define DHSB(X)   (X.W.L.B.H)
#define DLSB(X)   (X.W.L.B.L)
#define HSBOF(X)  (((WORD*)&X)->B.H)
#define LSBOF(X)  (((WORD*)&X)->B.L)

/******************************************************************************/
/*                          Marcros definition                                																	 */
/******************************************************************************/
#define BIT0      0x01
#define BIT1      0x02
#define BIT2      0x04
#define BIT3      0x08
#define BIT4      0x10
#define BIT5      0x20
#define BIT6      0x40
#define BIT7      0x80
#define HIGH	  1
#define LOW        0
#define NULL          ( (void*)0 )   
#define LENOF(ARR)    ( (U8)(sizeof(ARR)/sizeof(ARR[0])) )
#define MOD(X,N)      ( (X) % (N) )
#define MODEX(X, N, R)  ( (R == (X) % (N)) ? TRUE : FALSE ) 
#define NIBHSB(X)     ( (X) >> 4 )
#define NIBLSB(X)     ( (X) & 0x0F )
#define BMSK(N)       ( 1U << (N) )
#define BSET(X, N)    ( (X) |= (N) )
#define BCLR(X, N)     ( (X) &= (N^-1) )
#define BCPL(X, N)     ( (X) ^= (N) )
#define BTST(X, N)     ( (X) & (N) )

                                                                       
#define U8_MAX     ((u8)255)
#define S8_MAX     ((s8)127)
#define S8_MIN     ((s8)-128)
#define U16_MAX    ((u16)65535u)
#define S16_MAX    ((s16)32767)
#define S16_MIN    ((s16)-32768)
#define U32_MAX    ((u32)4294967295uL)
#define S32_MAX    ((s32)2147483647)
#define S32_MIN    ((s32)-2147483648)

                                                                        
/*
20180719 tom
iqmath �㷨����ת��Ϊ �������㣬��������ٶ�

#define   IQ(A)         (u16) (A * 32768.0L) 
#define   IQmpy(A,B)    ((((u32)A*B))>>15) 
#define   IQdiv(A,B)    (u16)((A/B)<<15)   
*/
                                                                        
#define   IQ(A)         ((s16) ((A) * 4095.0L))  
#define   IQmpy(A,B)    ((((s32)(A)*(B)))>>12) 
#define   IQdiv(A,B)    ((s16)(((A)/(B))<<12))                                        


/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

#endif /* __STM8S_TYPE_H */

/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
