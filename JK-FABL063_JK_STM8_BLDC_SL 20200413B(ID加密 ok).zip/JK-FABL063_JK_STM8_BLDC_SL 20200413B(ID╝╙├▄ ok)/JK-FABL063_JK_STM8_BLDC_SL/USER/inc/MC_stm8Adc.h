/**
  ******************************************************************************
  * @file    \USER\inc\MC_stm8Adc.h 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief  adcͷ�ļ�
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MC_STM8ADC_H
#define MC_STM8ADC_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 
extern void ADC_Config(void);
extern void AdcGetConversionValue(void);
extern void AdcSingleScanMode(void);
extern void AdcChannelSwitchMode(void);
extern void AdcSoftMultichannelScanMode(void);

#endif /* __HD_init_H */

/************************* (C) COPYRIGHT 2018 JK ***************END OF FILE****/

