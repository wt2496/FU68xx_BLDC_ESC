/**
  ******************************************************************************
  * @file    \USER\inc\MC_stm8Timer.h  
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   ��ʱ��ͷ�ļ� 
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MC_STM8TIMER_H
#define MC_STM8TIMER_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 
extern void TIM1_Config(void);
extern void TIM2_Config(void);

#endif /* __HD_init_H */

/************************* (C) COPYRIGHT 2018 JK ***************END OF FILE****/


