/**
  ******************************************************************************
  * @file    \USER\inc\tempconstant.h 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   �м����ͷ�ļ����弰����
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/ 
#ifndef __TEMPCONSTANT_H_
#define __TEMPCONSTANT_H_ 

#include  "MC_stm8s_HWPlat_param.h"

#define LINUART                   (1)  /* for STM8AF UART3 only!*/
#define AUTOMATIC_RESYNCHRO       (0)  /* for STM8AF UART3 only!*/
#define MUTE_MODE                 (1)  /* for STM8AF UART3 only!*/

#define PWMIN_MODE                (1)
#define LIN_MODE                  (2)
/*-----------------------------------------------------------------------------*/
/*TIM1 PWM*/
#define STM8_FREQ_MHZ             (HSE_VALUE/1000000) 
#define PWMDIV                    (32767/PWMARR)              
#define PWM_PRESCALER             (PWM_FREQUENCY/1000)      

/*-----------------------------------------------------------------------------*/
#define PWM_PERIOD              (U16)((STM8_FREQ_MHZ*(U32)1000000)/PWM_FREQUENCY) / 2
#define PWM_DEAD_CNT            (U8)(STM8_FREQ_MHZ*PWM_DEAD_TIME)
#define PWM_CMP_CCR4            (U16)((U32)PWM_CC4_PERCENT*PWM_PERIOD/100)
#define PWM_MAX_VALUE           (U16)((U32)PWM_MAX_PERCENT*PWM_PERIOD/100)
#define PWM_MIN_VALUE           (U16)((U32)PWM_MIN_PERCENT*PWM_PERIOD/100)
#define RPD_PWM_MAX_VALUE       (U16)PWM_PERIOD

#define T_MOTOR_VS_MIN          (u16)((U32)PWM_PERIOD*MOTOR_VS_MIN>>15)

#define XFILTER_NUM             (PWM_FREQUENCY/100)  /*PWMIN �������ֵ */
#define ONOFFFILTER_NUM         (10)

#define E360_PEIOD_MAX         ((u32)PWM_FREQUENCY*60/1200)  /*��Сת��1�Լ� 1200rpm*/
#define E360_PEIOD_MIN         ((u32)PWM_FREQUENCY*60/20000)  /*���ת��1�Լ� 20000rpm*/

#define NOR_RUN_TIM            (1000) /*����NOR �೤ʱ�䣬������ϱ�־λ*/
/*-----------------------------------------------------------------------------
ADC + BEMF���
*/
#define VRiseSeta               (1.0)      
#define VFallSeta               (0.5)      
#define HW_ADC_VREF             (5.0)
#define VDC_OFFSETT_SET         (-10)         /*BEMF ���Ե��ƶ��� +���ƣ�-����*/
#define VDC_OFFSETT_MAX         (300)        /*û��ʹ��*/
#define START_VDC_RISE_OFFSETT_SET   (10)   /*����ƫ�ã����������ƶ�*/
#define START_VDC_FALL_OFFSETT_SET   (-10)    /*����ƫ�ã��½������ƶ�*/
/*
Drv.AdcMeas.VdcMeasGain = (float)(RV_BUS_1+RV_BUS_2)/(float)RV_BUS_2;
VGain = (float)(RV_BUS_1+RV_BUS_2)/(float)RV_BUS_2;
*/
#define  V_GAIN                  (float)((float)(RV_BUS_1+RV_BUS_2)/(float)RV_BUS_2)
#define  VDCMEASEGAIN            (float)(HW_ADC_VREF*(V_GAIN)/0x3FF)                  /* 0X7FFF -> 3FF  Q15->Q10  */

#define  MECAS_DCVOLTAGE           (s16)(DCVOLTAGE/VDCMEASEGAIN)   
#define  MECAS_OVERVOLTAGE         (s16)(OVERVOLTAGE/VDCMEASEGAIN)
#define  MECAS_OVREVOLTAGE_RE      (s16)(OVREVOLTAGE_ER/VDCMEASEGAIN) 

#define  MECAS_UNDERVOLTAGE        (s16)(UNDERVOLTAGE/VDCMEASEGAIN)
#define  MECAS_UNRERVOLTAGE_RE     (s16)(UNDERVOLTAGE_ER/VDCMEASEGAIN)

#define  MECAS_DC_DERATED          (s16)(DC_DERATED/VDCMEASEGAIN)
/*-----------------------------------------------------------------------------
IGain = ((float)RI_BUS_1/(float)RI_BUS_2)+ 1;      
Drv.AdcMeas.IBusMeasGain = HW_ADC_VREF/(Rs*0x7FFF*IGain);
*/
//#define  I_GAIN                  (35.0)
#define  I_GAIN                (((float)RI_BUS_1/(float)RI_BUS_2)+ 1)  

#define  IBUSMEASGAIN             (HW_ADC_VREF/(Rs*0x3FF*I_GAIN))   /* 0X7FFF */ 

#define  MECASEOVERCURRENT        (s16)(OVERCURRENT/IBUSMEASGAIN)
#define  MECASECURRENTLIMITMAXREF (s16)(CURRENT_LIMIT_MAXREF/IBUSMEASGAIN)

/*-----------------------------------------------------------------------------
LL99ASC �¶ȼ��㹫ʽ  
Th = (3.7-Vt*5.0/1024)*1000/7.85+25  ADC�ֱ���->0.622���϶�
*/
//#define  TH_A       (float)(5.0*1000/1024/7.85)          /* -0.622 */
//#define  TH_B       (float)(3.7*1000/7.85+25)            /* 496.3 */
//
//#define  OH1MEAS       (u16)((TH_B - OH1_TH)/TH_A)        /*100->335*/
//#define  OH2MEAS       (u16)((TH_B - OH2_TH)/TH_A)       
//#define  OH3MEAS       (u16)((TH_B - OH3_TH)/TH_A)   

/*
TOM ���
TLE7184�¶ȼ���:  P34
Vatrt = (1.32+1.65)/2 = 1.485
Katrt = (4.57+5.20)/2 = 4.885

Th = (Vt - 1.485)*1000/4.885 + 25;

#define  TH_A       1           //0.999 
#define  TH_B       279         // 279
*/
#define  TH_A       (float)(5.0*1000/1024/4.885)           //0.999 
#define  TH_B       (float)(-1.485*1000/4.885+25)           // 279
#define  OH1MEAS    (u16)((OH1_TH - TH_B)/TH_A)        /*100->335*/
#define  OH2MEAS    (u16)((OH2_TH - TH_B)/TH_A)       
#define  OH3MEAS    (u16)((OH3_TH - TH_B)/TH_A) 
#define  OH4MEAS    (u16)((OH4_TH - TH_B)/TH_A) 
#define  OH5MEAS    (u16)((OH5_TH - TH_B)/TH_A) 

#define  OH7184_WARNE_MEAS (u16)((OH7184_WARN_TH - TH_B)/TH_A)  

/*-----------------------------------------------------------------------------
�ٶȸ��� ����������
Y = aX + b��
Y = (SPEED_MIN_SEF_TEMP,SPEED_MXN_SEF_TEMP)
X = (0.55,0.95) = 
*/

#define SPEED_MIN_SEF_TEMP      IQ(SPEED_MIN_SEF/BASE_SPEED) /* *  */
#define SPEED_MAX_SEF_TEMP      IQ(SPEED_MAX_SEF/BASE_SPEED) /* * */

#define SPEED_INPUT_REF_MIN    (IQ(0.15))
#define SPEED_INPUT_REF_MAX    (IQ(0.85))
#define SPEED_OUTPUT_REF_MIN   (IQ(600.0/BASE_SPEED))
#define SPEED_OUTPUT_REF_MAX   (IQ(2400.0/BASE_SPEED)) //(SPEED_MAX_SEF_TEMP)
#define SPEED_SCALER_A         (u16)((((u32)(SPEED_OUTPUT_REF_MAX - SPEED_OUTPUT_REF_MIN)*4095))/(SPEED_INPUT_REF_MAX - SPEED_INPUT_REF_MIN))
#define SPEED_SCALER_B         (s16)((s16)SPEED_OUTPUT_REF_MAX - (s16)(((u32)SPEED_SCALER_A*SPEED_INPUT_REF_MAX)/4095))



/*-----------------------------------------------------------------------------
�ٶȼ���
Drv.speed.SpeedScaler = _IQ((60*(float)750000)/(6*(float)Ctl.Motor.PolePairs*Ctl.Motor.BaseSpeed)); 

#define SPEEDSCALER  (_IQ((60*(float)TIM2_FREQ)/(6*(float)POLE_PAIR*BASE_SPEED)))

ע�⣺ʹ��TIM2������ʱ�䣬���һ�������ڵ�ʱ�䣬������Ƕ�

����ֵ����
tSpeed = SPEEDSCALER/EventPeriod;

ʵ��ת�ټ���
tSpeedRpm = tSpeed*BaseRpm��

����EventPeriod = 12374  SpeedScaler = 14742000  POLE_PAIR = 5 BASE_SPEED = 5000
    -> Speed = 1191  SpeedRpm = 1453rpm

24000000	16	1500000 	0.667us	        43.690ms 
24000000	32	1500000	        1.333us	        87.38ms 
24000000	64	 375000	        2.667us	        174.76ms  
24000000	128	 187500	        5.332us	        533.2ms  
*/
#define TIM2_PRESCALER         (TIM2_PRESCALER_128)
#define TIM2_FREQ              (HSE_VALUE /128)    /*(HSE_VALUE /(2^TIM2_PRESCALER_16))   24/64 = 1.5mHz */
#define SPEEDSCALER            (((60*(float)TIM2_FREQ)/((float)POLE_PAIR*BASE_SPEED))*4095)
#define SL_RUN_STB1_CON        (u16)(SL_RUN_STB1*TIM2_FREQ/1000.0) 
#define SPEEDSCALER1           (((60*(float)PWM_FREQUENCY)/((float)POLE_PAIR*BASE_SPEED))*4095)


#define UH_GPIO_ON()      BCLR(UH_ODR, (u8)UH_BIT) /* �͵�ƽ��Ч */
#define UH_GPIO_OFF()     BSET(UH_ODR, (u8)UH_BIT) 
#define UL_GPIO_ON()      BSET(UL_ODR, (u8)UL_BIT)
#define UL_GPIO_OFF()     BCLR(UL_ODR, (u8)UL_BIT)
  
#define VH_GPIO_ON()      BCLR(VH_ODR, (u8)VH_BIT) 
#define VH_GPIO_OFF()     BSET(VH_ODR, (u8)VH_BIT) 
#define VL_GPIO_ON()      BSET(VL_ODR, (u8)VL_BIT)
#define VL_GPIO_OFF()     BCLR(VL_ODR, (u8)VL_BIT)
  
#define WH_GPIO_ON()      BCLR(WH_ODR, (u8)WH_BIT) 
#define WH_GPIO_OFF()     BSET(WH_ODR, (u8)WH_BIT) 
#define WL_GPIO_ON()      BSET(WL_ODR, (u8)WL_BIT)
#define WL_GPIO_OFF()     BCLR(WL_ODR, (u8)WL_BIT) 

#define UVWL_GPIO_OFF();  GPIOD->ODR &= ~((u8)UL_BIT|(u8)VL_BIT|(u8)WL_BIT); /*�����¹�ͬʱ�رա� PD3  PD4  PD7 0x8C*/
#define UVWL_GPIO_ON();   GPIOD->ODR |=  ((u8)UL_BIT|(u8)VL_BIT|(u8)WL_BIT); /*�����¹�ͬʱ�򿪡� PD3  PD4  PD7->0x8C*/
/* Three phase PWM control configuration port/pin  */

#define UH_PWM_ON()       BSET(TIM1->CCER1, BIT0) /*ʹ�������Ч��ƽ*/
#define VH_PWM_ON()       BSET(TIM1->CCER1, BIT4)
#define WH_PWM_ON()       BSET(TIM1->CCER2, BIT0)

#define UH_PWM_OFF()      BCLR(TIM1->CCER1, BIT0) /*ʧ�������Ч��ƽ*/
#define VH_PWM_OFF()      BCLR(TIM1->CCER1, BIT4)
#define WH_PWM_OFF()      BCLR(TIM1->CCER2, BIT0) 

#define UVWH_PWM_OFF();	   {UH_PWM_OFF();VH_PWM_OFF();WH_PWM_OFF();}

/*-----------------------------------------------------------------------------*/
#define BREAK_VALUE         IQ(1.0)         /*ɲ��ǿ��*/
#define FREE_DOWN           ((s8)1)              
#define SLOWING_DOWN        ((s8)2)              
#define BREAK_DOWN          ((s8)3)              

#define NODIR               (0)               
#define CW                  ((s8)1)                   
#define CCW                 ((s8)2)              

/*-----------------------------------------------------------------------------*/
#define ACTIVE_HIGH 1
#define ACTIVE_LOW 0
#define ACTIVE 1
#define INACTIVE 0

#define PWM_U_HIGH_SIDE_POLARITY        ACTIVE_LOW
#define PWM_U_LOW_SIDE_POLARITY         ACTIVE_HIGH
#define PWM_U_HIGH_SIDE_IDLE_STATE      INACTIVE
#define PWM_U_LOW_SIDE_IDLE_STATE       INACTIVE

#define PWM_V_HIGH_SIDE_POLARITY        ACTIVE_LOW
#define PWM_V_LOW_SIDE_POLARITY         ACTIVE_HIGH
#define PWM_V_HIGH_SIDE_IDLE_STATE      INACTIVE
#define PWM_V_LOW_SIDE_IDLE_STATE       INACTIVE

#define PWM_W_HIGH_SIDE_POLARITY        ACTIVE_LOW
#define PWM_W_LOW_SIDE_POLARITY         ACTIVE_HIGH
#define PWM_W_HIGH_SIDE_IDLE_STATE      INACTIVE
#define PWM_W_LOW_SIDE_IDLE_STATE       INACTIVE 



#ifdef ETR_INPUT
	#define OCxCE_ENABLE BIT7
#else
	#define OCxCE_ENABLE 0
#endif

/*select PWM mode 1, OC1 preload enabled, OCxCE enabled.*/
#define CCMR_PWM (OCxCE_ENABLE|BIT6|BIT5|BIT3)

/*select PWM mode 2, OC1 preload enabled, OCxCE enabled. Low Side  */
#define CCMR_PWM_LS (OCxCE_ENABLE|BIT6|BIT5|BIT3)

/*select OCREF - Forced Inactive, OC1 preload enabled (LS Off, HS On) X_COMP mode  */
#define CCMR_LOWSIDE (BIT6|BIT3)

/*select OCREF - Forced Active, OC1 preload enabled (LS ON, HS Off) X_COMP mode    */
#define CCMR_HIGHSIDE (BIT6|BIT4|BIT3)

#if (PWM_U_LOW_SIDE_POLARITY == ACTIVE_LOW)
	#define PWM_POL_LS_A BIT3
#else
	#define PWM_POL_LS_A 0
#endif
#if (PWM_U_HIGH_SIDE_POLARITY == ACTIVE_LOW)
	#define PWM_POL_HS_A BIT1
#else
	#define PWM_POL_HS_A 0
#endif
#define PWM_POL_A  PWM_POL_LS_A|PWM_POL_HS_A

#if (PWM_V_LOW_SIDE_POLARITY == ACTIVE_LOW)
	#define PWM_POL_LS_B BIT7
#else
	#define PWM_POL_LS_B 0
#endif
#if (PWM_V_HIGH_SIDE_POLARITY == ACTIVE_LOW)
	#define PWM_POL_HS_B BIT5
#else
	#define PWM_POL_HS_B 0
#endif
#define PWM_POL_B PWM_POL_LS_B|PWM_POL_HS_B

#if (PWM_W_LOW_SIDE_POLARITY == ACTIVE_LOW)
	#define PWM_POL_LS_C BIT3
#else
	#define PWM_POL_LS_C 0
#endif
#if (PWM_W_HIGH_SIDE_POLARITY == ACTIVE_LOW)
	#define PWM_POL_HS_C BIT1
#else
	#define PWM_POL_HS_C 0
#endif
#define PWM_POL_C PWM_POL_LS_C|PWM_POL_HS_C

#define A_ON  (BIT0|PWM_POL_A)    /* PWM mode on High Side */
#define A_ON_LS  (BIT2|PWM_POL_A) /* PWM mode on Low Side  */
#ifdef LS_GPIO_CONTROL
	#define A_COMP (PWM_POL_A)
#else
	#define A_COMP (BIT2|BIT0|PWM_POL_A)
#endif

#define A_OFF   PWM_POL_A

#define B_ON (BIT4|PWM_POL_B)	 /* PWM mode on High Side */
#define B_ON_LS (BIT6|PWM_POL_B) /* PWM mode on Low Side  */
#ifdef LS_GPIO_CONTROL
	#define B_COMP (PWM_POL_B)
#else
	#define B_COMP (BIT6|BIT4|PWM_POL_B)
#endif

#define B_OFF PWM_POL_B

#define C_ON     (BIT4|BIT0|PWM_POL_C) /* PWM mode on High Side */
#define C_ON_LS (BIT4|BIT2|PWM_POL_C)  /*PWM mode on Low Side   */
#ifdef LS_GPIO_CONTROL
	#define C_COMP (BIT4|PWM_POL_C)
#else
	#define C_COMP (BIT4|BIT2|BIT0|PWM_POL_C)
#endif

#define C_OFF (BIT4|PWM_POL_C)

/*BRK settings*/
#define DEV_BKIN TIM1_BREAK_ENABLE

#define DEV_BKIN_POLARITY  TIM1_BREAKPOLARITY_HIGH

#endif

