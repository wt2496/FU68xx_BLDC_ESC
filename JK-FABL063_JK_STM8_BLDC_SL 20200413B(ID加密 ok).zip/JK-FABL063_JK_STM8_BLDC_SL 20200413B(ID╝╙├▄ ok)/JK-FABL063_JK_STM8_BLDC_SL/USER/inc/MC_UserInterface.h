/**
  ******************************************************************************
  * @file    \USER\inc\MC_UserInterface.h  
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   �˻�����ͷ�ļ� 
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MC_USERINTERFACE_H
#define MC_USERINTERFACE_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

/** \defgroup Uaer_Interface_data  �˻����������ݽṹ 
 *  @{
 */

/**
* \struct Uibit_TypeDef
*  bit
* \note 
*/  
typedef struct 
 { 
  u8 START:2;        
  u8 FR:2;                  
  u8 RSV3:1;         
  u8 RSV2:1; 
  u8 RSV1:1; 
 }Uibit_TypeDef;

/**
* \struct PWMIN_TypeDef
*  PWMIN�������
* \note 
*/  
typedef struct
  { 
    u8 Pulse;
    u8 H_Cur;
    u8 L_Cur;
    u8 H_Per;
    u8 L_Per;  
    u8 L_Avg; 
    u8 Period;
    u16 L_Sum;   
    
    s8  LostSignalFlag;       /*!< PWMIN ��ʧ��־  */ 
    s8  LostSignalTimCunter;  /*!< PWMIN ��ʧ��ʱ��  */ 
    s8  SignalTimCunter;      /*!< PWMIN ��λ��ʱ��  */     
    
  }PWMIN_TypeDef;

/**
* \struct FB_TypeDef
*  PWMIN�������
* \note 
*/  
typedef struct
  {     
    s8  LostSignalFlag;       /*!< PWMIN ��ʧ��־  */ 
    s8  LostSignalTimCunter;  /*!< PWMIN ��ʧ��ʱ��  */ 
    s8  SignalTimCunter;      /*!< PWMIN ��λ��ʱ��  */     
    
  }FB_TypeDef;

/**
* \struct  Ui_TypeDef
*  UI�����
* \note 
*/  
typedef struct
  {
    Uibit_TypeDef  flg;       /*!< ��־  */ 
    PWMIN_TypeDef Pwmin;      /*!< PWMIN ����  */ 
    FB_TypeDef Fb;            /*!< Fb ����  */ 
    s8  OnOffFilterCounter;     /*!< ��ͣ�˲���ʱ��  */ 
    u8  FaultLedNumCunter;    /*!< ���ϱ���  */        
    u16 FaultLedTimCunter;    /*!< ���ϱ���  */  
    
    s8  KLPwmFeedbackFlag;
    s16 KLPwmPCT3Counter;
    s16 KLPwmPCT97Counter;    
  }Ui_TypeDef;

extern Ui_TypeDef  Ui;  
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 
extern void Ui_Function(void) ;
extern void APP_PwminDetection(void);

/** @}*/

#endif /* __HD_init_H */

/************************* (C) COPYRIGHT 2018 JK ***************END OF FILE****/