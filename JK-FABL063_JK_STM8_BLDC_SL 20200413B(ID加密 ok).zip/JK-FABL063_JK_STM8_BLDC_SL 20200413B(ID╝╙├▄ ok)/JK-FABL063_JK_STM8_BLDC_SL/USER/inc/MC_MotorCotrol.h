/**
  ******************************************************************************
  * @file    \USER\inc\MC_MotorCotrol.h 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   ������Ʋ�ͷ�ļ�
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MC_MOTORCOTROL_LAYER_H
#define MC_MOTORCOTROL_LAYER_H

/* Includes ------------------------------------------------------------------*/
#include "stm8s_type.h"
/* Exported types ------------------------------------------------------------*/


/** \defgroup Motor_Control_data ������Ʋ����ݽṹ  
 *  @{
 */


/**
* \enum Status_TypeDef
*  ϵͳ״̬��
* \note 
*/
typedef enum
{ 
  MOTOR_NONE       = 0,  /*!<  NONE*/  
  MOTOR_INIT       = 1,  /*!<  ��ʼ��״̬*/  
  MOTOR_STOP       = 2,  /*!<  ͣ��״̬*/  
  MOTOR_READY      = 3,  /*!<  ׼��״̬*/  
  MOTOR_PRECHARGE  = 4,  /*!<  ���״̬*/   
  MOTOR_ALIGNMENGT = 5,  /*!<  ��λ״̬*/  
  MOTOR_OPENLOOP   = 6,  /*!<  ����״̬*/   
  MOTOR_NORMAL     = 7,  /*!<  NOR״̬*/ 
  MOTOR_FAILURE    = 8   /*!<  ����״̬*/  
}Status_TypeDef;

/**
* \enum ErrorCode_TypeDef
*  ϵͳ���ϴ���
* \note 
*/
typedef enum            
{ 
  NONE      = 0,          /*!< 0           */
  E_FAIL    = 1,          /*!< 1 Ӳ������  */
  E_OC      = 2,          /*!< 2 ��������  */
  E_OL      = 3,          /*!< 3 ���ع���  */
  E_OV      = 4,          /*!< 4 ��ѹ����  */
  E_UV      = 5,          /*!< 5 Ƿѹ����  */

  E_STA1    = 7,          /*!< 7 ��hall������ʱ Start Over Time */
  E_STA2    = 8,          /*!< 8 ʧ��1     */
  E_STB1    = 9,          /*!< 9 ʧ��2     */
  E_STB2    = 10,         /*!< 10 ʧ��3    */
  E_STB3    = 11,         /*!< 11 ʧ��3    */
  
  E_HALL    = 12,         /*!< 12 hall���� */
  E_OH1     = 13,         /*!< 13 ���¹��� */
  E_OH2     = 14,         /*!< 14 ���¹��� */
   
  E_ADC     = 17,         /*!< 17 ADC�Լ���� */
  E_ADC_V   = 18,         /*!< 18 ADC��ѹ�Լ���� */
  E_ADC_T   = 19,         /*!< 19 ADC�����Լ���� */
  
  E_8174    = 20,
  E_IPD     = 21,

	
}ErrorCode_TypeDef;
         
/**
* \enum L99ErrorCode_TypeDef
*  ϵͳ���ϴ���
* \note 
*/
typedef enum   
{
  E_L99NONE   = 0, /*!< 0  */  
  E_L99CHARGE = 1, /*!< charge pump  */ 
  E_L99SPI    = 2, /*!< SPI  */ 
  E_L99VDD5   = 3, /*!< VDD5  */ 
  E_L99OT     = 4, /*!< OVER temp  */ 
  E_L99VS     = 5, /*!< VS VSREG VSMS  */     
  E_L99OC     = 6, /*!< OVER C  */ 
  E_L99DSOV   = 7, /*!< DS OV  */ 
  
}L99ErrorCode_TypeDef;


/**
* \struct Uibit_TypeDef
*  bit
* \note 
*/   
// typedef struct 
// { 
//  u32 E_FAIL:1;        
//  u32 E_OC  :1;                  
//  u32 E_OL:1;         
//  u32 E_OV:1; 
//  u32 E_UV:1; 
//  u32 E_STA1:1; 
//  u32 E_STA2:1; 
//  u32 E_STB1:1;
//  
//  u32 E_STB2 :1;        
//  u32 E_STB3 :1;                  
//  u32 E_HALL:1;         
//  u32 E_OH1:1; 
//  u32 E_OH2:1; 
//  u32 E_ADC:1; 
//  u32 E_ADC_V:1; 
//  u32 E_L99:1;
// 
//  u32 E_L99CHARGE :1;   
//  u32 E_L99SPI :1; 
//  u32 E_L99VDD5 :1;
//  u32 E_L99OT :1;
//  u32 E_L99VS :1;
//  u32 E_L99OC :1;
//  u32 E_L99DSOV :1;
//  u32 RSV9 :1;
//  
//  u32 RSV1 :1;
//  u32 RSV2 :1;  
//  u32 RSV3 :1;  
//  u32 RSV4 :1;   
//  u32 RSV5 :1;  
//  u32 RSV6 :1;  
//  u32 RSV7 :1;  
//  u32 RSV8 :1;   
// }Codebit_TypeDef;
// 
/*
* \struct Error_TypeDef
*  L99���ϴ���
* \note 
*/
typedef struct 
{ 
   ErrorCode_TypeDef Code;   /*defect code */
//   L99ErrorCode_TypeDef gL99ErrorInformation; 
//   u8 gL99ErrorCode;
}Error_TypeDef;

/**
* \struct  E_MESSSAGE_TypeDef
*  ���ϴ洢
* \note 
*/
typedef struct 
{ 
  u8  ErrorF;              /*!<  */
  Error_TypeDef SysError;  /*!<  */
  Status_TypeDef State;    /*!<  */
  u8  FR;
  u16 SpeedRef;
  u16 SpeedFdb;
  u16 ImeasBus;
  u16 VdcMeas;    
  u16 Therm;
  u16 Duty;
  s16 Ibus;
  float Vdc;
} E_MESSSAGE_TypeDef ;

typedef struct
{
  u8 Group_0_1;   //���ϱ�־
  u8 Group_0_2;   //���ϴ���
} EEROM_TypeDef;
/**
* \struct Stall_TypeDef
* ת�ٸ��ٱ���
* \note 
*/
typedef struct    
{ 
  u16  WaitReatartNms;   
  u16  u16NormalRunms;   
  u8   u8Num;            
  u8   u8FL;             
}Stall_TypeDef;  

/**
* \struct Alig_TypeDef
*  ��λ����
* \note 
*/  
typedef struct 
{  
  s16 duty1;
  s16 duty2;
  u16 timNms;
  u16 TimCount;
}Alig_TypeDef;

/**
* \struct Ramp_TypeDef
*  PAMP״̬����
* \note 
*/  
typedef struct 
{ 
  u8    ForceComTick;  
  s16   ForceComTimCounter;     /*!< ����ʱ���ʱ��  */
  s16   ForceComTimAccT;     
  s16   ForceComTimCurT;         /*!< ����ʱ��    Force */
  s16   ForceComTimTarT;         /*!< ����ʱ��    Force */  
  s16   ForceComTimAcc;     
  s16   ForceComTimCur;         /*!< ����ʱ��    Force */
  s16   ForceComTimTar;         /*!< ����ʱ��    Force */  
  u16   ForceComDutyCur;        /*!< ����ռ�ձ�        */
  float ForceComDutyGain;
  
  s16   DutyCur;           /*!< RAMP_DUTY */
  s16   ComCounter;          /*!< ��������� */
  u8    ComNumber;         /*!< �������*/
  u16   MaskTime;          /*!< ��������ʱ��*/
  
  u8  StartRiseFallNumA;
  u8  StartMaskComNumA;       /*!< �����ȴ� ����ʱ��   */  
  u8  StartABSwitchNum;     
  u8  StartRiseFallNumB;
  u8  StartMaskComNumB;       /*!< �����ȴ� ����ʱ��   */    
  
  s8  BemfTureCnt;      /*!< ��ȷ�����������  */
  s8  BemfTureNum;      /*!< ��������ȷ����    */  
  u8  BemfErrCnt;       /*!< �����ƴ��������  */
  u8  BemfErrNum;
  
  s8  FailCnt;  
  
  
}Ramp_TypeDef;

/**
* \struct Nor_TypeDef
* 
* \note 
*/   
typedef struct 
{ 
  u16 ComCounter;
}Nor_TypeDef;


/**
* \struct Fail_TypeDef
* 
* \note 
*/   
typedef struct 
{ 
  u8 Sta1RestartNum;
  u8 OHLevel;
}Fail_TypeDef;

/**
* \enum bemfS_TypeDef
*  BEMF״̬��
* \note 
*/  
typedef enum
{ 
  BEMF_DZ_NONE     = 0,   
  BEMF_ZC_W        = 1,   /*!<  ZERO CROSS WAIT  */
  BEMF_ZC_D        = 2,   /*!<  ZERO CROSS DONE  */
  BEMF_C3_W        = 3,   /*!<  C3 WAIT          */
  BEMF_C3_D        = 4,   /*!<  C3 DONE --       */
  BEMF_C2_W        = 5,   /*!<  C2 WAIT          */
  BEMF_C2_D        = 6,   /*!<  C2 DONE --       */
  BEMF_DZ_W        = 7,   /*!<  DZ WAIT          */
  BEMF_DZ_D       = 8,   /*!<  DZ DONE1         */
  
  BEMF_CC2_W       = 12,  /*!< ��BEMF���        */
  BEMF_CC3_W       = 13,  /*!< ��BEMF���        */
  
}bemfS_TypeDef;

/**
* \struct BEMF_TypeDef
*  ��������ر���
* \note 
*/  
typedef struct
{
  u16 AngleCmpCounter;   /*!<   */   
  u16 E360CounterCur;    /*!<   */ 
  u16 E360CounterPre;    /*!<   */ 
  
  u16 E360CounterSum;    /*!<   */ 
  u16 E360CounterAvg;    /*!<   */ 
                          
  u8 E60CounterCur;      /*!<   */
  u8 E60CounterPre;      /*!<   */

  u8 Angle_7;  
  u8 Angle_15;
  u8 Angle_22;  
  u8 Angle_30; 
  u8 Angle_60;
  u8 Angle_60_R;
  
  u8 AngleCmpNum;
  
  u8  C3ComNumTar;   
  u8  C3ComNumCur;  
  u8  C3ComNumCur_L;   
  u8  C3Step11ComNumCur; 
  u8  C2ComNumTar;   
  u8  C2ComNumCur;  
  u8  C2ComNumCur_L;   
  
  u8  Angle_C2;
  u8  Angle_C3;

  u8 DzNumCounter;
  s8  SingleBemfDetectionStepCur ;
  s8  SingleBemfDetectionStepPre ;
  s8  SingleBemfDetectionStepNex ;
  
  u8  RiseFallFlag;     /*!< BEMF �� or BEMF ��  */
  s8  RiseFallCounter;  
  s8  RiseFallNum;
  u8  MaskComNum;       /*!< �����ȴ� ����ʱ��   */
  
  s16 StartVdcBemfOffsetCur;
  s16 StartVdcBemfOffsetCurRise;
  s16 StartVdcBemfOffsetCurFall;  

  bemfS_TypeDef Status;
  
  /*ת�ӳ�ʼλ�ü�� */
  u8  DetectDirectionStepCounter; 
  u8  DetectDirectionVtim;
  u16 DetectDirectionCounterCur;   
  s8  DetectDirectionArrayCur;
  s8  DetectDirectionArrayPre;
  s8  DetectDirectionSum;
  s8  DetectDirectionFR;
}BEMF_TypeDef; 

/**
* \struct VTim_TypeDef
* ���ⶨʱ������
* \note 
*/  
typedef struct
{
  u8  Tick100msPtr;
  u8  Tick1sPtr;          /*!<  100ms��ʱ�� */
  u8  Tick1minPtr;          /*!<  100ms��ʱ�� */
}RTC_TypeDef;

typedef struct
{
  u16 gIsrTicker;          /*!< ϵͳ Tick */ 
  u8  g1msTicker;          /*!< 1ms Tick  */
  u8  counterCurrent;      /*!< ��������ʱ��  */
  u8  counterSpeed ;       /*!< �ٶȻ���ʱ��  */
  u8  counterSpeedPro ;       /*!< �ٶȻ���ʱ��  */
  
  u8  Ui100msPtr;          /*!<  100ms��ʱ�� */
  u8  FG_1msCounter;       /*!<  FG */
  u16 FB_1msCounter;
  u8  BrakeNum;
  u16 BrakewaitNms;        /*!<   */
  u16 PowerOnNms;          /*!<  �ϵ�ȴ���ʱ�� */
  u16 NormalTimCounter;    /*!<   Nor״̬��ʱ��*/
  u16 FailureTimCounter;    /*!<   Nor״̬��ʱ��*/
  u16 SensorlessStartTimCounter;/*!<   */  
  
  u16 OnOffTimCounter;     /*!<   */
  u16 FaultCunter;         /*!<   */
  
  s8  OCnms;               /*!<   */
  u16 UVnms;               /*!<   */
  u16 OVnms;               /*!<   */
  u16 Nonms;               /*!<   */

  u16 STA2TimCounter;     /*!<   */
  u16 STB1TimCounter;     /*!<   */     
  u16 STB2nms;          
  
  s16 OH1nms;            /*!<   */
  s16 OH2nms;            /*!<   */ 
  s16 OH3nms;            /*!<   */   
  s16 OH4nms;            /*!<   */   
  s16 OH5nms;            /*!<   */  
  
  s16 OH7184Warnnms;     /*!<   */     
  s16 OH7184ErrRstnms;     /*!<   */    
  
  s16 OH1REnms;          /*!<   */
  u16 Tle7184SleepTimCounter;    

  u16 STRestartCounter;  /*!<   */ 
  u16 STRestartTim;      /*!<   */ 

  u16 MainLoopCounter;    /*!<   */
  u16 MainLoopTim;        /*!<   */
  
  RTC_TypeDef RTC;       /*!< ����ʵʱʱ��  */
 
}VTim_TypeDef;  
  
/**
* \struct spd_TypeDef
*  �ٶȿ�����ر���
* \note 
*/  
typedef struct
{ 
  u8  SlowingDownFlag;  /*!<   */
  u8  RampCounter;      /*!<   */
  s8  CmdRunDirection;
  s8  CmdRunCwfilter;
  s8  CmdRunCCwfilter;
  s8  CmdRun0filter;
  u16 CwCCwSwitchNms;        /*!<   */  
  
  u8  LimitFlag;        /*!<   */
  u16 Vtim100ms;        /*!<   */
  s16 UiRefMax;         /*!<   */
  s16 UiRefTar;         /*!<   */
  s16 UiRefDuty;         /*!<   */  
  s16 RefTar;           /*!<  �ٶȲο�Ŀ��ֵ */    
  s16 RefCur;           /*!<  �ٶȲο���ǰֵ */    
  s16 Err;              /*!<  �ٶ���� */
  s16 ErrSum;           /*!<   */
  s16 FdbSpeed;         /*!<  �ٶȷ��� */      
  s16 FdbSpeedRpm;      /*!<  �ٶȷ���ʵ��ֵ */      
  u8  Shift;         
  u8  InputSelect;      /*!<   */      
  s16 IncValue;         /*!<  �ٶ����� */    
  s16 DecValue;         /*!<  �ٶȼ��� */      
  u16 EventPeriodCur;   /*!<   */
  u16 EventPeriodPre;   /*!<   */
  u16 EventPeriodErr;   /*!<   */
  u16 EventPeriodErrSum;   /*!<   */
  u16 EventPeriodErrAvg;   /*!<   */ 
  u32 SpeedScaler;      /*!<   */    
  u16 BaseRpm;          /*!<   */   
  
  u8 OverSpdCounter;
  u8 AngleCalcFlag;

  /*
  u32 ComNum;               
  s32 MechCircleNum;        
  u8  RotorPosition ;       
  u8  RotorPositionqPre; 
  */   
}spd_TypeDef;

/**
* \struct Fail_TypeDef
*
* \note
*/
typedef struct
{
  u8 ErrCur;
  u8 ErrPre;
  
  u8 DsovRestartNum;
  u8 DsovRestartCounter;
  u16 DsovRestartTimCounter;
  
}IPD_TypeDef;

/**
* \struct MCL_TypeDef
*  ������Ʋ����
* \note
*/
typedef struct
{
  Status_TypeDef State;       /*!< ϵͳ״̬ */      

  u8  gIsrTicker;             /*!< ϵͳ��ʱ��*/
  s8  gStartC;                /*!< ������� */       
  s8  gDirectionC;            /*!< ���������з��� */       
  s8  gStopmodeC;             /*!< ������ͣ��ģʽ */      
  s8  gStepCur;               /*!< ����������� */     
  s8  gStepPre;               /*!< ����������� */       

  Error_TypeDef  SysError;    /*!< ϵͳ���ϴ��� */        
  E_MESSSAGE_TypeDef E_message;
  spd_TypeDef    Spd;         /*!< �ٶ�-�ṹ�� */       
  VTim_TypeDef   Vtim;        /*!< ���ⶨʱ�� */        
  Stall_TypeDef  Stall;       /*!< ת�ٸ��� */      
  Alig_TypeDef   Alig;        /*!< ��λ״̬ */       
  Ramp_TypeDef   Ramp;        /*!< ����״̬ */       
  Nor_TypeDef    Nor;         /*!< ����״̬ */
  Fail_TypeDef   Fail;         /*!< ����״̬ */
  
  BEMF_TypeDef   Bemf;        /*!< ������ */       

  IPD_TypeDef    IPD;
} MCL_TypeDef;
  
extern MCL_TypeDef  Ctl;      

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
extern void MCL_Function(void);      
extern void MCL_Bkin_Isr(void);
extern void MainISR(void);     

/** @}*/

#endif /* __MAIN_H */


