/**
  ******************************************************************************
  * @file    \USER\inc\MC_init.h 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   ��ʼ��ͷ�ļ�
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 
#ifndef MC_INIT_H
#define MC_INIT_H

/* Includes ------------------------------------------------------------------*/
#include "MC_stm8Timer.h"
#include "MC_stm8Adc.h"
#include "MC_MotorCotrol.h"

/* Exported define -----------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
typedef struct 
{ 
  u8  Flag;
  u16 ROP;  
  u16 AFR;
  u16 WFS; /*Flash wait states*/
} OPT_BYTE_TypeDef ;
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 
extern void Clk_Config(void);
extern void SoftwareInit(void);
extern void MCL_ModuleInit(void);
extern void MCL_ModuleDefault(void);
extern void gDelayus(u16 timer);
extern void gDelayms(u16 timer);

extern void Ui_Function(void);
extern void APP_FaultLed(void); 
extern void BSP_FeedDog(void);
extern void APP_GetMainLoopTim(void);
extern void APP_RstMainLoopTim(void);
extern void APP_Flash_Save_Data(void);

extern OPT_BYTE_TypeDef Opt;
#endif /* __HD_init_H */

/************************* (C) COPYRIGHT 2018 JK ***************END OF FILE****/