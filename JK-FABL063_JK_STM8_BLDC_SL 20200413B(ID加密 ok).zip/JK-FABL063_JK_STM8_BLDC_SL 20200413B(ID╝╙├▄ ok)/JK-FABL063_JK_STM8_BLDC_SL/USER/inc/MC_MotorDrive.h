/**
  ******************************************************************************
  * @file    \USER\inc\MC_MotorDrive.h  
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   ���������ͷ�ļ� 
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MC_MOTORDRIVE_H
#define MC_MOTORDRIVE_H

/* Includes ------------------------------------------------------------------*/
#include "stm8s_type.h"
/* Exported types ------------------------------------------------------------*/

/** \defgroup Motor_Drive_data  ������������ݽṹ
 *  @{
 */

/**
* \struct SPEED_MEAS_CAP 
*  �ٶȼ������
* \note 
*/  
typedef struct 
{
  u16 EventPeriodCur;/*!<  */
  u16 EventPeriodPre;/*!<  */
  u16 EventPeriodErr;/*!<  */
  u32 SpeedScaler;   /* Parameter : Scaler converting 1/N cycles to a GLOBAL_Q speed (Q0) - independently with global Q  */
  u16 BaseRpm;       /* Parameter : Scaler converting GLOBAL_Q speed to rpm (Q0) speed - independently with global Q      */
  s16 SpeedRpm;      /* Output : speed in r.p.m. (Q0) - independently with global Q                                       */
  s16 Speed;         /* Output :        */
  s16 Err; 
} SPEED_MEAS_CAP;    /* Data type created   */

/**
* \struct ADC2MEAS_TypeDef
*  adc��������
* \note 
*/  
typedef struct 
{ 
  u8  ChannelChoice;  /*!<  */
  SWORD Data;          /*!<  */
  s16 VmeasA;         /*!<  Va*/ 
  s16 VmeasB;         /*!<  Vb*/
  s16 VmeasC;         /*!<  Vc*/
  s16 VmeasX;         /*!<  Vx*/
  s16 VmeasRise;      /*!<  */
  s16 VmeasFall;      /*!<  */
  s16 VmeasZn;        /*!<  */

  float Vdc;          /*!< ĸ�ߵ�ѹ*/
  float VdcMeasGain;  /*!< Parameter: gain for Vdc (Q13)  */ 

  s16 VdcMeasPre;         /*!< Output: measured Vdc (Q15)     */  
  s16 VdcMeas;         /*!< Output: measured Vdc (Q15)     */
  s16 VdcMeasHalf;     /*!<  */
  s16 VdcAvgMeas;
  s16 VdcSumMeas;      /*!<  */
  
  s16 VdcBemfOffset;   /*!<  */
  s16 VdcBemfOffsetCur;/*!<  */
  s16 VdcBemfOffsetTar;/*!<  */
  
  float Ibus;         /*!< ĸ�ߵ���*/
  float IBusMeasGain; /*!< Parameter: gain for Ia (Q13)   */
  s16 IBusMeasOffset;  /*!< Parameter: offset for Ia (Q15) */    
  s16 ImeasBus;        /*!< Output: measured Ia (Q15)      */
  
  float Th1;          /*!< Output: measured VthMeas (Q12)   */
  s16   Th2;           /*!< Output: measured VthMeas (Q12)   */
  u16 Vth1Meas;        /*!< Output: measured VthMeas (Q12)*/ 
  u16 Vth2Meas;        /*!< Output: measured Vth1Meas (Q12)*/ 
  s16 SrefMeas;        /*!< Output: measured VthMeas (Q12) */
} ADC2MEAS_TypeDef; 

/**
* \struct Stk_TypeDef 
* ת�ٸ��ٱ���
* \note 
*/  
typedef struct   
{
  s8  BemfSetFR;  /*!<  */
  s8  BemfValue;  /*!<  */                   
  u8  BemfNum;    /*!<  */
  s8  BemfTabA,BemfTabB,RefNumZ,RefNumY,RefNumX;   /*!<  */  
  u8  BemfFR;     /*!<  */                   
  u8  Calcnum;    /*!<  */                   
  u8  Calcnms;    /*!<  */                 
} Stk_TypeDef;    

/**
* \struct HALL_TypeDef
* hall����
* \note 
*/  
typedef struct
{
  u8  Status;            /*!<  */  
  u8  StatusPre;         /*!<  */             
  u8  Section;           /*!<  */            
  u8  u8ChangePhaseNum;  /*!<  */             
  s16 s16AdvanceEangle;  /*!<  */     
  u8  u8ChangePhaseFlag; /*!<  */   
} HALL_TypeDef;

/**
* \struct PWM_TypeDef
*  PWM�������
* \note 
*/  
typedef struct
{ 
  WORD Duty;           /*!<  */
  u16  Period;         /*!<  */
  u16  DutyArr;        /*!<  */
  s16  DutyCur;        /*!<  */
  s16  DutyTar;        /*!<  */
  s16  DutyIncValue;   /*!<  */     
  s16  DutyDecValue;   /*!<  */
  s16  DutyMax;        /*!<  */
  s16  DutyMin;        /*!<  */
  s16  DutyLimitMaxRefH;/*!<  */
  s16  DutyLimitMaxRefL;/*!<  */
  u16  DutyLimitValue; /*!<  */
  u8   DutyLimitFlag;  /*!<  */    
}PWM_TypeDef;


/**
* \struct PWM_TypeDef
*  PWM�������
* \note 
*/  
typedef struct
{ 
  s8 Errfilter; 
  
}TLE7184_TypeDef;



/**
* \struct DRV_TypeDef
*  ������������
* \note 
*/  
typedef struct
{
  ADC2MEAS_TypeDef  AdcMeas; /*!<  */          
  PWM_TypeDef       PWM;     /*!<  */         
  /* SPEED_MEAS_CAP    Spd;   */          
  //HALL_TypeDef      Hall;     
  TLE7184_TypeDef TLE7184;
  u8 MduCalcFlag;
}DRV_TypeDef;

extern DRV_TypeDef Drv;         /*ȫ�ֱ��� �ⲿ���� */
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 
extern void Drv_SpeedRampCale(void);
extern void Drv_PwmUpdate(void);
extern void Drv_Commutation(s8 Step);
extern void Drv_BemfPhaseChoice(s8 Step);
extern void Drv_BemftCalc(void);
extern void Drv_SpdClosed(void);
extern void Drv_SpdClosedPro(void);
extern void Drv_Tim2CalcPeriod (void);
extern void Drv_SpeedClac(void);
extern void APP_MainLoopTim(void);
extern void Drv_OverSpd (void);
extern void Drv_Tim2SetDelayAngle (u16 Angle);
extern void Drv_MotorSelfInspection(void);
extern void Drv_7184ClearError(void);

/** @}*/

#endif /* __HD_init_H */

/************************* (C) COPYRIGHT 2018 JK ***************END OF FILE****/