/**
  ******************************************************************************
  * @file    \USER\inc\MC_stm8s_HWPlat_param.h 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   Ӳ������
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 
#ifndef __MC_STM8S_HWPlat_PARAM_H
#define __MC_STM8S_HWPlat_PARAM_H


/*FAULT ????*/
#define FAULT_PORT         GPIOC
#define FAULT_ODR          GPIOC->ODR
#define FAULT_BIT          GPIO_PIN_5
#define FAULT_ON           BSET(FAULT_ODR, (u8)FAULT_BIT)
#define FAULT_OFF          BCLR(FAULT_ODR, (u8)FAULT_BIT)
#define FAULT_ONOFF        {FAULT_ODR ^= (u8)FAULT_BIT;}

/*P4 ��������*/  
#define FBIN_PORT         GPIOD
#define FBIN_IDR          GPIOD->IDR
#define FBIN_ODR          GPIOD->ODR
#define FBIN_BIT          GPIO_PIN_5 
#define FBIN_ON           BSET(FBIN_ODR, (u8)FBIN_BIT)
#define FBIN_OFF          BCLR(FBIN_ODR, (u8)FBIN_BIT)

#define FBIN_ONOFF        {FBIN_ODR ^= (u8)FBIN_BIT;}

/*FB*/  	
#define FB_PORT         GPIOD
#define FB_IDR          GPIOD->IDR
#define FB_ODR          GPIOD->ODR
#define FB_BIT          GPIO_PIN_6 
#define FB_ON           BSET(FB_ODR, (u8)FB_BIT)
#define FB_OFF          BCLR(FB_ODR, (u8)FB_BIT)

#define FB_ONOFF        {PB_ODR ^= (u8)PB_BIT;}
/*FG*/  	
#define FG_PORT         GPIOC
#define FG_ODR          GPIOC->ODR
#define FG_BIT          GPIO_PIN_5 
#define FG_OFF          BSET(FG_ODR, (u8)FG_BIT)
#define FG_ON           BCLR(FG_ODR, (u8)FG_BIT)
#define FG_ONOFF        {FG_ODR ^= (u8)FG_BIT;}

/*PWMIN */
#define PWMIN_PORT         GPIOD
#define PWMIN_ODR          GPIOD->ODR
#define PWMIN_IDR          GPIOD->IDR
#define PWMIN_BIT          (u8)GPIO_PIN_2
#define PWMIN_ON           BSET(PWMIN_ODR, (u8)PWMIN_BIT)
#define PWMIN_OFF          BCLR(PWMIN_ODR, (u8)PWMIN_BIT)

/* BRK */                             
//#define BREAK_PORT              GPIOD
//#define BREAK_IDR               GPIOD->IDR
//#define BREAK_ODR               GPIOD->ODR
//#define BREAK_BIT               GPIO_PIN_0

/* ERR */  
#define TLE7184_ERR_PORT              GPIOD
#define TLE7184_ERR_IDR               GPIOD->IDR
#define TLE7184_ERR_ODR               GPIOD->ODR
#define TLE7184_ERR_BIT               GPIO_PIN_0

/* RGS */                             
#define TLE7184_RGS_PORT        GPIOC
#define TLE7184_RGS_IDR         GPIOC->IDR
#define TLE7184_RGS_ODR         GPIOC->ODR
#define TLE7184_RGS_BIT         (u8)GPIO_PIN_6  

#define TLE7184_RGS_ON           BSET(TLE7184_RGS_ODR, TLE7184_RGS_BIT)
#define TLE7184_RGS_OFF          BCLR(TLE7184_RGS_ODR, TLE7184_RGS_BIT)

/* INHD */                             
#define TLE7184_INHD_PORT       GPIOC
#define TLE7184_INHD_IDR        GPIOC->IDR
#define TLE7184_INHD_ODR        GPIOC->ODR
#define TLE7184_INHD_BIT        GPIO_PIN_7  

/* Three phase PWM control configuration port pin */
#define UH_PORT                 GPIOC
#define UH_ODR                  GPIOC->ODR
#define UH_BIT                  GPIO_PIN_1

#define VH_PORT                 GPIOC
#define VH_ODR                  GPIOC->ODR
#define VH_BIT                  GPIO_PIN_2

#define WH_PORT                 GPIOC
#define WH_ODR                  GPIOC->ODR
#define WH_BIT                  GPIO_PIN_3

#define UL_PORT                 GPIOD
#define UL_ODR                  GPIOD->ODR
#define UL_BIT                  GPIO_PIN_3

#define VL_PORT                 GPIOD
#define VL_ODR                  GPIOD->ODR
#define VL_BIT                  GPIO_PIN_4

#define WL_PORT                 GPIOD
#define WL_ODR                  GPIOD->ODR
#define WL_BIT                  GPIO_PIN_7

/*
#define CMP_IDR                 GPIOB->IDR
#define CMP_PHASE_U_BEMF_CHAN   GPIO_PIN_0
#define CMP_PHASE_V_BEMF_CHAN   GPIO_PIN_1
#define CMP_PHASE_W_BEMF_CHAN   GPIO_PIN_2
     
#define ADC_PHASE_U_BEMF_CHAN 	ADC1_CHANNEL_0
#define ADC_PHASE_V_BEMF_CHAN 	ADC1_CHANNEL_1
#define ADC_PHASE_W_BEMF_CHAN 	ADC1_CHANNEL_2
#define ADC_BUS_CHANNEL         ADC1_CHANNEL_3
#define ADC_CURRENT_CHANNEL     ADC1_CHANNEL_4
#define ADC_VSPEED_CHANNEL      ADC1_CHANNEL_12
#define ADC_USER_CHANNEL        ADC1_CHANNEL_5
*/

#endif 


