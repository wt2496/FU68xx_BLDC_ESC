/**
  ******************************************************************************
  * @file    JK_STM8_BLDC\USER\inc\MC_DMC.h 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   ��ѧ����
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 
#ifndef MC_DMC_H
#define MC_DMC_H

/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
/* Exported define -----------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

/**
* \struct PIDREG
*  PID����
* \note 
*/  
typedef struct 
{
  s16 Ref;           /*!<  �ο�ֵ */
  s16 Fdb;           /*!<  ����ֵ */
  s16 Err;           /*!<  ���ֵ*/  
  s16 Kp;            /*!<  KP*/
  s16 Ki;  
  s16 Ki_p;            /*!<  KI*/
  s16 Ki_n;            /*!<  KI*/  
  s16 Kd;            /*!<  Kd*/
  s16 Kc;            /*!<  Kc*/  
  s16 Out;           /*!<  OUT*/ 
  s16 Up;            /*!<  UP*/
  s16 Ui;            /*!<  UI*/
  s16 Ud;            /*!<  Ud*/
  
  s16 UpPre;         /*!<  UpPre*/  
  s16 OutPreSat;     /*!<  OutPreSat*/
  s16 OutMax;        /*!<  OutMax*/
  s16 OutMin;        /*!<  OutMin*/
  s16 Err_1;         /*!<  �ϴ����ֵ*/
  s16 Err_2;         /*!<  �ϴ����ֵ*/  
  
  s16 SatErr;          /*!<  �ϴ����ֵ*/
}PIDREG;

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 
/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
extern PIDREG  pid_spd ;         
extern void Dmc_SpdPidInit(void);
extern void Dmc_SpdPidDefault(void);
extern void Dmc_SpdPidCalc(void);
extern void Dmc_GetConversionValue(void);
#endif /* __HD_HALL_H */

/************************* (C) COPYRIGHT 2018 JK ***************END OF FILE****/