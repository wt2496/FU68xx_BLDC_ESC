/**
  ******************************************************************************
  * @file    \USER\inc\Bsp_Pwmin.h 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   PWMIN  ����ͷ�ļ�
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef BSP_PWMIN_H
#define BSP_PWMIN_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

/** \defgroup Uaer_Interface_data  �˻����������ݽṹ 
 *  @{
 */

/**
* \struct Uibit_TypeDef
*  bit
* \note 
*/  

typedef struct
  { 
    WORD Data1;          /*!<  */
    WORD Data2;          /*!<  */
    u8 Pulse;
    u16 H_Cur;
    u16 L_Cur;
    u16 H_Per;
    u16 L_Per;  
    u16 L_Avg; 
    u16 Period;
    u16 PeriodH;
    u16 PeriodL;
    
    u16 Duty;  
    u16 DutySum;  
    u16 DutyAvg;  
    
    u8 TimOvCounter;
    s8 SignaCounter;
    float fDuty;        
  }PWMINCAP_TypeDef;


/**
* \struct PWMINCAP_TypeDef
*  PWMPWMINCAP_TypeDef IN�������
* \note 
*/  

extern PWMINCAP_TypeDef gPwminCap;

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 
//extern void Ui_Function(void) ;
extern void APP_PwminDetection(void);
extern void BSP_PwmIn_Init(void);
extern void APP_PwminCap_Calc(void);
extern void APP_PwminLostSignalCalc(void);

/** @}*/

#endif /* __HD_init_H */

/************************* (C) COPYRIGHT 2018 JK ***************END OF FILE****/