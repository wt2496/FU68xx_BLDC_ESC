/**
  ******************************************************************************
  * @file    \USER\inc\TTech_BLDC.h 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 
#ifndef __JKTECH_BLDC_H
#define __JKTECH_BLDC_H

/* Includes ------------------------------------------------------------------*/
/* Exported define -----------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 
extern void Drv_SmartRumCalc(void);       
extern void Drv_SmartStartCalc(void);
extern void Drv_PosTrack(void);


#endif /* __JKTECH_BLDC_H*/

/************************* (C) COPYRIGHT 2018 JK ***************END OF FILE****/