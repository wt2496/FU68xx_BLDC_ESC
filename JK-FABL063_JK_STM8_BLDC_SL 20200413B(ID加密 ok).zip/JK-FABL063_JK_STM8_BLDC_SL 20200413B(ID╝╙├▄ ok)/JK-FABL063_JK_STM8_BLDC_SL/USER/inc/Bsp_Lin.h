/**
  ******************************************************************************
  * @file    \USER\inc\MC_UserInterface.h
  * @author  tom.wang Application Team
  * @version
  * @since
  * @date    2018-10-17
  * @note
  * @brief   �˻�����ͷ�ļ�
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef BSP_LIN_H
#define BSP_LIN_H

/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/

/** \defgroup Uaer_Interface_data  �˻����������ݽṹ
 *  @{
 */

/* LIN Frame type */
typedef struct
{
  u16 LostSignalTimCounter;
  uint8_t LostSignalFlag;
  uint8_t DataReceived ;   /* Flag to indicate data reception on RX pin (RXNE) */
  uint8_t HeaderReceived ; /* Flag to indicate Break reception on RX pin (LHDF) */
  uint8_t BreakReceived;   /* Flag to indicate Break reception on RX pin (LBDF) */
  uint8_t IdentifierParityError ; /*Flag to indicate parity error in received LIN Identifier */
  uint8_t LINReceptionTimeoutValue ;
  uint8_t gLINChecksum;

  uint8_t SpeedRef;
  uint8_t SpeedStart;
  uint8_t DataToSend[9];/* Data to be sent */
  /*
  static uint8_t LINTransmitBuffer[9];
  static uint8_t LINReceiveBuffer[9];
 */
  bool LINReceptionTimeout;
  bool LINSlave;
  volatile uint8_t UART3_SR_Buf;
  volatile uint8_t UART3Data;
  volatile uint8_t ReceptionError;

} LINF_Type;


/**
* \struct PWMINCAP_TypeDef
*  PWMPWMINCAP_TypeDef IN�������
* \note
*/

extern LINF_Type gLin;
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

extern void InitScheduleTable(void);
extern void LIN_SlaveConfig(void);
extern void APP_LIN_Task(void);
extern void APP_Lin_Calc(void);

/** @}*/

#endif /* __HD_init_H */

/************************* (C) COPYRIGHT 2018 JK ***************END OF FILE****/