/**
  ******************************************************************************
  * @file    \USER\src\MC_Stm8Adc.c 
  * @author  Application Team  Tom.wang 
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   ģ�����ɼ�
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */   
/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "MC_stm8Adc.h"
#include "MC_MotorDrive.h" 
#include "MC_init.h" 
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void ADC_Config(void);
void AdcGetConversionValue(void);
void AdcSelfInspection(void);
u16 ADCFastImeasConvert(void);
void AdcSingleScanMode(void);
void AdcChannelSwitchMode(void);
void AdcSoftMultichannelScanMode(void);

extern void gAdcSampleCapacitorsDelay(void);
/* Private functions ---------------------------------------------------------*/

/**
  * @fn     void ADC_Config(void)    
  * @brief  
  *    �ƻ��������Ʋ������ȼ���ߣ� 
  *    �ڷ����Ʋ�������֮�󣬿�ʼ���β��������źš�
  * @retval None
000: fADC = fMASTER /2 
001: fADC = fMASTER /3 
010: fADC = fMASTER /4 
100: fADC = fMASTER /8 
101: fADC = fMASTER /10 
110: fADC = fMASTER /12 
111: fADC = fMASTER /18
  */
void ADC_Config(void)
{
  GPIO_Init(GPIOB, GPIO_PIN_0, GPIO_MODE_IN_FL_NO_IT);
  GPIO_Init(GPIOB, GPIO_PIN_1, GPIO_MODE_IN_FL_NO_IT);
  GPIO_Init(GPIOB, GPIO_PIN_2, GPIO_MODE_IN_FL_NO_IT);
  GPIO_Init(GPIOB, GPIO_PIN_3, GPIO_MODE_IN_FL_NO_IT);
  GPIO_Init(GPIOB, GPIO_PIN_4, GPIO_MODE_IN_FL_NO_IT);
  GPIO_Init(GPIOB, GPIO_PIN_5, GPIO_MODE_IN_FL_NO_IT);  
  GPIO_Init(GPIOF, GPIO_PIN_4, GPIO_MODE_IN_FL_NO_IT); 
  
  /*
  ʩ���ش�������ֹ
  */
  #if(0)
    ADC2->TDRH = (uint8_t)0xFF; 
    ADC2->TDRL = (uint8_t)0xFF; 

    ADC2->CR1  = 0x50;  /*ADCʱ��=��ʱ��/10=2.4MHZ,ת��ģʽ=����,��ֹADCת�� */
    ADC2->CR2  = 0x0A;  /*A/D��������Ҷ��룬����ɨ��*/
    ADC2->CSR  = 0x03;  /*ɨ��ģʽֻ�ܴ�ͨ��0��ʼ��ֱ��ͨ��n��*/
  #else
  
  ADC2->TDRH = (uint8_t)0xFF; /*ʩ���ش�������ֹ*/
  ADC2->TDRL = (uint8_t)0xFF;

  /*ADC2_PrescalerConfig(ADC2_PRESSEL_FCPU_D10);  2.4mHz
  ADC2_ConversionConfig(ADC2_CONVERSIONMODE_CONTINUOUS,ADC2_CHANNEL_0,ADC2_ALIGN_RIGHT);

  ADCʱ��=��ʱ��/2 = 10MHZ,   ����ת������14��  ʱ��7us��
  */
  ADC2->CR1  = (u8)0x40;   /*ADC2_PRESSEL_FCPU_D12;*/
  ADC2->CR1 |= (u8)2;          /*����ģʽ*/
  ADC2->CR2  = 0x08;       /*A/D��������Ҷ��룬����ɨ��*/
  ADC2->CSR  = 0x00;       /*ɨ��ģʽֻ�ܴ�ͨ��0��ʼ��ֱ��ͨ��n��*/
  
  /* ADC2 û��ģ�⿴�Ź�
  ADC2->CSR |= 1<<5;  ʹ��ģ�⿴�Ź�
  ADC2->CSR |= 1<<4;  ʹ��ģ�⿴�Ź�
  ADC2->AWCRL |= 1<<0;  ʹ��ģ�⿴�Ź�����
  */
//  ADC2->HTRH = 0xFF;  ++++
//  ADC2->HTRL = 0xFF;
//
//  ADC2->LTRH = 0x40;
//  ADC2->LTRL = 0x00;

  ADC2->CR1 |= (u8)1; /*����ת��*/
  #endif      
    
  AdcSelfInspection();
}

/*
20180808 TOM
ת��ʱ�� 2Mhz 14cycle  0.5us*14 = 7us 
ʵ�ʲ��ԣ�8.7us
*/
u16 ADCFastImeasConvert(void)
{
  WORD tADC;
  
  ADC2->CSR  = (u8)ADC2_CHANNEL_12;
  ADC2->CR1 |= ADC2_CR1_ADON; 
  
  while((ADC2->CSR & (u8)0x80) == (u8)0x00){};	
  ADC2->CSR &= ~(u8)0x80;			
  
  tADC.B.L = ADC2->DRL;
  tADC.B.H = ADC2->DRH;
  
  return tADC.W;       
}

/**
  * @fn     void AdcSelfInspection(void)    
  * @brief  adc��ʼ��
  * @retval None
  */
#pragma optimize=none 
void AdcSelfInspection(void)
{
  u8 i,j;
  u16 tIbusAvg,tIbusTemp;

  /*
  VDCMEASEGAIN = 0.02805;
  IBUSMEASGAIN = 0.14; 
  */
  Drv.AdcMeas.VdcMeasGain = VDCMEASEGAIN;  
  Drv.AdcMeas.IBusMeasGain = IBUSMEASGAIN; 
 /*----------------------------------------------------
 adc ��������Լ�,����������׼У׼ 
 */
  tIbusAvg = 0;  
  for(i = 0,j = 0;i < (u8)8;)
  {
    tIbusTemp = ADCFastImeasConvert(); 
                  
    if(tIbusTemp < (u16)(1024*0.3))
    {
      tIbusAvg += tIbusTemp;
      i++;
    }
    else if((tIbusTemp < (u16)(1024*0.4))&&(tIbusTemp >  (u16)(1024*0.6)))   /*R10.4 ������ֻ��ǿ��ת��Ϊ����խ�ĸ����� */
    {
      tIbusAvg += tIbusTemp;
      i++;
    }
    else
    {
      //j++;
      if(j > (u8)8)
      {
        i = 8;
        //Ctl.SysError.Code = E_ADC;     
      }
    }
  }
  Drv.AdcMeas.IBusMeasOffset = -(tIbusAvg>>3); 
  Drv.AdcMeas.ImeasBus = 0;
  Drv.AdcMeas.Ibus = (float)0.0;  

  if(Ctl.SysError.Code != E_ADC)
  {  
    /*
    �����Լ�  �ϵ��¶��ڣ�-100��~200�棩֮��  �������ѹ(2.3V~4.6V)
    */
    for(i = 0,j = 0;i < 8;)
    {
      Drv.AdcMeas.ChannelChoice = (u8)ADC2_SCHMITTTRIG_CHANNEL5;
      AdcChannelSwitchMode();
      Drv.AdcMeas.Vth1Meas = Drv.AdcMeas.Data.W;
            
      if((Drv.AdcMeas.Vth1Meas < (u16)958)&&(Drv.AdcMeas.Vth1Meas > (u16)476))
      {
        i++;
      }
      else
      {
        j++;      
        if(j > (u8)8)
        {
          i = (u8)8;
          //Ctl.SysError.Code = E_ADC_T;     
        }
      }
    } 
   /*
   ĸ�ߵ�ѹ�Լ�  ��ѹ��Χ��5V~30V�� �������ѹ(0.8V~4.8V)
   */
    for(i = 0,j = 0;i < 8;)
    {
      Drv.AdcMeas.ChannelChoice = ADC2_SCHMITTTRIG_CHANNEL4;
      AdcChannelSwitchMode();
      Drv.AdcMeas.VdcMeas = Drv.AdcMeas.Data.W;
            
      if((Drv.AdcMeas.VdcMeas < 986)&&(Drv.AdcMeas.VdcMeas > 164))
      {
        i++;
      }
      else
      {
        j++;      
        if(j > (u8)8)
        {
          i = 8;
          //Ctl.SysError.Code = E_ADC_V;     
        }
      }
    }
  }  
}

/**
  * @fn     void AdcSingleScanMode(void)    
  * @brief  
  *         ���²�������ADCʱ��2MHz���������Ը�Ϊ4mhz 
  *         ����ɨ��ģʽ
  * @retval None
  */
void AdcSingleScanMode(void) 
{ 
  #if(0)
    /*
    ����1  ʱ��100us ԭ����� 
  
    */
    ADC2->CSR  = 0x02;     /*ɨ��ģʽֻ�ܴ�ͨ��0��ʼ��ֱ��ͨ��n��*/
    ADC2->CR2 |= 0x02;     /*ɨ��ģʽ */
    ADC2->CR1 |= 0x01;     /*����*/
    
    while((ADC2->CSR & 0x80) == 0x00){};
    ADC2->CSR &= ~0x80;	                
    Drv.AdcMeas.VmeasA = (u16)ADC2_GetBufferValue(ADC2_SCHMITTTRIG_CHANNEL0<<1);   
    Drv.AdcMeas.VmeasB = (u16)ADC2_GetBufferValue(ADC2_SCHMITTTRIG_CHANNEL1<<1);   
    Drv.AdcMeas.VmeasC = (u16)ADC2_GetBufferValue(ADC2_SCHMITTTRIG_CHANNEL2<<1);  
    /*
    Drv.AdcMeas.ImeasBus = (u16)ADC2_GetBufferValue(ADC2_SCHMITTTRIG_CHANNEL3<<1);
    Drv.AdcMeas.VdcMeas = (u16)ADC2_GetBufferValue(ADC2_SCHMITTTRIG_CHANNEL4<<1); 
    */ 
    ADC2->CR2  &= ~0x02;               /* ��ֹɨ�� */ 

  #elif (1)
    /*����2 27us*/
    ADC2->CSR  = (u8)ADC2_CHANNEL_3;
    gAdcSampleCapacitorsDelay();
    Drv.AdcMeas.ChannelChoice = (u8)ADC2_SCHMITTTRIG_CHANNEL0;
    AdcChannelSwitchMode();
    Drv.AdcMeas.VmeasA = Drv.AdcMeas.Data.W;
    ADC2->CSR  = (u8)ADC2_CHANNEL_3;
    gAdcSampleCapacitorsDelay();
    Drv.AdcMeas.ChannelChoice = (u8)ADC2_SCHMITTTRIG_CHANNEL1;
    AdcChannelSwitchMode();
    Drv.AdcMeas.VmeasB = Drv.AdcMeas.Data.W;
    ADC2->CSR  = (u8)ADC2_CHANNEL_3;
    gAdcSampleCapacitorsDelay();
    Drv.AdcMeas.ChannelChoice = (u8)ADC2_SCHMITTTRIG_CHANNEL2;
    AdcChannelSwitchMode();
    Drv.AdcMeas.VmeasC = Drv.AdcMeas.Data.W;
    
  #elif (0)
    /*����3 26.7us �ȷ���2�� 30�ֽ�,�ٶȿ첻��1us��*/
    ADC2->CSR  = ADC2_SCHMITTTRIG_CHANNEL0;
    ADC2->CR1 |= ADC2_CR1_ADON; 

    while((ADC2->CSR & 0x80) == 0x00){}; 
    ADC2->CSR &= ~0x80;                 

    tADC.B.L = ADC2->DRL;
    tADC.B.H = ADC2->DRH; 
    Drv.AdcMeas.VmeasA = tADC.W; 

    
    ADC2->CSR  = ADC2_SCHMITTTRIG_CHANNEL1;
    ADC2->CR1 |= ADC2_CR1_ADON; 

    while((ADC2->CSR & 0x80) == 0x00){};
    ADC2->CSR &= ~0x80;                 

    tADC.B.L = ADC2->DRL;
    tADC.B.H = ADC2->DRH; 
    Drv.AdcMeas.VmeasB = tADC.W; 
    
    ADC2->CSR  = ADC2_SCHMITTTRIG_CHANNEL2;
    ADC2->CR1 |= ADC2_CR1_ADON; 

    while((ADC2->CSR & 0x80) == 0x00){}; 
    ADC2->CSR &= ~0x80;               
    
    tADC.B.L = ADC2->DRL;
    tADC.B.H = ADC2->DRH; 
    Drv.AdcMeas.VmeasC = tADC.W;
 
#endif 
}

/**
  * @fn     void AdcChannelSwitchMode(void)    
  * @brief  
  * @retval None
  */
void AdcChannelSwitchMode(void)
{  
  ADC2->CSR  = Drv.AdcMeas.ChannelChoice;
  ADC2->CR1 |= ADC2_CR1_ADON; 
  
  ADC2->CSR &= ~(u8)0x80;                      /*�������*/
  while((ADC2->CSR & (u8)0x80) == (u8)0x00){}; /*�ȴ�ת�����*/ 
  ADC2->CSR &= ~(u8)0x80;                      /*�������*/

  Drv.AdcMeas.Data.B.L = ADC2->DRL;
  Drv.AdcMeas.Data.B.H = ADC2->DRH;
}

/**
  * @fn     void AdcSoftMultichannelScanMode(void)    
  * @brief  
  * @retval None
  */
void AdcSoftMultichannelScanMode(void)
{
  s16 temp;
  /*
  ���������� �����ɺ󣬿�ʼ��������ѹ���¶Ȳ��� 
  AN3 -> Ibus 
  AN4 -> Vbus
  AN5 -> Tj
  */
  if((Ctl.gStepCur != Ctl.Bemf.SingleBemfDetectionStepCur)||(Ctl.State != MOTOR_NORMAL))
  {  
    ADC2->CSR  = ADC2_CHANNEL_3;
    gDelayus((u16)1);     /*  �β���u16 ��ʽ*/
    
    if(Drv.AdcMeas.ChannelChoice == (u8)4)
    {
      Drv.AdcMeas.ChannelChoice = 5;
    }
    else if(Drv.AdcMeas.ChannelChoice == (u8)5)
    {
      Drv.AdcMeas.ChannelChoice = 12;
    }
    else
    {
      Drv.AdcMeas.ChannelChoice = 4;
    }
    AdcChannelSwitchMode();
    
    if(Drv.AdcMeas.ChannelChoice == (u8)12)           /*Ibus  ƫ�õ�ѹ->506*/
    {
      Drv.AdcMeas.ImeasBus = Drv.AdcMeas.Data.W + Drv.AdcMeas.IBusMeasOffset;  
    }  
    else if(Drv.AdcMeas.ChannelChoice == (u8)4)
    {  
      Drv.AdcMeas.VdcMeas  = Drv.AdcMeas.Data.W;     /*Vbus 13.5V -> 442*/ 
      temp= Drv.AdcMeas.VdcMeas- Drv.AdcMeas.VdcMeasPre;
      
      if((temp > -15)&&(temp < 15))                 /*�˳������ź� ADCֵ34->1V*/
      {  
        Drv.AdcMeas.VdcSumMeas += Drv.AdcMeas.VdcMeas ;  
        Drv.AdcMeas.VdcAvgMeas  = Drv.AdcMeas.VdcSumMeas>>2;  /*�з����� ��λ*/
        Drv.AdcMeas.VdcSumMeas -= Drv.AdcMeas.VdcAvgMeas ;
      }
      
      Drv.AdcMeas.VdcMeasPre = Drv.AdcMeas.VdcMeas;
    }
    else if(Drv.AdcMeas.ChannelChoice == (u8)5)     /*L99 Tj */
    {
      Drv.AdcMeas.Vth1Meas = Drv.AdcMeas.Data.W;
    }
    else
    {
      ;
    }

  }
}
