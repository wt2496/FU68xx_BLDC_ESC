/**
  ******************************************************************************
  * @file    \USER\src\Interrupt.c 
  * @author  tom.wang Application Team
  * @version     
  * @since
  * @date    2018-10-17
  * @note  
  * @brief  �жϷ����ļ� 
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "MC_init.h" 
#include "MC_UserInterface.h"
#include "MC_MotorCotrol.h"  

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/**
  * @brief INTERRUPT_HANDLER
  * @par Parameters:
  * None
  * @retval void None
  * @par Required preconditions:
  * None
  * @par Called functions:
  * None
  */
INTERRUPT_HANDLER(TIM1_UI_BRK_IRQHandler,ITC_IRQ_TIM1_OVF) 
{
  if(TIM1_GetITStatus(TIM1_IT_UPDATE))
  {
    /*MainISR(); */
    TIM1->SR1 = (uint8_t)(~(uint8_t)TIM1_IT_UPDATE);
  }
  /*if(TIM1->SR1&TIM1_IT_BREAK)*/  
  if(TIM1_GetITStatus(TIM1_IT_BREAK))
  {
    /*Ctl.SysError.Code = E_FAIL;*/
    TIM1->SR1 = (uint8_t)(~(uint8_t)TIM1_IT_BREAK);
  }
}

/**
  * @brief Timer1 Capture/Compare Interruption routine.
  * @par Parameters:
  * None
  * @retval void None
  * @par Required preconditions:
  * None
  * @par Called functions:
  * None
  */
INTERRUPT_HANDLER(TIM1_CAP_COM_IRQHandler,ITC_IRQ_TIM1_CAPCOM)
{
  /*
  TIM1->SR1 &= TIM1->IER;
  if(TIM1->SR1&TIM1_IT_CC4)  
  */
  if(TIM1_GetITStatus(TIM1_IT_CC4))
  { 
    MainISR();    
    TIM1->SR1 = (uint8_t)(~(uint8_t)TIM1_IT_CC4);
  }
}
/*******************************************************************************
* Function Name  : 
* Description    : TIM2
* Input          : None
* Output         : 
* Return         : None
*******************************************************************************/
INTERRUPT_HANDLER(TIM2_COM_CAP_COM_IRQHandler,ITC_IRQ_TIM2_CAPCOM) 
{
  if(TIM2_GetITStatus(TIM2_IT_CC1))
  {
    TIM2->SR1 = (uint8_t)(~(uint8_t)TIM2_IT_CC1);
  }
}

/*******************************************************************************
* Function Name  : 
* Description    : 22
* Input          : None
* Output         : 
* Return         : None
INTERRUPT_HANDLER(ADC_IRQHandler, ITC_IRQ_ADC1)
{
  if(ADC1->CSR&ADC1_FLAG_AWD)
  { 
    ADC1->AWSRL = 0;
    ADC1->AWSRH = 0;
    ADC1->CSR = (uint8_t)(~(uint8_t)0xE0); 
  }
}
*******************************************************************************/


