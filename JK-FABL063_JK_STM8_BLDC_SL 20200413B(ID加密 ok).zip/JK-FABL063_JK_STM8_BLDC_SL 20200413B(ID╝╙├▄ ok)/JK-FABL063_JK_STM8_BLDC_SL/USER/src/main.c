/**
  ******************************************************************************
  * @file    \USER\src\main.c 
  * @author  tom.wang Application Team
  * @version
  *           ����Դ�ļ��汾�ţ�  PRO_JK_FABL039_S_V01
  *           ���������ļ��汾�ţ�PRO_JK_FABL039_P_V01
  *           Ӳ��ԭ��ͼ�汾�ţ�  SD_JK-FABL039-P201
  *           Ӳ��LAYOUT�汾�ţ�  LD_JK-FABL039-P201
  * @since
  * @date    2019-6-19
  * @note 
  *          20180807 Tom  \n
  *          Ӳ��ƽ̨:STM8AF6286+TLE7184 \n
  *          Ӳ���汾:LD_JK-FABL007-P201    \n                   
  * 
  * @brief   BLDC �����������������
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
/*#include <stdio.h> */
#include "stm8s_conf.h"
#include "user_conf.h"
#include "MC_init.h"  
#include "MC_UserInterface.h"
#include "MC_MotorCotrol.h"  
#include "MC_MotorDrive.h"  

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
uint8_t BSP_GetResetFlag(void);
/* Private functions ---------------------------------------------------------*/


/**
  * @fn     main
  * @brief  Main program
  * @note   None
  * @retval None
  */

void main(void)
{	
  SoftwareInit(); 
  MCL_ModuleInit();
  for(;;)
  {
    APP_RstMainLoopTim();
    BSP_FeedDog();
    Ui_Function();
    BSP_FeedDog();
    MCL_Function(); 
    BSP_FeedDog();
    APP_GetMainLoopTim();
  }  
}


#ifdef FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(u8 *file, u16 line)
#else
void assert_failed(void)
#endif
{
  /* Add your own code to manage an assert error */
  /* Infinite loop */
  for(;;)
  {
  }
}

/******************* (C) COPYRIGHT 2018 JK *****END OF FILE****/
