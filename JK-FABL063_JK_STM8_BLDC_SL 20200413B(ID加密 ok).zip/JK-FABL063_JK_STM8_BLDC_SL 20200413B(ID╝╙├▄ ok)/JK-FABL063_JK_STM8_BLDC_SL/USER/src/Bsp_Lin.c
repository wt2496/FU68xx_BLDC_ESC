/**
  ******************************************************************************
  * @file    \USER\src\MC_Pwimin.c
  * @author  tom.wang Application Team
  * @version
  * @since
  * @date    2019-01-25
  * @note
  * @brief   PWMռ�ձȼ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2019 JK </center></h2>
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "Bsp_Lin.h"
#include "MC_UserInterface.h"
#include "MC_MotorDrive.h"
#include "MC_MotorCotrol.h"

/* External variables --------------------------------------------------------*/
 bool ErrorState;

/* Private typedef -----------------------------------------------------------*/

typedef enum
{
  Idle,                   /*!<  ���� ���߸ߵ�ƽ*/
  Break,                  /*!<  ��� ���ߵ͵�ƽ*/
  SynchField,             /*!<  ͬ���� 0x55*/
  Identifier,             /*!<  ID*/
  DataTransmission,       /*!<  ��������*/
  DataReception           /*!<  ��������*/
} LIN_FSM_state;

/* LIN Frame type */
typedef struct
{
  uint8_t LINFrameIdentifier;  /*!<  ID*/
  uint8_t LINFrameDirection;   /*!<  ����*/
  uint8_t LINFrameDataLength;  /*!<  ���ݳ���*/
  uint8_t LINFrameBuffer[9];   /*!<  Buffer*/
} LINFrame_Type;

/* LIN Schedule table type */
typedef struct
{
  LINFrame_Type LINScheduleTableFrame; /*!<  ֡��ʽ*/
  uint8_t LINScheduleTableFrameDelay;  /*!<  ��ʱ�趨*/
} LINScheduleTable_Type;

LIN_FSM_state LIN_FSM;   /*!<  LIN״̬*/

LINScheduleTable_Type LINScheduleTable[4]; /*!<  */
LINF_Type gLin;

/* Private defines -----------------------------------------------------------*/

#define DELAY_10MS 10
#define DELAY_20MS 20

#define RECEIVE 0
#define TRANSMIT 1

#define LIN_MASTER_RECEPTION_TIMEOUT 4
#define LIN_SLAVE_RECEPTION_TIMEOUT  100  /* lin ���ܳ�ʱ 100ms�����³�ʼ��LIN״̬��*/


/*
ID	ID		BYTE1	BYTE2	BYTE3	 BYTE4	 BYTE5	 BYTE6	 BYTE7	 BYTE8	У��
3b	FB	129	81	FE	/	/	/	/	/	/


ID	ID	����ת��	����ת��	��ѹ	����/A	�¶�	����
1B	5B	BYTE1	BYTE2	BYTE3	 BYTE4	 BYTE5	 BYTE6	 BYTE7	 BYTE8	У��
1B	5B	0	0	4C	0		0	F4	1F

*/
#define MS0ID (0xFB) /* Master to slave frame 0, ID=0x3B with parity ��2λ��1*/
#define SM1ID (0x5B) /* Slave to master frame 1, ID=0x1B with parity */

#define MS2ID (0x3C|0xC0) /* Master to slave frame 2, ID=0x3D with parity */
#define SM3ID (0x3D|0XC0) /* Slave to master frame 3, ID=0x3C with parity */


/* Private macros ------------------------------------------------------------*/

#define IncrementScheduleTableTick() ScheduleTableTick++;
#define ClearScheduleTableTick() ScheduleTableTick=0;

/* Private variables ---------------------------------------------------------*/
static uint8_t DataBuffer[4][8]={0};     /* Reception data buffer for Frames*/
static uint8_t LINChecksumBuffer[10]={0}; /* Buffer for checksum calculation */
static uint8_t ResponseDataByteIndex =0;
static uint8_t DLC; /* Response length */
static uint8_t Index=0;
static bool LINTick = FALSE;

/* Private function prototypes -----------------------------------------------*/

static uint8_t LINChecksum (uint8_t*, uint8_t);
static void StartLINReceptionTimeout(void);
static void StopLINReceptionTimeout(void);
static bool LINReceptionTimeoutElapsed(void);
static uint8_t TestLINTimebaseTick(void);
static void ClearLINTimebaseTick(void);
static void LINError(void);

static void UART3_RIE (void);
void UART3_BDIE (void);
void APP_Lin_Calc(void);

/* Private functions ---------------------------------------------------------*/

/**
* @brief  < Add here the function description >
* @note   < OPTIONAL: add here global note >
* @param  None
* @retval None
*/
void InitScheduleTable(void)
{
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameIdentifier=MS0ID;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameDirection=TRANSMIT;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameDataLength=8;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameBuffer[0]=0;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameBuffer[1]=0;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameBuffer[2]=0;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameBuffer[3]=0;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameBuffer[4]=0;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameBuffer[5]=0;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameBuffer[6]=0;
  LINScheduleTable[0].LINScheduleTableFrame.LINFrameBuffer[7]=0;

  LINScheduleTable[1].LINScheduleTableFrame.LINFrameIdentifier=MS2ID;
  LINScheduleTable[1].LINScheduleTableFrame.LINFrameDirection=RECEIVE;
  LINScheduleTable[1].LINScheduleTableFrame.LINFrameDataLength=8;

  LINScheduleTable[2].LINScheduleTableFrame.LINFrameIdentifier=SM1ID;
  LINScheduleTable[2].LINScheduleTableFrame.LINFrameDirection=TRANSMIT;
  LINScheduleTable[2].LINScheduleTableFrame.LINFrameDataLength=4;
  LINScheduleTable[2].LINScheduleTableFrame.LINFrameBuffer[0]=0;
  LINScheduleTable[2].LINScheduleTableFrame.LINFrameBuffer[1]=0;
  LINScheduleTable[2].LINScheduleTableFrame.LINFrameBuffer[2]=0;
  LINScheduleTable[2].LINScheduleTableFrame.LINFrameBuffer[3]=0;

  LINScheduleTable[3].LINScheduleTableFrame.LINFrameIdentifier=SM3ID;
  LINScheduleTable[3].LINScheduleTableFrame.LINFrameDirection=RECEIVE;
  LINScheduleTable[3].LINScheduleTableFrame.LINFrameDataLength=4;

//  LINScheduleTable[0].LINScheduleTableFrameDelay = DELAY_10MS;
//  LINScheduleTable[1].LINScheduleTableFrameDelay = DELAY_10MS;
//  LINScheduleTable[2].LINScheduleTableFrameDelay = DELAY_10MS;
//  LINScheduleTable[3].LINScheduleTableFrameDelay = DELAY_20MS;

  gLin.DataToSend[0] = 0x70;
  gLin.DataToSend[1] = 0x70;
  gLin.DataToSend[2] = 0x46;
  gLin.DataToSend[3] = 0x19;
  gLin.DataToSend[4] = 0x81;
  gLin.DataToSend[5] = 0x00;
  gLin.DataToSend[6] = 0xf4;
  gLin.DataToSend[7] = 0x1f;
  gLin.DataToSend[8] = 0x00;

}

/**
* @brief  < Add here the function description >
* @note   < OPTIONAL: add here global note >
* @param  None
* @retval None
*/
void LIN_SlaveConfig(void)
{
  GPIO_Init(LIN_TX_PORT, LIN_TX_BIT, GPIO_MODE_IN_PU_NO_IT);	    /*PD5 ����   */
  GPIO_Init(LIN_RX_PORT, LIN_RX_BIT, GPIO_MODE_IN_PU_NO_IT);	    /*PD6 ����   */
  GPIO_Init(LIN_WK_PORT, LIN_WK_BIT, GPIO_MODE_IN_PU_NO_IT);	    /*PD7 ���   */
  //BSET(GPIOD->ODR, GPIO_PIN_4);

  /* Deinitializes the UART3 peripheral */
  UART3_DeInit();

  /* Configure the UART3 */
  UART3_Init((uint32_t)19200, UART3_WORDLENGTH_8D, UART3_STOPBITS_1, UART3_PARITY_NO,UART3_MODE_TXRX_ENABLE);

  UART3_LINBreakDetectionConfig(UART3_LINBREAKDETECTIONLENGTH_11BITS);

#ifdef AUTOMATIC_RESYNCHRO
  UART3_LINConfig(UART3_LIN_MODE_SLAVE, UART3_LIN_AUTOSYNC_ENABLE,UART3_LIN_DIVUP_NEXTRXNE);
#else
  UART3_LINConfig(UART3_LIN_MODE_SLAVE, UART3_LIN_AUTOSYNC_DISABLE,UART3_LIN_DIVUP_LBRR1);
#endif

  UART3_LINCmd(ENABLE); /* Enable LIN mode */

  ITC_SetSoftwarePriority(ITC_IRQ_UART3_RX,ITC_PRIORITYLEVEL_1); /* �����ж� ���ȼ�1*/

  /* Enable UART3 Receive interrupt */
  UART3_ITConfig(UART3_IT_RXNE_OR, ENABLE);
}

/**
* @brief  < Add here the function description >
* @note   < OPTIONAL: add here global note >
* @param  None
* @retval None
*/
void APP_LIN_Task(void)
{
  gLin.LINSlave = TRUE;
  /* LIN Master mode demo or test mode */
  if (gLin.LINSlave==FALSE)
  {
    ;
  }
  /* LIN Slave test mode */
  else
  {
    /* ----------- */
    /* Slave mode */
    /* ----------- */

    if (LINReceptionTimeoutElapsed())
    {
      StopLINReceptionTimeout();
      LIN_FSM = Idle;
    }

    switch ((LIN_FSM_state)LIN_FSM)
    {
      /* ------------- */
      /* STATE Idle :  */
      /* ------------- */
    case Idle:
      /* Set mute mode */
      //FG_ONOFF;

      #ifdef MUTE_MODE
      UART3_ReceiverWakeUpCmd(ENABLE); /* set LINUART mute mode */
      #endif
      LIN_FSM = Identifier;

      ResponseDataByteIndex=0;


      break;

      /* ------------------------------------------ */
      /* STATE IDField : Waiting for ID Field 			*/
      /* ------------------------------------------ */
    case Identifier:
      if (gLin.HeaderReceived&!gLin.ReceptionError&!gLin.IdentifierParityError) /*���յ����ģ�û�д���*/
      {
        gLin.HeaderReceived=0;
        /* Store ID for enhanced checksum calculation */
        LINChecksumBuffer[0] = gLin.UART3Data;
        ResponseDataByteIndex=1; /* index for 1st data */
        StartLINReceptionTimeout();
        switch (gLin.UART3Data)
        {
          case MS0ID:     /*0X3B �ٶȸ��� 4���ֽ�*/
            LIN_FSM = DataReception;
            DLC = 3;
            break;

          case SM1ID:    /*0X1B �ӻ���Ӧ���� 8���ֽ�*/
//            for (Index=0;Index<8;Index++)
//            {
//              DataToSend[Index]=DataBuffer[1][Index];
//            }
            LIN_FSM = DataTransmission;
            DLC = 8;
            break;

          case MS2ID:

            LIN_FSM = DataReception;
            DLC = 8;
            break;

          case SM3ID:
            for (Index=0;Index<8;Index++)
            {
              gLin.DataToSend[Index]=DataBuffer[3][Index];
            }
            LIN_FSM = DataTransmission;
            DLC=4;
            break;

          default: /* Discard response */
            LIN_FSM = Idle;
            break;

          }	/* switch (UART3Data) */
        }
        else if (gLin.ReceptionError|gLin.IdentifierParityError)
        {
          gLin.ReceptionError=0;
          gLin.IdentifierParityError=0;
          LINError();
          LIN_FSM = Idle;
        }

        break;

        /* -------------------------------------*/
        /* STATE DataReception : wait for data  */
        /* ------------------------------------ */
      case DataReception:

        if (gLin.HeaderReceived&!gLin.ReceptionError)
        {
          LIN_FSM = Identifier;
        }
        else if (gLin.DataReceived&!gLin.ReceptionError)
        {
          gLin.DataReceived = 0;
          /* Data reception */
          if (ResponseDataByteIndex < DLC)  /*�������� */
          {
            /* Store Data */
            LINChecksumBuffer[ResponseDataByteIndex] = gLin.UART3Data;
            #ifdef AUTOMATIC_RESYNCHRO
            if (ResponseDataByteIndex == DLC)
            {
              UART3->CR6 |=  UART3_CR6_LDUM;	/* set LDUM bit */
            }
            #endif
            ResponseDataByteIndex++;
          }
          /* End of frame */
          else
          {
            LINChecksumBuffer[ResponseDataByteIndex] = gLin.UART3Data;
            gLin.gLINChecksum = LINChecksum(LINChecksumBuffer,DLC);
            /*У��*/
            if (gLin.gLINChecksum == LINChecksumBuffer[ResponseDataByteIndex])
            {
              if (LINChecksumBuffer[0] == MS0ID)
              {
                gLin.SpeedRef = LINChecksumBuffer[1]&0x7F;/*ת�ٺ���ͣ�źŸ���*/
                gLin.SpeedStart = 0x01&LINChecksumBuffer[2];
                gLin.LostSignalTimCounter = 0;

              }
//              uint8_t i;
//              for (i=0;i<DLC;i++)
//              {
//                if (LINChecksumBuffer[0]==MS0ID)
//                {
//                  DataBuffer[0][i] = LINChecksumBuffer[i+1]; // Store Response
//                }
//                else if (LINChecksumBuffer[0]==SM1ID)
//                {
//                  DataBuffer[2][i] = LINChecksumBuffer[i+1]; // Store Response
//                }
//              }

            }
            else
            {
              LINError();
            }

            LIN_FSM = Idle;
          }

        }
        else if (gLin.ReceptionError)
        {
          gLin.DataReceived=0;
          gLin.ReceptionError=0;
          LINError();
          LIN_FSM = Idle;
        }

        break;

        /* -------------------------------------------- */
        /* STATE DataTransmission : send data	       */
        /* --------------------------------------------	*/
      case DataTransmission:

        if (gLin.HeaderReceived&!gLin.ReceptionError)
        {
          LIN_FSM = Identifier;
        }
        else if (ResponseDataByteIndex==1)  /* �Ѿ����յ� master ���͵� ID*/
        {
          UART3_SendData8(gLin.DataToSend[0]); /* Send 1st data */
          ResponseDataByteIndex++;
        }
        else
        {
          gLin.UART3_SR_Buf = UART3->SR;
          /* Data received ? �Ƿ���ܵ�����*/
          if (gLin.UART3_SR_Buf & UART3_SR_RXNE)
          {
            //FG_ONOFF;
            gLin.DataReceived=1;
          }

          if (gLin.DataReceived)//&!gLin.ReceptionError)
          {
            gLin.DataReceived = 0;
            //FG_ONOFF;

            /* Data transmission */
            if (ResponseDataByteIndex < (DLC+2))
            {
              if (gLin.UART3Data == gLin.DataToSend[ResponseDataByteIndex-2]) /* Check possible bit error */
              {
                LINChecksumBuffer[ResponseDataByteIndex-1]=gLin.UART3Data;
                if (ResponseDataByteIndex==(DLC+1))
                {
                  gLin.DataToSend[ResponseDataByteIndex-1] = LINChecksum(LINChecksumBuffer,(DLC+1));
                  #ifdef AUTOMATIC_RESYNCHRO
                  UART3->CR6 |=  UART3_CR6_LDUM;	/* set LDUM bit */
                  #endif
                }

                UART3_SendData8(gLin.DataToSend[ResponseDataByteIndex-1]); /* Send data */
                ResponseDataByteIndex++;
              }
              else
              {
                LINError();
                LIN_FSM = Idle;
              }
            }
            /* End of frame */
            else
            {
              if (gLin.UART3Data != gLin.DataToSend[ResponseDataByteIndex-2])
              {
                LINError();
              }
              LIN_FSM = Idle;
            }
          }
          else if (gLin.ReceptionError)
          {
            gLin.DataReceived = 0;
            gLin.ReceptionError = 0;
            LINError();
            LIN_FSM = Idle;
          }
          else
          {
            //FG_ONOFF;
          }
        }
        break;
      }
    }
  }


  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  Param1     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @param  Param2     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @retval returntype < Add here the description of the returned value >
  */
  uint8_t LINChecksum (uint8_t* Checksum_Buffer, uint8_t Data_Number)
  {
    uint8_t i=0;
    uint8_t Sum8=0;
    uint16_t Sum16=0;

    for(i=0;i < Data_Number;i++)
    {
      Sum16 = Sum16 + *(Checksum_Buffer+i);
      if(Sum16 > 0xFF)
      {
        Sum16 -= 0XFF;
      }
    }
    Sum8 = Sum16;
    return (uint8_t)(~Sum8);
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  None
  * @retval None
  */
  void UART3_RIE (void)
  {
    /* Disable Break Detection interrupt and
    enable receiver interrupt to read-back Data */
    UART3_ITConfig(UART3_IT_LBDF, DISABLE);
    UART3_ITConfig(UART3_IT_RXNE_OR, ENABLE);
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  None
  * @retval None
  */
  void UART3_BDIE (void)
  {
    /* enable Break Detection interrupt and
    disable receiver interrupt to read-back Break */
    UART3_ITConfig(UART3_IT_RXNE_OR, DISABLE);
    UART3_ITConfig(UART3_IT_LBDF, ENABLE);
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  Param1     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @param  Param2     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @retval returntype < Add here the description of the returned value >
  */
  uint8_t LIN_ReadData(uint8_t FrameNumber, uint8_t BytePosition)
  {
    if (gLin.LINSlave==FALSE)
    {
      return (LINScheduleTable[FrameNumber].LINScheduleTableFrame.LINFrameBuffer[BytePosition]);
    }
    else
    {
      return (DataBuffer[FrameNumber][BytePosition]);
    }
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  Param1     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @param  Param2     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @retval returntype < Add here the description of the returned value >
  */
  void LIN_WriteData(uint8_t FrameNumber, uint8_t BytePosition, uint8_t Value)
  {
    if (gLin.LINSlave==FALSE)
    {
      LINScheduleTable[FrameNumber].LINScheduleTableFrame.LINFrameBuffer[BytePosition]=Value;
    }
    else
    {
      DataBuffer[FrameNumber][BytePosition]=Value;
    }
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  None
  * @retval None
  */
  void StartLINReceptionTimeout(void)
  {
    gLin.LINReceptionTimeout = TRUE;
    gLin.LINReceptionTimeoutValue = 0;
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  None
  * @retval None
  */
  void StopLINReceptionTimeout(void)
  {
    gLin.LINReceptionTimeout = FALSE;
    gLin.LINReceptionTimeoutValue=0;
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  Param1     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @param  Param2     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @retval returntype < Add here the description of the returned value >
  */

  bool LINReceptionTimeoutElapsed(void)
  {
    if (gLin.LINReceptionTimeoutValue > LIN_SLAVE_RECEPTION_TIMEOUT) /*�ӻ����ܳ�ʱ�ж�*/
    {
      if(!ErrorState) LINError();
      return(TRUE);
    }
    else return (FALSE);
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  None
  * @retval None
  */
  void SetLINTimebaseTick(void)
  {
    LINTick=TRUE;
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  None
  * @retval None
  */
  void ClearLINTimebaseTick(void)
  {
    LINTick=FALSE;
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  None
  * @retval None
  */
  uint8_t TestLINTimebaseTick(void)
  {
    if (LINTick) return 1;
    else return 0;
  }

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  None
  * @retval None
  */
  void LINError(void)
  {
    //GPIO_WriteHigh(GPIOA, (GPIO_Pin_TypeDef)GPIO_PIN_3); /* LD3 red LED ON */
  }

u16 tempSpeedRef;


/**
  * @fn    void MCL_ModuleInit(void)
  * @brief �������ģ���ʼ��



  * @par Parameters:
  * @retval void None
  */

void APP_Lin_Calc(void)
{
  if(gLin.LostSignalTimCounter >= 30) /*3��û�н��յ���ȷ��LIN����*/
  {
    gLin.LostSignalTimCounter = 30;
    if(Ui.Fb.LostSignalTimCunter == 0)  /* û��LIN ��FB����  ȫ������*/
    {
      Ui.OnOffFilterCounter++;
      Ctl.Spd.UiRefTar = SPEED_MAX_SEF_TEMP;
    }
    else
    {
      Ui.OnOffFilterCounter--;
    }
  }
  else  /* lin����*/
  {
    if(((LIN_FSM_state)LIN_FSM) != DataTransmission)  /*���͹����� ���ټ��㷢��ֵ*/
    {
      /* master �ٶȸ���*/
      if((gLin.SpeedStart == 0)&&((gLin.SpeedRef&0X7F) != 0))
      {
        Ui.OnOffFilterCounter++;
      }
      else
      {
        Ui.OnOffFilterCounter--;
      }

      /* TEMP �¶ȱ�������С�ڵ���F3,ȫ������*/
      if((Ctl.Fail.OHLevel == 0xF3)||(Ctl.Fail.OHLevel == 0xF2))
      {
        Ctl.Spd.UiRefTar = SPEED_MAX_SEF_TEMP;
        gLin.SpeedRef = gLin.SpeedRef|0x80;
      }
      else
      {
        tempSpeedRef = (u16)(gLin.SpeedRef&0x7F)<<5;
        Ctl.Spd.UiRefTar = IQmpy(tempSpeedRef,SPEED_SCALER_A) + SPEED_SCALER_B;
      }

      /* slave ��Ϣ���� */
      if(Drv.MduCalcFlag == (u8)9)      /*����ת�� ���λ��0*/
      {
        gLin.DataToSend[0] = gLin.SpeedRef;
      }
      else if(Drv.MduCalcFlag == (u8)10) /*����ת��*/
      {
        gLin.DataToSend[1] = Ctl.Spd.FdbSpeedRpm/20.866;
      }
      else if(Drv.MduCalcFlag == (u8)11) /*������ѹ*/
      {
        gLin.DataToSend[2] = Drv.AdcMeas.VdcAvgMeas/5.146; //54  70  6.67
      }
      else if(Drv.MduCalcFlag == (u8)12) /*��������*/ //8.3A->15  10->19  22A->36  
      {
        if(Ctl.State == MOTOR_NORMAL)
        {
          if(Drv.AdcMeas.Ibus < 1.0)
          {
            gLin.DataToSend[3] = 1;
          }
          else
          {  
            gLin.DataToSend[3] = Drv.AdcMeas.Ibus/1.7;
          }
        }
        else
        {  
          gLin.DataToSend[3] = Drv.AdcMeas.Ibus/1.7;
        }
      }
      else if(Drv.MduCalcFlag == (u8)13) /*�����¶�*/
      {
        gLin.DataToSend[4] = Drv.AdcMeas.Th2;
      }
      else if(Drv.MduCalcFlag == (u8)14) /*��������*/
      {
        /*
        Ƿ��ѹ ->  0x40
        ��ת   ->  0x44
        ����   ->  0x68
        */
        if((Ctl.SysError.Code == E_OV)||(Ctl.SysError.Code == E_UV))
        {
          gLin.DataToSend[5] = 0x40;
        }
        else if(Ctl.SysError.Code == E_OH1)
        {
          gLin.DataToSend[5] = 0x68;
        }
        else if(Ctl.Vtim.FailureTimCounter >= 600)
        {
          Ctl.Vtim.FailureTimCounter = 600;
          gLin.DataToSend[5] = 0x44;
        }        
        else if(Ctl.Vtim.NormalTimCounter >= (u16)1000) /*��������1����������*/
        {
          gLin.DataToSend[5] = 0;
        }
      }
      else
      {
      
      }
    }
  }
}

/**
* @brief  UART3 RX interrupt routine.
* @param  None
* @retval None
*/
//INTERRUPT_HANDLER(UART3_RX_IRQHandler, 21)
//{
//  /* In order to detect unexpected events during development,
//  it is recommended to set a breakpoint on the following instruction.
//  */
//  gLin.UART3_SR_Buf = UART3->SR;
//  gLin.UART3Data = UART3->DR;
//
//  if (gLin.LINSlave == TRUE)
//  {
//    /* Header received ?  �Ƿ��⵽���� ͷ  0x55*/
//    if (UART3->CR6 & UART3_CR6_LHDF)
//    {
//      UART3->CR6 &= ~UART3_CR6_LHDF;       /* Reset LHDF flag */
//      gLin.HeaderReceived = 1;
//      gLin.DataReceived = 0;               /* remove limitation when mute mode disabled and del lentgh=23.9-bit */
//      gLin.IdentifierParityError = gLin.UART3_SR_Buf&0x01;
//    }
//    else
//    {
//      /* Header error ?  ����ͷ������*/
//      if (gLin.UART3_SR_Buf & UART3_SR_OR) /* UART3_SR_OR is same bit as UART3_SR_LHE */
//      {
//        UART3->CR6 &= ~UART3_CR6_LSF;      /* clear LSF flag */
//        gLin.ReceptionError = 1;
//      }
//
//      /* Data received ? �Ƿ���ܵ�����*/
//      if (gLin.UART3_SR_Buf & UART3_SR_RXNE)
//      {
//        gLin.DataReceived = 1;
//      }
//    }
//  }
//}
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/



