/**
  ******************************************************************************
  * @file    \USER\src\MC_Init.c
  * @author  tom.wang Application Team
  * @version
  * @since
  * @date    2018-10-17
  * @note
  * @brief   ������ʼ���ļ�
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
u8 APP_CheckUniqueID(void);                   /*!<  ID����У��*/
void Get_Unique_Device_ID(void);             /*!<  ��ȡоƬID*/
void Formula_039(u8 *D,u8 *Result);           /*!<  �����㷨 101*/
u16 Formula_CRC16(u8 *p,u8 len);               /*!<  CRC ����*/

u8 UidCheckValue;
u8 Unique_ID[12],Unique_IDdata[12];           /*!<  оƬID*/
u8 UID_Password[4],UID_PasswordReadFlash[4];  /*!<  ��Կ*/
typedef union { u8 U8[4]; u32 U32; }UID_Constant_Type;
UID_Constant_Type UID_Constant;
u16 Fml_CRC16;    


/**
  * @fn   void Get_Unique_Device_ID()
  * @brief
  * @par Parameters:
  * @retval void None
  */
/* JK-FABL032  
30 35 37 31 
32 47 38 32
30 30 35 36
*/
#define FLASH_UNIQUE_ID_ADDRESS  0x48CD
#define FLASH_PASSWORD_ADDRESS   0x4100
#pragma optimize=none  //speed  size ,  low,medium, high,

void Get_Unique_Device_ID(void)
{
  UID_Constant.U32 = 0x20190818;                      /* ��Կ����*/
  UID_PasswordReadFlash[0] = (*((u8*)FLASH_PASSWORD_ADDRESS+0));
  UID_PasswordReadFlash[1] = (*((u8*)FLASH_PASSWORD_ADDRESS+1));
  UID_PasswordReadFlash[2] = (*((u8*)FLASH_PASSWORD_ADDRESS+2));
  UID_PasswordReadFlash[3] = (*((u8*)FLASH_PASSWORD_ADDRESS+3));
  
  Unique_ID[0] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+0));  /* 0x48CD wafer XL*/
  Unique_ID[1] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+1));  /* 0x48CE wafer XH*/
  Unique_ID[2] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+2));  /* 0x48CF wafer YH*/
  Unique_ID[3] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+3));  /* 0x48D0 wafer YL*/
  Unique_ID[4] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+4));  /* 0x48D1 wafer Number*/
  Unique_ID[5] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+5));  /* 0X48D2 Lot number*/
  Unique_ID[6] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+6));  /* 0X48D3 Lot number*/
  Unique_ID[7] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+7));  /* 0X48D4 Lot number*/
  Unique_ID[8] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+8));  /* 0X48D5 Lot number*/
  Unique_ID[9] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+9));  /* 0X48D6 Lot number*/
  Unique_ID[10] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+10));/* 0X48D7 Lot number*/
  Unique_ID[11] = (*((u8*)FLASH_UNIQUE_ID_ADDRESS+11));/* 0X48D8 Lot number*/
  
  Unique_IDdata[4] = Unique_ID[0];
  Unique_IDdata[5] = Unique_ID[1];
  Unique_IDdata[6] = Unique_ID[2];
  Unique_IDdata[7] = Unique_ID[3];
  
  Unique_IDdata[0] = Unique_ID[4];
  Unique_IDdata[1] = Unique_ID[5];
  Unique_IDdata[2] = Unique_ID[6];
  Unique_IDdata[3] = Unique_ID[7];
  
  Unique_IDdata[8] = Unique_ID[8];
  Unique_IDdata[9] = Unique_ID[9];
  Unique_IDdata[10] = Unique_ID[10];
  Unique_IDdata[11] = Unique_ID[11];
  
  Formula_039(&(Unique_IDdata[0]),&UID_Password[0]);      /*ID����*/  
  UidCheckValue = APP_CheckUniqueID();                    /*��ԿУ��*/
}

/**
  * @fn   void APP_CheckUniqueID()
  * @brief
  * @par Parameters:
  * @retval void None
  */

u8 APP_CheckUniqueID(void)
{  
  if((UID_PasswordReadFlash[0] == UID_Password[0])
     &&(UID_PasswordReadFlash[1] == UID_Password[1])  
       &&(UID_PasswordReadFlash[2] == UID_Password[2]) 
         &&(UID_PasswordReadFlash[3] == UID_Password[3]))
  {
    return 1;;
  }
  else
  {
    return 0;
  }
}

/******************************************************************** 
�������ܣ�CRC16 ����(�˺������ǹ�ʽ,���������һ�ٶ�����ʽ����Щ����ô˺�������
������,ʵ��Ӧ��ʱ�������ѵĳ����м���) 
��ڲ�����p Ϊ����ָ�룬len Ϊ���ݳ���
�� �أ�8 λ���
�� ע��
********************************************************************/ 
u16 Formula_CRC16(u8 *p,u8 len) 
{ 
  u8 i; 
  while(len--) 
  { 
    for(i=0x80; i!=0; i>>=1) 
    { 
      if((Fml_CRC16 & 0x8000) != 0) 
      { 
        Fml_CRC16 <<= 1; 
        Fml_CRC16 ^= 0x1021; 
      } 
      else 
      { 
        Fml_CRC16 <<= 1; 
      } 
      if((*p&i)!=0) 
      { 
        Fml_CRC16 ^= (u16)0x1021; 
      } 
    } 
    p++; 
  } 
  return Fml_CRC16;
}

/******************************************************************** 
�������ܣ���ʽ 39
��ڲ�����D 
********************************************************************/ 
void Formula_039(u8 *D,u8 *Result) 
{ 
  Result[0] = UID_Constant.U8[3] ^ D[0] | D[1] ^ D[2] & D[3] ^ D[4] | D[5] ; 
  Result[1] = UID_Constant.U8[2] ^ D[6] ^ D[7] ^ D[8] ^ D[9] ^ D[10] ^ D[11] ; 
  Result[2] = UID_Constant.U8[1] ^ D[6] | D[1] ^ D[7] & D[3] ^ D[9] | D[5] ; 
  Result[3] = UID_Constant.U8[0] ^ D[8] ^ D[7] ^ D[8] ^ D[2] ^ D[10] ^ D[1] ; 
}

