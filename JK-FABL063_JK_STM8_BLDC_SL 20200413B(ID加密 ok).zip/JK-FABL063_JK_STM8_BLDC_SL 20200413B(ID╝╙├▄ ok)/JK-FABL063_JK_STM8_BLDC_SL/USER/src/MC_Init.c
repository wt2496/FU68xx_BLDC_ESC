/**
  ******************************************************************************
  * @file    \USER\src\MC_Init.c 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   ������ʼ���ļ�
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 


/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "Bsp_Pwmin.h"
#include "Bsp_Uart3.h"
#include "MC_DMC.h" 
#include "MC_init.h" 
#include "MC_UserInterface.h"
#include "MC_MotorCotrol.h"  
#include "MC_MotorDrive.h" 

#define MEM_ROP_EN         (0)            /* �������ܣ�������ʹ�� */
#define FWS_EN             (1)            /* FLASH wait  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
void GPIO_Config(void);
void Int_Config(void);
void MCL_ModuleInit(void);
void MCL_ModuleDefault(void);
void gDelayus(u16 timer);
void gDelayms(u16 timer);
void SoftwareInit(void);
void Set_OptionByte(void);
void BSP_FeedDog(void);
void APP_GetMainLoopTim(void);
void APP_RstMainLoopTim(void);
void APP_Flash_Save_Data(void);

extern void Get_Unique_Device_ID(void);   
extern u8 APP_CheckUniqueID(void);

extern u8 UidCheckValue,UID_Password[],UID_PasswordReadFlash[]; 
OPT_BYTE_TypeDef Opt;
extern u8 tBemfAdcSwitch;
extern u8 tPowerOnFlag; /*JK-FABL039 ��ʱ�����������ж��ϵ�PWMIN������ �ϵ�X��5%��������*/

/**
  * @fn void Clk_Config(void)  
  * @brief ��������
  * @retval None
  */
void Clk_Config(void)  
{    
  #if(0)
  //CLK_DeInit();
  CLK_HSECmd(ENABLE);                                       
  while(SET != CLK_GetFlagStatus(CLK_FLAG_HSERDY)) {};        
  CLK_ClockSwitchConfig(CLK_SWITCHMODE_MANUAL, CLK_SOURCE_HSE, DISABLE,CLK_CURRENTCLOCKSTATE_DISABLE); /*��HSE ���ر�����ʱ�� Ϊ�Զ�ģʽ  */
  CLK_ClockSwitchCmd(ENABLE);                            
  CLK_SYSCLKConfig(CLK_PRESCALER_CPUDIV1);                

  #elif(1)
  CLK_DeInit();
  CLK_HSECmd(ENABLE);                                     
  CLK_LSICmd(ENABLE);                                      
  CLK_HSICmd(ENABLE);                                  
  while(SET != CLK_GetFlagStatus(CLK_FLAG_HSERDY)) {};     
 
  CLK_ClockSwitchCmd(ENABLE);                             
  CLK_ClockSwitchConfig(CLK_SWITCHMODE_MANUAL,CLK_SOURCE_HSE,DISABLE,CLK_CURRENTCLOCKSTATE_DISABLE); 
  CLK_SYSCLKConfig(CLK_PRESCALER_CPUDIV1);          
  #else
  
  CLK_DeInit();
  /* Clock divider to HSI/1 */
  CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
  
  /* Output Fcpu on CLK_CCO pin */
  #endif
  
//  gDelayms(1000);
//  gDelayms(1000);
//  gDelayms(500);
  
  /*���Ź����� by lhj*/
  /*IWDG->KR = 0x55;*/
  /*
  0 62.5uS-15.9mS
  1 125uS-31.9mS
  2 250uS-63.7mS
  3 500uS-127mS
  4 1mS-255mS
  5 2ms-510mS
  6 4mS-1.02S
  */
  
  #if 0
    IWDG->KR = 0xCC;  /*Ҫ��ʹ�ܲ�������*/
    IWDG->KR = 0x55;
    IWDG->PR = 6; 
    IWDG->RLR = 0xFF; /*�ʱ��*/
    IWDG->KR = 0xAA;
  #else  
    WWDG->CR = (uint8_t)0xFF; /*ʹ�ܴ��ڿ��Ź� 12288��fckc_wwdg_ck���ڵݼ�һ��  (1/16000000)*12288*0x40=49.152mS   ��ʱʱ����49mS*/
    WWDG->WR = (uint8_t)0x7F; /*���ô�����CR���ֵһ���������κ�ʱ����ι��*/
  #endif
}

/**
  * @fn    void SoftwareInit(void)
  * @brief ��ʼ��
  * @par Parameters:
  * @retval void None
  */
void SoftwareInit(void)
{
  disableInterrupts();
  Ctl.SysError.Code = NONE;
  /* clk configuration */
  Clk_Config();  

  /* GPIO Configuration   */ 
  GPIO_Config();          
  
  gDelayms(15);
  BSP_FeedDog();
  /* INT  Configuration   */
  /*Int_Config();         */
  /* ADC  Configuration   */
  ADC_Config();
  /* Time1 Configuration  */ 
  TIM1_Config();
  /* Time2 Configuration  */ 
  TIM2_Config();  
  
  //Uart3_Config();
  
  BSP_PwmIn_Init();
  
  /* ��ȫ���ж�   */ 
  enableInterrupts();
  
  Get_Unique_Device_ID();
}

/**
  * @fn    void GPIO_Config(void)
  * @brief IO�ڳ�ʼ��
  * @par Parameters:
  * @retval void None
  */
void GPIO_Config(void)
{
  GPIO_Init(UL_PORT, UL_BIT, GPIO_MODE_OUT_PP_LOW_FAST);
  GPIO_Init(VL_PORT, VL_BIT, GPIO_MODE_OUT_PP_LOW_FAST);
  GPIO_Init(WL_PORT, WL_BIT, GPIO_MODE_OUT_PP_LOW_FAST);

  GPIO_Init(UH_PORT, UH_BIT, GPIO_MODE_OUT_PP_HIGH_FAST);
  GPIO_Init(VH_PORT, VH_BIT, GPIO_MODE_OUT_PP_HIGH_FAST);
  GPIO_Init(WH_PORT, WH_BIT, GPIO_MODE_OUT_PP_HIGH_FAST);	

  UL_GPIO_OFF();
  VL_GPIO_OFF();
  WL_GPIO_OFF();

  UH_GPIO_OFF();
  VH_GPIO_OFF();
  WH_GPIO_OFF();
  
  GPIO_Init(TLE7184_ERR_PORT, TLE7184_ERR_BIT, GPIO_MODE_IN_FL_NO_IT); 
  GPIO_Init(TLE7184_INHD_PORT, TLE7184_INHD_BIT, GPIO_MODE_IN_PU_NO_IT);

  BSP_FeedDog();
  gDelayms(10);
  GPIO_Init(TLE7184_RGS_PORT, TLE7184_RGS_BIT, GPIO_MODE_OUT_PP_LOW_FAST);  
  TLE7184_RGS_OFF;
  gDelayus(10);
  TLE7184_RGS_ON; /* ���ERR */
  gDelayms(10);
  TLE7184_RGS_OFF;
  gDelayus(10);
  TLE7184_RGS_ON; /* ���ERR */
  BSP_FeedDog();
  GPIO_Init(PWMIN_PORT, PWMIN_BIT, GPIO_MODE_IN_PU_NO_IT);	   /*PD2 PWMIN ����   */
  GPIO_Init(FG_PORT, FG_BIT, GPIO_MODE_OUT_PP_LOW_FAST);	   /*PD6 FB_O */
  GPIO_Init(FB_PORT, FB_BIT, GPIO_MODE_OUT_PP_LOW_FAST);	   /*PB_I �����ź� */
  GPIO_Init(FBIN_PORT, FBIN_BIT, GPIO_MODE_IN_FL_NO_IT);	   /*PD2 PWMIN ??   */ 
  FB_OFF;

}

/**
  * @fn    void Int_Config(void)
  * @brief �ⲿ�жϳ�ʼ��
  *        FO ��ʹ���ⲿ�ж�IO�ڣ�ʹ��TIM1_BRK     
  * @par Parameters:
  * @retval void None
  */
void Int_Config(void) 
{
  /* IO����Ϊ��� */ 
  /*GPIO_Init(GPIOD, GPIO_PIN_0, GPIO_MODE_IN_FL_IT); */
  /* GPIOD->DDR &= 0xFE;  PD0���� */
  /*GPIOD->CR1 &= 0xFE;	  PD0��������   */
  /*GPIOD->CR2 |= 0x01;   ʹ���ⲿ�ж�  */
          
  /*EXTI->CR1 	= 0x40;   PD����Ϊ�����ش���  */

  /*ITC->ISPR2 &= ~0x30; */	
  /*ITC->ISPR2 |=  0x20;  PD0��Ϊ�����ⲿ�жϿڣ����ȼ�Ϊ2��TIM1_CAP_COM���ȼ�Ϊ1�� */

}

/**
  * @fn    void MCL_ModuleInit(void)
  * @brief �������ģ���ʼ��  �ϵ��ʼ��
  * @par Parameters:
  * @retval void None
  */
void MCL_ModuleInit(void)
{
  tPowerOnFlag = 0;                  /*JK-FABL039 �ϵ�����*/
  
  Ctl.gStopmodeC = STOPMODE;
    
  Drv.AdcMeas.VdcBemfOffsetTar = VDC_OFFSETT_SET;
  Drv.AdcMeas.VdcBemfOffsetCur = VDC_OFFSETT_SET;  
  
  Ui.OnOffFilterCounter = 0;
  Ui.flg.FR = MOTOR_DIRECTION ; 
  Ui.Pwmin.SignalTimCunter = 0;
  Ui.Pwmin.LostSignalFlag = 0x7F;
  Ui.Fb.LostSignalTimCunter = 0;
  Ui.Fb.LostSignalFlag = 0;  /*0x71 FBû�ж��ߣ� 0x72 FB����*/
  
  Drv.PWM.Period = PWM_PERIOD;
  Drv.PWM.DutyMax = MOTOR_VS_MAX;
  Drv.PWM.DutyMin = MOTOR_VS_MIN;
  Drv.PWM.DutyLimitValue = (s16)(LIMIT_DUTYINCDEC);  
  Drv.PWM.DutyLimitMaxRefH = (s16)(MECASECURRENTLIMITMAXREF*1.01);    
  Drv.PWM.DutyLimitMaxRefL = (s16)(MECASECURRENTLIMITMAXREF*0.99);     
  Drv.AdcMeas.VdcSumMeas = 0;
  Drv.TLE7184.Errfilter = 0;
  
  Ctl.Alig.timNms = ALIGNMENTNMS;   /* ��λʱ��  */

  Ctl.Ramp.DutyCur =  IQ(RAMP_DUTY);
  Ctl.Ramp.BemfTureNum = (s8)RAMP_TURE_NUM;  
  Ctl.Ramp.BemfErrNum = 100;
  Ctl.Ramp.StartABSwitchNum = RAMP_SWITCH_NUM;        /* ����N�κ�A/B�л�*/
  Ctl.Ramp.StartRiseFallNumA = RAMP_DETECTION_NUM_A;  /* ������*/
  Ctl.Ramp.StartMaskComNumA = RAMP_TIM_MASK_A;        /* ���δ���*/
  Ctl.Ramp.StartRiseFallNumB = RAMP_DETECTION_NUM_B;  /* ������*/
  Ctl.Ramp.StartMaskComNumB = RAMP_TIM_MASK_B;        /* ���δ���*/
  Ctl.Ramp.ForceComTimCurT = RAMP_FORCECOM_TIM_STA;
  Ctl.Ramp.ForceComTimTarT = RAMP_FORCECOM_TIM_TAR; 
  Ctl.Ramp.ForceComTimAccT = RAMP_FORCECOM_TIM_ACC;  
  
  Ctl.Bemf.SingleBemfDetectionStepNex = 1;
  Ctl.Bemf.SingleBemfDetectionStepCur = 12;
  Ctl.Bemf.SingleBemfDetectionStepPre = 11; 
  Ctl.Bemf.StartVdcBemfOffsetCur = 0;
  Ctl.Bemf.StartVdcBemfOffsetCurRise = START_VDC_RISE_OFFSETT_SET;
  Ctl.Bemf.StartVdcBemfOffsetCurFall = START_VDC_FALL_OFFSETT_SET;
        
  Ctl.Spd.UiRefMax = SPEED_MAX_SEF_TEMP;
  Ctl.Spd.EventPeriodCur = 0;
  Ctl.Spd.EventPeriodPre = 0;
  Ctl.Spd.EventPeriodErr = 0 ; 
  Ctl.Spd.EventPeriodErrAvg = 0;
  Ctl.Spd.IncValue = SPEED_INCVALUE;
  Ctl.Spd.DecValue = SPEED_DECVALUE;
  Ctl.Spd.SpeedScaler = SPEEDSCALER;
  Ctl.Spd.BaseRpm  = (u16)BASE_SPEED;   /*R10.3*/
  Ctl.Spd.CmdRunDirection = 0;
  Ctl.Spd.CmdRunCwfilter = 0;
  Ctl.Spd.CmdRunCCwfilter = 0;
  Ctl.Spd.CmdRun0filter = 0;
  Ctl.IPD.DsovRestartNum = 0;
  
  Ctl.Vtim.Nonms = (u16)(NONMS-5);
  Ctl.Vtim.FailureTimCounter = 0;
  Ctl.Vtim.OH1nms = 0;
  Ctl.Vtim.OH2nms = 0;
  Ctl.Vtim.OH3nms = 0;
  Ctl.Vtim.OH4nms = 0;
  Ctl.Vtim.OH5nms = 0;

  Ctl.Fail.Sta1RestartNum = 0;
  Ctl.Fail.OHLevel = 0;
  Ctl.State = MOTOR_INIT;
  
  Dmc_SpdPidInit();
}

/**
  * @fn    void MCL_ModuleDefault(void)
  * @brief �������ģ��Ĭ��ֵ
  * @par Parameters:
  * @retval void None
  */
void MCL_ModuleDefault(void)
{
  //Ctl.Spd.CmdRunDirection = 0;
  Ui.KLPwmPCT3Counter = 0;
  Ui.KLPwmPCT97Counter = 0;  
    
  tBemfAdcSwitch = 0xF2;
  /* ����������ʼ�� */  
  Ctl.gStepPre = 0;
  Ctl.gStepCur = 0;
  Ctl.Ramp.ForceComTimCounter = 0;  
  Ctl.Ramp.ComCounter = 0;          /* ����������� */
  Ctl.Ramp.BemfTureCnt = 0;       /* EMF Ture */
  Ctl.Ramp.BemfErrCnt = 0;
  
  Ctl.Nor.ComCounter = 0;
 
  Ctl.Bemf.E60CounterPre = 0;     /* ����ʱ�� */
  Ctl.Bemf.E60CounterCur = 0;     /* ����ʱ�� */
  Ctl.Bemf.RiseFallCounter = 0;   /* ����㵽������� ��ʱ */
  Ctl.Bemf.C3ComNumCur = 0;
  Ctl.Bemf.C3ComNumTar = 0;
  Ctl.Bemf.MaskComNum = RAMP_TIM_MASK_B;
  Ctl.Bemf.RiseFallNum = RAMP_DETECTION_NUM_B;  

  Ctl.Bemf.DetectDirectionStepCounter = 0;
  Ctl.Bemf.DetectDirectionCounterCur = 0;  
  
  if(Ctl.gDirectionC == CW)
  {
    Ctl.Bemf.SingleBemfDetectionStepNex = 1;
    Ctl.Bemf.SingleBemfDetectionStepCur = 12;
    Ctl.Bemf.SingleBemfDetectionStepPre = 11;
  }
  else
  {
    Ctl.Bemf.SingleBemfDetectionStepNex = 5;
    Ctl.Bemf.SingleBemfDetectionStepCur = 6;
    Ctl.Bemf.SingleBemfDetectionStepPre = 7;
  }  
  /*  
  Drv.Spd.EventPeriodCur = 0;
  Drv.Spd.EventPeriodPre = 0;
  Drv.Spd.EventPeriodErr = 0 ;  
  */
  Ctl.Vtim.STA2TimCounter = 0;
  Ctl.Vtim.STB1TimCounter = 0;
  Ctl.Vtim.NormalTimCounter = 0;
  Ctl.Vtim.SensorlessStartTimCounter = 0;
  Ctl.Vtim.STRestartCounter = 0;
  Ctl.Vtim.STRestartTim = 5000; /*��ת�������ʱ�䣬*/
  Ctl.Vtim.BrakewaitNms = 0;
  Ctl.Vtim.BrakeNum = 0;
  
  Drv.AdcMeas.ChannelChoice = 12;
  Drv.AdcMeas.VdcBemfOffset = 0;  
  Drv.AdcMeas.VdcBemfOffsetTar = 1;
  Drv.AdcMeas.VdcBemfOffsetCur = 1;
    
  Ctl.Spd.Shift = 3;
  Ctl.Spd.SlowingDownFlag = 0X7F;
  Ctl.Spd.RefCur = 0;
  Ctl.Spd.RefTar = 0;
  Ctl.Spd.EventPeriodErr = 0;
  Ctl.Spd.EventPeriodErrAvg = 0;
  Ctl.Spd.EventPeriodErrSum = 0;
  
  Ctl.Spd.FdbSpeed = 0;
  Dmc_SpdPidDefault();
//  Ctl.Spd.CmdRunCwfilter = 0;
//  Ctl.Spd.CmdRunCCwfilter = 0;
//  Ctl.Spd.CmdRun0filter = 0;   
  
  Drv.PWM.DutyCur = 0;
  Drv.PWM.DutyLimitValue = (s16)(LIMIT_DUTYINCDEC);  
  Drv.PWM.DutyLimitMaxRefH = (s16)(MECASECURRENTLIMITMAXREF*1.0);    
  Drv.PWM.DutyLimitMaxRefL = (s16)(MECASECURRENTLIMITMAXREF*1.0);    
  
  Ctl.IPD.ErrCur = 0;
  Drv.TLE7184.Errfilter = 0;
  Drv_7184ClearError();  
}


/**
  * @fn    void gDelayus(u16 timer) 
  * @brief  1us��ʱ  24mhz ��Ƶ 1.042us+n*1us
  * @par Parameters:
  * @retval void None
  */
//#pragma optimize=none // none  //high 
void gDelayus(u16 timer)
{
  /* while(timer--) */
  for(;timer > (u16)0; timer--)
  {
    nop();nop();nop();nop();nop();
    nop();nop();nop();nop();nop();
    nop();nop();nop();nop();
    //nop();nop();
  }
}


/**
  * @fn   void gDelayms(u16 timer)
  * @brief 1ms ��ʱ
  * @par Parameters:
  * @retval void None
  */
//#pragma optimize=none  //high 
void gDelayms(u16 timer)
{
  /* while(timer--) */
  for(;timer > (u16)0; timer--)  
  {
    gDelayus((u16)999);
  }
}

/**
  * @fn   void Set_OptionByte()
  * @brief 
  * @par Parameters:
  * @retval void None
  */
void Set_OptionByte(void)
{
  Opt.Flag = FLASH_ReadByte(0x4000);  
  
  if(Opt.Flag != (u8)0x7f)
  {
    FLASH_Unlock(FLASH_MEMTYPE_DATA);

    while(!(FLASH->IAPSR & FLASH_IAPSR_DUL)) 
    {
      nop();
    };/*�ȴ��������*/

    
    /* Alternate function remapping (AFR)*/
    /*
    Opt.AFR = FLASH_ReadOptionByte(0x4803);  
    
    if((Opt.AFR&0x0200)==FALSE)
    {  
      FLASH_ProgramOptionByte(0x4803,0x28);
    }
    */
    #if(MEM_ROP_EN)
    Opt.ROP = FLASH_ReadOptionByte(0x4800); /*Read-out protection (ROP)*/
    
    if((Opt.ROP)==FALSE)
    {  
      FLASH_ProgramOptionByte(0x4800,0xAA);
    }  
    #endif
   
    #if(FWS_EN)
    Opt.ROP = FLASH_ReadOptionByte(0x480D); /*Read-out protection (ROP)*/
    
    if((Opt.ROP&(u16)0x0100)==FALSE)
    {  
      FLASH_ProgramOptionByte(0x480D,0x01);
    }  
    
    Opt.ROP = FLASH_ReadOptionByte(0x480D); /*Read-out protection (ROP)*/
    #endif
    
    Opt.Flag = FLASH_ReadByte(0x4000);
    FLASH_ProgramByte(0x4000,0x7F);  
   
    FLASH_Lock(FLASH_MEMTYPE_DATA); 
  }
}

/*
20190604 ���� 
1.����дEEROMдһ���ֽ�2.5~5.5ms
2.EEROM�����ݲ��ò���������ֱ��д��
3.�ᴥ��L99��λ��
*/
#if(0)
#define EEPROM_STARTADDR 0x4000 
#pragma optimize=none  //speed  size ,  low,medium, high,
void APP_Flash_Save_Data(void)
{
  u8 Len;
  
  u8 *pData;
  u8 *PtrSegAddr;

  Len = 6;  /*34*/
   
  disableInterrupts();                             /*�ر��ж�*/
  
  WWDG->CR = (uint8_t)0x0;                         /*�رտ��Ź�*/

  pData = &(Ctl.E_message.ErrorF);                 /*��ȡ�׵�ַ*/
  
  PtrSegAddr = (u8*)(EEPROM_STARTADDR);            /*pָ��ָ��EEPROM ��Ӧ�ĵ�Ԫ*/  
  
  FLASH_Unlock(FLASH_MEMTYPE_DATA);                /*����*/
  
  while(!(FLASH->IAPSR & FLASH_IAPSR_DUL)) nop();;/*�ȴ��������*/
  
  for( ; Len > 0; Len--)                          /*�洢����*/
  {
    *PtrSegAddr++ = *pData++;                     /*2ms~6ms*/
    BSP_FeedDog();                                /*ι��*/
  } 
  
  FLASH_Lock(FLASH_MEMTYPE_DATA);                 /*����*/
  Ctl.E_message.ErrorF   = 1;                     /*���ϴ洢���*/
  
  enableInterrupts();                             /*���ж�*/
}    
#endif

void BSP_FeedDog(void)
{
  /*IWDG->KR = 0xAA;*/
  WWDG->CR = (uint8_t)0xFF; /*ʹ�ܴ��ڿ��Ź� ��ʱʱ����49mS  ���ڿ��Ź�����ͨ��opt������haltʱ����λ*/
}


void APP_GetMainLoopTim(void)
{
  Ctl.Vtim.MainLoopTim = Ctl.Vtim.MainLoopCounter;
  if(UID_PasswordReadFlash[0] != UID_Password[0])
  {
    #if(ID_EN)
    Ui.flg.START = (u8)FALSE;
    Ctl.State = MOTOR_FAILURE;   
    #endif
  }  
}

void APP_RstMainLoopTim(void)
{
  Ctl.Vtim.MainLoopCounter = 0;
  if(UID_PasswordReadFlash[0] != UID_Password[0])
  {
    #if(ID_EN)
    Ui.flg.START = (u8)FALSE;
    Ctl.State = MOTOR_FAILURE;   
    #endif
  }
}
/**
  * @fn   void fputc()  
  * @brief ��printf ���¶���
  * @par Parameters:
  * @retval void None
  *  https://blog.csdn.net/gang_life/article/details/50763176
  */

/*
int fputc(int ch, FILE *f)
{ 
  while (!(UART2->SR&0x80)); 
  UART2->DR=ch;
  return ch; 
} 
*/


