/**
  ******************************************************************************
  * @file    \USER\src\MC_MotorDrive.c 
  * @author  Application Team  Tom.wang 
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   ���������
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 

/* Includes --- ---------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "MC_DMC.h" 
#include "MC_stm8Adc.h"
#include "MC_UserInterface.h"
#include "MC_MotorCotrol.h"  
#include "MC_MotorDrive.h" 
#include "TTech_BLDC.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/**  
 *  @brief �������������ṹ�� 
*/
DRV_TypeDef Drv; 
u8 tBemfAdcSwitch;
u16 tBemfAdcSwitchCounter;

extern u8 volatile gDetectMode; 
extern void gDelayus(u16 timer);
extern void gAdcSampleCapacitorsDelay(void);
/* Private function prototypes -----------------------------------------------*/
void Drv_BemftCalc(void);
void Drv_SpeedRampCale(void);
void Drv_Commutation(s8 Step);
void Drv_PwmUpdate(void);
void Drv_Tim2CalcPeriod (void);
void Drv_SpdClosed(void);
void Drv_SpdClosedPro(void);
void Drv_BemfPhaseChoice(s8 Step);
void Drv_OverSpd (void);
void Drv_SpeedClac(void);
void BemfC3ComNumCurCalc(void);
void Drv_MotorSelfInspection(void);
void Drv_7184ClearError(void);

static void tMotorSelfInspectionFunction1(void);
static void tMotorSelfInspectionFunction2(u8 phaseX);
static void tMotorSelfInspectionFunction3(void);

/* Private functions ---------------------------------------------------------*/

/**
  * @fn     void Drv_BemftCalc(void)    
  * @brief  Bemf����   
  * @retval None
  */
void Drv_BemftCalc(void)
{     
  Ctl.Bemf.E60CounterCur++;
  Ctl.Bemf.E360CounterCur++;
                                                             
  if(Ctl.State == MOTOR_OPENLOOP)
  {
    Drv_SmartStartCalc();  
  }
  else if(Ctl.State == MOTOR_NORMAL)       
  {
    Drv_SmartRumCalc();   
  }
  else  if(Ctl.State == MOTOR_READY)  
  {
    Drv_PosTrack();
    
    if(Ctl.Bemf.E60CounterCur > (u8)10)
    {
      Ctl.Bemf.E60CounterCur = 0;
    }    
  }
  else 
  {
    if(Ctl.Bemf.E60CounterCur > (u8)10)
    {
      Ctl.Bemf.E60CounterCur = 0;
    }
  }
  /*  
  ------------------------------------------
  ������������ѹ���¶Ȳ��� 
  AN3 -> Ibus  AN4 -> Vbus  AN5 -> Tj
  */
  AdcSoftMultichannelScanMode();
  
}

/**
  * @fn     void Drv_Tim2CalcPeriod(void)    
  * @brief  �ٶȼ���  
  * @retval None
  */
void Drv_Tim2CalcPeriod (void)
{
  WORD tempWord;
  u16 tEventPeriodErr;
  
  Ctl.Spd.InputSelect |= (u8)0x11;
  
  tempWord.B.H = TIM2->CNTRH;
  tempWord.B.L = TIM2->CNTRL;
  
  Ctl.Spd.EventPeriodCur = tempWord.W; 
  if((TIM2->SR1&(u8)0x01) != (u8)0)        /*TIM2_FLAG_UPDATE*/
  {
    tEventPeriodErr = 0xFFFF - Ctl.Spd.EventPeriodPre; 
    Ctl.Spd.EventPeriodErr = tEventPeriodErr + Ctl.Spd.EventPeriodCur;
  }
  else
  {
    Ctl.Spd.EventPeriodErr = Ctl.Spd.EventPeriodCur - Ctl.Spd.EventPeriodPre;        
  }
    
  Ctl.Spd.EventPeriodErrSum += Ctl.Spd.EventPeriodErr;
  Ctl.Spd.EventPeriodErrAvg = Ctl.Spd.EventPeriodErrSum>>2;
  Ctl.Spd.EventPeriodErrSum -= Ctl.Spd.EventPeriodErrAvg;
  
  Ctl.Spd.EventPeriodPre = Ctl.Spd.EventPeriodCur;
  
  Ctl.Spd.AngleCalcFlag = 0x7F;
}

/**
  * @fn     void Drv_SpeedClacRpm(void)    
  * @brief  ת�ټ��� 
  * @param[in]  duty s16
  * @retval None
  */
void Drv_SpeedClac(void)
{
  /*if(Ctl.gStepCur != 12)*/
  {
    #if(SPEED_CALC_EN)
    if(Drv.MduCalcFlag == (u8)1)
    {  
      if(Ctl.Spd.EventPeriodErr != (u8)0)
      {
        Ctl.Spd.FdbSpeed = (s16)(Ctl.Spd.SpeedScaler/Ctl.Spd.EventPeriodErrAvg); /*31.0us   s16 = u32/u16*/
      }
      else
      {
        Ctl.Spd.FdbSpeed = 0;
      }
      
      pid_spd.Fdb = Ctl.Spd.FdbSpeed;
    }
    #endif

    #if (SPEED_CALC_EN == 2)
    if(Drv.MduCalcFlag == (u8)2)
    {   
      Ctl.Spd.FdbSpeedRpm = IQmpy(Ctl.Spd.FdbSpeed,Ctl.Spd.BaseRpm);    /*12.6us*/
    }
    #endif
  }
}

/**
  * @fn     void Drv_PwmUpdate(void)    
  * @brief  PWMռ�ձȸ���  ���ռ�ձȷ�Χ��1%~100%��
  *         IQ(1.0) -> 100%  ��Ч��ƽ
  *         IQ(0.0) -> 0%    ��Ч��ƽ   
  * @param[in]  duty s16
  * @retval None
  */
void Drv_PwmUpdate(void)
{ 
  /*Drv.PWM.DutyCur += Ctl.Spd.dutyArray[Ctl.Spd.EventPointerC];*/
  #if(CURRENT_LIMIT_EN)
  if(Drv.PWM.DutyLimitFlag != 0u)                
  {
    Drv.PWM.DutyMax -= Drv.PWM.DutyLimitValue;
    if(Drv.PWM.DutyMax < 1024u)
    {
      Drv.PWM.DutyMax = 1024;
    }
  }
  else
  {
    Drv.PWM.DutyMax += Drv.PWM.DutyLimitValue;
    if(Drv.PWM.DutyMax > MOTOR_VS_MAX)
    {
      Drv.PWM.DutyMax = MOTOR_VS_MAX;
    }
  }   
  #endif
  
  if( Ctl.State != MOTOR_ALIGNMENGT)
  {  
    if(Drv.PWM.DutyCur > Drv.PWM.DutyMax)
    {
      Drv.PWM.Duty.W = IQmpy(Drv.PWM.DutyMax,Drv.PWM.Period);  
    }
    else if(Drv.PWM.DutyCur < Drv.PWM.DutyMin)
    {
      Drv.PWM.Duty.W = IQmpy(Drv.PWM.DutyMin,Drv.PWM.Period);  
    }
    else
    {
      Drv.PWM.Duty.W = IQmpy(Drv.PWM.DutyCur,Drv.PWM.Period);  
    }
  }
  else
  {
    Drv.PWM.Duty.W = IQmpy(Drv.PWM.DutyCur,Drv.PWM.Period); 
  }
  
  
  
  if(Drv.PWM.Duty.W > PWM_PERIOD)
  {
    Drv.PWM.Duty.W = PWM_PERIOD; 
  }
  
  TIM1->CCR1H = Drv.PWM.Duty.B.H;     
  TIM1->CCR1L = Drv.PWM.Duty.B.L;     

  TIM1->CCR2H = Drv.PWM.Duty.B.H;     
  TIM1->CCR2L = Drv.PWM.Duty.B.L;    

  TIM1->CCR3H = Drv.PWM.Duty.B.H;    
  TIM1->CCR3L = Drv.PWM.Duty.B.L;     
}

/**
  * @fn     void Drv_SpeedRampCale(void)    
  * @brief  �Ӽ�������    
  * @retval None
  */
void Drv_SpeedRampCale(void)
{
  /*if((Ctl.State == MOTOR_OPENLOOP)||(Ctl.State == MOTOR_NORMAL))*/
  if(Ctl.State == MOTOR_NORMAL)  
  {
    if((Ctl.Spd.RefTar - Ctl.Spd.RefCur) > Ctl.Spd.IncValue)
    {
      Ctl.Spd.RefCur += Ctl.Spd.IncValue;
    }
    else if((Ctl.Spd.RefCur - Ctl.Spd.RefTar) > Ctl.Spd.DecValue)
    {
      Ctl.Spd.RefCur -= Ctl.Spd.DecValue;
    }
    else
    {
      Ctl.Spd.RefCur = Ctl.Spd.RefTar;
    }
  }
}

/**
  * @fn     void Drv_Commutation(s8 Step)    
  * @brief  12������ ˳�� 
  * @param[in]  Step s8  
  * @retval None
  */
//#pragma optimize=none  //speed  size ,  low,medium, high,
void Drv_Commutation(s8 Step)
{
  if(Ctl.gStepPre != Ctl.gStepCur )
  { 
    FG_ONOFF;
    switch(Step)
    {
      case 0:
        UVWH_PWM_OFF();
        UVWL_GPIO_OFF();
        break;
      case 1:  /*UHWH -> VL */
        UH_PWM_ON();
        VH_PWM_OFF();
        WH_PWM_ON();        
        UL_GPIO_OFF();
        VL_GPIO_ON();
        WL_GPIO_OFF();        
      break;
      case 2:  /*UH   -> VL    W�� */
        UH_PWM_ON();
        VH_PWM_OFF();
        WH_PWM_OFF();        
        UL_GPIO_OFF();
        VL_GPIO_ON();
        WL_GPIO_OFF();    
      break;
      case 3:  /*UH   -> WLVL  */
        UH_PWM_ON();
        VH_PWM_OFF(); 
        WH_PWM_OFF();        
        UL_GPIO_OFF();
        VL_GPIO_ON();
        WL_GPIO_ON(); 
      break;  
      case 4:  /*UH   -> WL    V�� */
        UH_PWM_ON();
        VH_PWM_OFF();
        WH_PWM_OFF();        
        UL_GPIO_OFF();
        VL_GPIO_OFF();
        WL_GPIO_ON();       
      break;       
      case 5:  /*VHUH -> WL  */
        UH_PWM_ON();
        VH_PWM_ON();
        WH_PWM_OFF();        
        UL_GPIO_OFF();
        VL_GPIO_OFF();
        WL_GPIO_ON();       
      break;        
      case 6:  /*VH  -> WL     U�� */
        UH_PWM_OFF();
        VH_PWM_ON();
        WH_PWM_OFF();        
        UL_GPIO_OFF();
        VL_GPIO_OFF();
        WL_GPIO_ON();       
      break;        
      case 7: /*VH   -> ULWL */
        UH_PWM_OFF();
        VH_PWM_ON();
        WH_PWM_OFF();        
        UL_GPIO_ON();
        VL_GPIO_OFF();
        WL_GPIO_ON();      
      break;       
      case 8:  /*VH   -> UL    W�� */
        UH_PWM_OFF();
        VH_PWM_ON();
        WH_PWM_OFF();        
        UL_GPIO_ON();
        VL_GPIO_OFF();
        WL_GPIO_OFF();      
      break;        
      case 9:  /*WHVH -> UL */
        UH_PWM_OFF();
        VH_PWM_ON();
        WH_PWM_ON();        
        UL_GPIO_ON();
        VL_GPIO_OFF();
        WL_GPIO_OFF();      
      break;
      case 10: /*WH   -> UL    V�� */
        UH_PWM_OFF();
        VH_PWM_OFF();
        WH_PWM_ON();        
        UL_GPIO_ON();
        VL_GPIO_OFF();
        WL_GPIO_OFF();         
      break;        
      case 11: /*WU   -> ULVL */
        UH_PWM_OFF();
        VH_PWM_OFF();
        WH_PWM_ON();        
        UL_GPIO_ON();
        VL_GPIO_ON();
        WL_GPIO_OFF();         
      break;         

      case 12:  /*WH   -> VL   U��*/
        UH_PWM_OFF();
        VH_PWM_OFF();
        WH_PWM_ON();        
        UL_GPIO_OFF();
        VL_GPIO_ON();
        WL_GPIO_OFF();         
      break;         
      
      default:
      break; 
    }
    Ctl.gStepPre = Ctl.gStepCur;
  }
}

/**
  * @fn     void Drv_BemfPhaseChoice(s8 Step)    
  * @brief  ѡ��ʹ����һ·ADC����⣬������ 
  * @param[in] Step s8    
  * @retval None
  */
void Drv_BemfPhaseChoice(s8 Step)
{
  switch(Step)
  {
    case 2:    /*UH->VL   W��  */
        ADC2->CSR  = (u8)ADC2_CHANNEL_2;
        ADC2->CR1 |= ADC2_CR1_ADON; 
        Ctl.Bemf.RiseFallFlag = 0;
      break;
    case 4:    /*UH->WL   V�� */
        ADC2->CSR  = (u8)ADC2_CHANNEL_1;
        ADC2->CR1 |= ADC2_CR1_ADON; 
        Ctl.Bemf.RiseFallFlag = 1;
      break;
    case 6:    /*VH->WL   U�� */
        ADC2->CSR  = (u8)ADC2_CHANNEL_0;
        ADC2->CR1 |= ADC2_CR1_ADON;
        Ctl.Bemf.RiseFallFlag = 0;
      break;  
    case 8:   /*VH->UL;   W�� */
        ADC2->CSR  = (u8)ADC2_CHANNEL_2;
        ADC2->CR1 |= ADC2_CR1_ADON;
        Ctl.Bemf.RiseFallFlag = 1;
      break;  
    case 10:   /*WH->UL    V�� */
        ADC2->CSR  = (u8)ADC2_CHANNEL_1;
        ADC2->CR1 |= ADC2_CR1_ADON;
        Ctl.Bemf.RiseFallFlag = 0;
      break; 
    case 12:   /*WH->VL    U�� */
        ADC2->CSR  = (u8)ADC2_CHANNEL_0;
        ADC2->CR1 |= ADC2_CR1_ADON;
        Ctl.Bemf.RiseFallFlag = 1;
      break; 
    default:
      break; 
  } 
  if(Ctl.gDirectionC == CCW)
  {
    Ctl.Bemf.RiseFallFlag ^= (u8)1; /*��־λȡ�� */  
  }
}

/**
  * @fn     void Drv_SpdClosed(void)    
  * @brief  �ٶȱջ�����  
  *         ��Ϊ�����׶�
  *     1��PWM���ڡ�       
  *     2����ǰ�ǵ��ڡ�
  *     3���������ڡ� 
  * @retval None
  */
//#pragma optimize=none  //speed size ,low,medium, high,
void Drv_SpdClosed(void)
{
  /*-------------------------------------
  ���ٶȱջ� 
  Err = FDB - REF
  */   
  s16 temp1,temp2,temp3;
  
  Ctl.Spd.Err = Ctl.Spd.FdbSpeed - Ctl.Spd.RefCur;
  
  if(Drv.PWM.DutyLimitFlag != 0) /*����ʱ��ֹ����*/
  {
    if(Ctl.Spd.Err < 0)
    {
      Ctl.Spd.Err = 0;
    }
  }
     
  if(Ctl.Spd.RefCur < IQ(1500.0/3000.0))
  {
    temp1 = 3;
    temp2 = 2;
    temp3 = 1;  
  }
  else
  {
    temp1 = 5;
    temp2 = 3;
    temp3 = 1;
  }
    
  if(Ctl.Spd.Err > 0)
  {  
    if(Ctl.Spd.Err > 100)
    {
      Drv.PWM.DutyCur -= temp1;
    }
    else if(Ctl.Spd.Err > 50)
    {
      Drv.PWM.DutyCur -= temp2;
    }
    else if(Ctl.Spd.Err > 10)
    {
      Drv.PWM.DutyCur -= temp3;
    }
  }
  else
  {  
    if(Ctl.Spd.Err < -100)
    {
      Drv.PWM.DutyCur += temp1;
    }
    else if(Ctl.Spd.Err < -50)
    {
      Drv.PWM.DutyCur += temp2;
    }
    else  if(Ctl.Spd.Err < -10)
    {
      Drv.PWM.DutyCur += temp3;
    }   
  }
    
  if(Drv.PWM.DutyCur >= IQ(1.01))
  {
    Drv.PWM.DutyCur = IQ(1.01);
  }
  else if( Drv.PWM.DutyCur < Drv.PWM.DutyMin)
  {
    Drv.PWM.DutyCur = Drv.PWM.DutyMin;
  }
  else
  {
    ;
  }
}

void Drv_SpdClosedPro(void)
{ 
  /*-------------------------------------
  ���ٶȱջ� 
  Err = FDB - REF
  */   
  Ctl.Spd.Err = Ctl.Spd.FdbSpeed - Ctl.Spd.RefCur;	

  if(Ctl.Spd.Err > 100) /*130*/
  {
    tBemfAdcSwitch = 0xF2;
  }
  /*ն������ SECTION 1*/
  if((tBemfAdcSwitch == 0xF2)&&(Drv.AdcMeas.VdcBemfOffsetTar == 0)) /*��Ҫ�˳���ǰ�ǣ��ٽ���PWM���� */
  {  
    //if(Drv.PWM.DutyCur > IQ(0.5))
    {  
      if(Ctl.Spd.Err > 50)
      {
        Drv.PWM.DutyCur -= 5;
      }
      else if(Ctl.Spd.Err < -50)
      {
        Drv.PWM.DutyCur += 12;

      }
      else if(Ctl.Spd.Err > 10)
      {
        Drv.PWM.DutyCur--;
      }
      else if(Ctl.Spd.Err < -10)
      {
        Drv.PWM.DutyCur++;
      }
      else
      {
        ;
      }
    }
    
    if(Drv.PWM.DutyCur < IQ(0.1))
    {
      Drv.PWM.DutyCur = IQ(0.1);
    }
    else if(Drv.PWM.DutyCur >= IQ(1.01)) //1.01
    {
      if(tBemfAdcSwitchCounter < 50) /*1S*/
      {
        tBemfAdcSwitchCounter++;
      }
      Drv.PWM.DutyCur = IQ(1.01);
    }
    else
    {
      tBemfAdcSwitchCounter = 0;
    }
  }
  
  #if (BEMF_SPUERSPED)  
  Drv_OverSpd();  
  #endif
}

/**
  * @fn     void Drv_OverSpd(void)    
  * @brief  ���ٵ���   
  * @retval None
  */
void Drv_OverSpd (void)
{
  u8 temp1; /*û��ʹ�õ�*/
  
  #if (BEMF_SPUERSPED)      /*��ǰ��  SECTION 2    100->72rpm */
  if((Drv.PWM.DutyCur >= IQ(1.0))&&(tBemfAdcSwitchCounter == 50)) 
  { 
    tBemfAdcSwitch = 0xF1;

      #if (BEMF_SPUERSPED >= 1)
      {
        if(Drv.AdcMeas.VdcBemfOffsetTar == 0)
        {  
          if(Ctl.Spd.Err > 100)         /*����*/
          {
            if( Ctl.Bemf.RiseFallNum < Ctl.Bemf.Angle_7)
            {  
              Ctl.Bemf.RiseFallNum++;
              if(Ctl.Bemf.RiseFallNum >= Ctl.Bemf.Angle_7)
              {
                Drv.PWM.DutyCur = IQ(1.0);
              }
            }
          
            temp1 =  Ctl.Bemf.Angle_30 - Ctl.Bemf.RiseFallNum;
            
            if(Ctl.Bemf.C3ComNumTar < temp1)
            {
              if(Ctl.Bemf.C3ComNumCur_L < 6)
              {
                Ctl.Bemf.C3ComNumCur_L++;  
                BemfC3ComNumCurCalc();
              }        
            }
            else
            {
              if(Ctl.Bemf.C3ComNumCur_L > 0)
              {
                Ctl.Bemf.C3ComNumCur_L--;
                BemfC3ComNumCurCalc();
              }     
            }            
          }
          else if(Ctl.Spd.Err < -100)  /*����*/
          {
            if(Ctl.Bemf.RiseFallNum > 3)
            {  
              Ctl.Bemf.RiseFallNum--;
            }
            temp1 =  Ctl.Bemf.Angle_30 - Ctl.Bemf.RiseFallNum;
            
            if(Ctl.Bemf.C3ComNumTar < temp1)
            {
              if(Ctl.Bemf.C3ComNumCur_L < 6)
              {
                Ctl.Bemf.C3ComNumCur_L++;  
                BemfC3ComNumCurCalc();
              }        
            }
            else
            {
              if(Ctl.Bemf.C3ComNumCur_L > 0)
              {
                Ctl.Bemf.C3ComNumCur_L--;
                BemfC3ComNumCurCalc();
              }     
            }            
            
          }
          else
          {
            ;
          }
        } 
      }
      #endif
      
      #if (BEMF_SPUERSPED >= 2) 
      {
        /*��ǰ��⣬���ڼ������*/    
        if(Ctl.Bemf.RiseFallNum == 3)
        {                   
          if(Ctl.Spd.Err > 80)         /*����*/
          {
             if(Drv.AdcMeas.VdcBemfOffsetTar > 0)
             { 
               Drv.AdcMeas.VdcBemfOffsetTar--;
             }
             if(Ctl.Bemf.C3ComNumCur_L > 0)
             {
               Ctl.Bemf.C3ComNumCur_L--;
               BemfC3ComNumCurCalc();
             }
          }
          else if(Ctl.Spd.Err < -15)   /*����*/
          {
            if(Drv.AdcMeas.VdcBemfOffsetTar < 200) 
            {
              Drv.AdcMeas.VdcBemfOffsetTar++;
            }
            if(Ctl.Bemf.C3ComNumCur_L < 6)
            {
              Ctl.Bemf.C3ComNumCur_L++; 
              BemfC3ComNumCurCalc();
            }
          }
          else
          {
            ;
          }
        } 
      }
      #endif 
    
  }
  else
  {
    Ctl.Bemf.C3ComNumCur_L = 0;
    Ctl.Bemf.RiseFallNum = Ctl.Bemf.Angle_7;  /*30�� 11�� */
    Ctl.Bemf.C3ComNumTar = 0;                 /*Ctl.Bemf.Angle_15; 5�� */    
  }
  #endif
}

void BemfC3ComNumCurCalc(void)
{
  if(Ctl.Bemf.C3ComNumCur_L == 6)
  {
    if(Ctl.Bemf.C3ComNumTar < (Ctl.Bemf.Angle_60-6))  
    {
      Ctl.Bemf.C3ComNumTar++;
      Ctl.Bemf.C3ComNumCur_L = 0;
    } 
  }
  else if( Ctl.Bemf.C3ComNumCur_L == 0)
  {
    if(Ctl.Bemf.C3ComNumTar > Ctl.Bemf.Angle_7)    
    {  
      Ctl.Bemf.C3ComNumTar--;
      Ctl.Bemf.C3ComNumCur_L = 5;
    }   
  }
  else
  {
   ;
  }
}

/**
  * @fn     void Drv_7184ClearError(void)    
  * @brief  
  * @retval None
  */
void Drv_7184ClearError(void)
{
  disableInterrupts();
  TLE7184_RGS_OFF;
  gDelayus(10);
  TLE7184_RGS_ON;          /* ���7184 ERR */
  enableInterrupts();
}

/**
  * @fn     void Drv_MotorSelfInspection(void)    
  * @brief  
  * @retval None
  */
#pragma optimize=none 
void Drv_MotorSelfInspection(void)
{
  Ctl.IPD.ErrCur = 0;
  UVWH_PWM_OFF();
  /*
  U���ź�U�������Լ�,

  UL_ON->�Լ�->UL_OFF->UH_ON->�Լ�->UH_OFF
  */
  gDelayus(20);
  UL_GPIO_ON();
  gDelayus(20);
  tMotorSelfInspectionFunction2(1);
  UL_GPIO_OFF();
  gDelayus(20);
  UH_GPIO_ON();
  gDelayus(20);
  tMotorSelfInspectionFunction1();
  UH_GPIO_OFF();
  UVWH_PWM_OFF();
  
  /*
  V���ź�V�������Լ�

  VL_ON->�Լ�->VL_OFF->VH_ON->�Լ�->VH_OFF
  */
  gDelayus(20);
  VL_GPIO_ON();
  gDelayus(20);
  tMotorSelfInspectionFunction2(2);  
  VL_GPIO_OFF();
  gDelayus(20);
  VH_GPIO_ON();
  gDelayus(20);
  tMotorSelfInspectionFunction1();
  VH_GPIO_OFF();
  UVWH_PWM_OFF();

  /*
  W���ź�W�������Լ�

  WL_ON->�Լ�->WL_OFF->WH_ON->�Լ�->WH_OFF
  */
  gDelayus(20);
  WL_GPIO_ON();
  gDelayus(20);
  tMotorSelfInspectionFunction2(2); 
  WL_GPIO_OFF();
  gDelayus(20);
  WH_GPIO_ON();
  gDelayus(20);
  tMotorSelfInspectionFunction1();
  WH_GPIO_OFF();
  UVWH_PWM_OFF(); 
  
  if(Ctl.IPD.ErrCur == 0)
  {  
    tMotorSelfInspectionFunction3();
  }
}

/*
20190606
ĸ�߷�ѹ���裬�����Ʒ�ѹ����MCU��ֵ���ԡ�
*/
#pragma optimize=none 
void tMotorSelfInspectionFunction1(void)
{
  s16 tErrVdc2VmeasX;

  AdcSingleScanMode();
  AdcSingleScanMode();
  
  tErrVdc2VmeasX = Drv.AdcMeas.VdcAvgMeas - Drv.AdcMeas.VmeasA;
  if(tErrVdc2VmeasX > (2.0/VDCMEASEGAIN))
  {
    Ctl.IPD.ErrCur |= 0x01;
  }
  tErrVdc2VmeasX = Drv.AdcMeas.VdcAvgMeas - Drv.AdcMeas.VmeasB;
  if(tErrVdc2VmeasX > (2.0/VDCMEASEGAIN))
  {
    Ctl.IPD.ErrCur |= 0x02;
  }  
  tErrVdc2VmeasX = Drv.AdcMeas.VdcAvgMeas - Drv.AdcMeas.VmeasC;
  if(tErrVdc2VmeasX > (2.0/VDCMEASEGAIN))
  {
    Ctl.IPD.ErrCur |= 0x04;
  }    
}

#pragma optimize=none 
void tMotorSelfInspectionFunction2(u8 phaseX)
{
  AdcSingleScanMode();
  AdcSingleScanMode();
  
  #if(0)
  if(Drv.AdcMeas.VmeasA >  (1.0/VDCMEASEGAIN))
  {
    Ctl.IPD.ErrCur |=  1<<(1+3);//1<<(phaseX+3);
  }
  if(Drv.AdcMeas.VmeasB >  (1.0/VDCMEASEGAIN))
  {
    Ctl.IPD.ErrCur |=  1<<(2+3);//1<<(phaseX+3);
  }
  if(Drv.AdcMeas.VmeasC >  (1.0/VDCMEASEGAIN))
  {
    Ctl.IPD.ErrCur |=  1<<(3+3);//1<<(phaseX+3);
  }  
  #endif
}

 
/*
��·��⣬7184_ERR���ŵ͵�ƽ�������
*/
#pragma optimize=none
void tMotorSelfInspectionFunction3(void)
{
  if((TLE7184_ERR_IDR & (u8)TLE7184_ERR_BIT) == TLE7184_ERR_BIT)
  {  
    UVWH_PWM_OFF();
    UVWL_GPIO_OFF();
    gDelayus(5);
    UH_GPIO_ON();
    VL_GPIO_ON();
    WL_GPIO_ON();
    gDelayus(30);    /*�Լ�UV UW�Ƿ��·*/
    
    VL_GPIO_OFF();
    WL_GPIO_OFF();  
    UH_GPIO_OFF(); 
    UVWH_PWM_OFF();  /*�ر������������*/
    gDelayus(10);   
    
    VH_GPIO_ON();
    UL_GPIO_ON();
    WL_GPIO_ON();  
    gDelayus(30);    /*�Լ�VU VW�Ƿ��·*/
    
    UH_GPIO_OFF(); 
    UL_GPIO_OFF();  
    VH_GPIO_OFF();  
    VL_GPIO_OFF();
    WH_GPIO_OFF();
    WL_GPIO_OFF();   /*�ر������������*/

    UVWH_PWM_OFF();
    gDelayus(10);
    
    #if(1)
    if((TLE7184_ERR_IDR & (u8)TLE7184_ERR_BIT) != TLE7184_ERR_BIT)
    {
      Ctl.SysError.Code = E_8174;
      Ctl.IPD.DsovRestartTimCounter = 0;
      Ctl.IPD.DsovRestartNum++;
    }
  }
  #endif
}
