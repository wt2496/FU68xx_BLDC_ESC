/**
  ******************************************************************************
  * @file    \USER\src\TTech_BLDC.c
  * @author  Application Team  Tom.wang
  * @version
  * @since
  * @date    2018-10-17
  * @note
  * @brief
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "MC_stm8Adc.h"
#include "MC_MotorCotrol.h"
#include "MC_MotorDrive.h"
#include "TTech_BLDC.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------- -----------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
void Drv_SmartRumCalc(void);
void Drv_SmartStartCalc(void);
void Drv_BemfZeroCrossDetect(void);
void Drv_PosTrack(void);
void Drv_SetCommutation(void);
void gAdcSampleCapacitorsDelay(void);

extern void gDelayus(u16 timer);

/**
  * @fn     Drv_SmartRumCalc
  * @brief  ��hall���в���
  * 1��Bemf���
  * 2��22����
  * 3������120���󣬿�ʼ33���ࡣ
  * 4�����60�Ȼ���ʱ�䣬ʹ��TIM1��⡣����ͬ��22�����33���ࡣ
  * 5��TIM2��� һ��������ʱ�䣬���������ٶȼ��㡣

  * 20180827 16:22
  * 1������������20Ȧ�󣬿�ʼ��BEMFͬ�����ࡣֻ���U�������ټ����������BEMF��
  * �ó��������������adc ����ʱ�������������顣ȱ�㣬���������ˣ�ʧ�ٱ�����Ҫ�ڿ��ǡ�
  * �ٶ���Ӧ������ɢ�ȷ����㹻�ˡ�
  * @retval None
  */
/*
size     none, low,medium, high, 
speed    none, low,medium, high, 
*/
#pragma optimize=none  //speed  size ,  low,medium, high,
void Drv_SmartRumCalc(void)
{
  if(Ctl.Bemf.RiseFallNum < 3 )
  {
    Ctl.Bemf.RiseFallNum = 3;
  }
  else if(Ctl.Bemf.RiseFallNum > 120)
  {
    Ctl.Bemf.RiseFallNum = 120;
  }
  else
  {
    ;
  }
  
  if(Ctl.Nor.ComCounter < (u16)(5*6))      /*˳������  30*6 */
  {
    #if(0)
    if(Ctl.Spd.EventPeriodErrAvg > 6500)
    {  
      Ctl.Bemf.RiseFallNum = 60;      /*����==3*/
    }
    else
    {
      Ctl.Bemf.RiseFallNum = 30;
    }
    #else
    Ctl.Bemf.RiseFallNum = 3;
    #endif
  }    

  Drv_BemfZeroCrossDetect();           /*bemf���*/
  
  if(Ctl.Bemf.RiseFallCounter >= Ctl.Bemf.RiseFallNum)
  {
    Ctl.Bemf.RiseFallCounter = 0;
    Ctl.Vtim.STA2TimCounter = 0;
    Ctl.Nor.ComCounter++;
  
    /*�������ڼ���  12*/
    if(Ctl.gStepCur == Ctl.Bemf.SingleBemfDetectionStepCur)
    {
      Drv_Tim2CalcPeriod();
      if(Ctl.Nor.ComCounter> (u16)1000)
      {
        #if(SL_RUN_STB3)
        if((Ctl.Bemf.E360CounterPre < Ctl.Bemf.E360CounterCur>>2)||(Ctl.Bemf.E360CounterCur < Ctl.Bemf.E360CounterPre>> 2)) /* ����ʱ60��ն���������٣�����ʹ������о� */
        {
          Ctl.SysError.Code = E_STB3;                     /*��ת��ʧ�ٹ���*/
        }
        #endif
        if(Ctl.Bemf.E360CounterPre < (u8)60)
        {
          Ctl.SysError.Code = E_STB1;
        }
      }

      Ctl.Bemf.E360CounterPre = Ctl.Bemf.E360CounterCur;  /*������*/
      Ctl.Bemf.E360CounterCur = 0;

      Ctl.Bemf.E360CounterSum +=  Ctl.Bemf.E360CounterPre;
      Ctl.Bemf.E360CounterAvg = Ctl.Bemf.E360CounterSum>>1;  /*�ٶȸ�������*/
      Ctl.Bemf.E360CounterSum -= Ctl.Bemf.E360CounterAvg;
     }
   
    //if(Drv.PWM.DutyCur >= IQ(1.0))
    {
      if(Drv.AdcMeas.VdcBemfOffsetCur < Drv.AdcMeas.VdcBemfOffsetTar)
      {
        Drv.AdcMeas.VdcBemfOffsetCur++;
      }
      else
      {
        Drv.AdcMeas.VdcBemfOffsetCur--;
      }
    }

    #if(BEMF_DETECTION_MODE)
    /*if((Drv.PWM.DutyCur >= IQ(0.5))&&(Ctl.gStepCur == 12))   U�� */
    if((Ctl.Nor.ComCounter >= (u16)300)&&(Ctl.gStepCur == Ctl.Bemf.SingleBemfDetectionStepCur))       /*CW-> U��  CCW-> U�� */
    {
      if((Ctl.Bemf.C3ComNumCur < Ctl.Bemf.C3ComNumTar)&&( Drv.PWM.DutyCur > IQ(0.5)))
      {
        Ctl.Bemf.C3ComNumCur++; /*����Ŀ�꣬C3ComNumTar ����C3�ĸ���*/
      }
      else if((Ctl.Bemf.C3ComNumCur > Ctl.Bemf.C3ComNumTar)||( Drv.PWM.DutyCur < IQ(0.3)))
      {
        if(Ctl.Bemf.C3ComNumCur > (u8)0)
        {
          Ctl.Bemf.C3ComNumCur--;
        }
      }
      else
      {
        ;
      }

      Ctl.Bemf.Angle_C2 = Ctl.Bemf.Angle_60 - Ctl.Bemf.C3ComNumCur ;
      Ctl.Bemf.AngleCmpNum = Ctl.Bemf.C3ComNumCur;   /*STEP1*/
      Ctl.gStepCur = Ctl.Bemf.SingleBemfDetectionStepNex;
      Drv_Commutation(Ctl.gStepCur);
      Ctl.Bemf.Status = BEMF_CC2_W;
    }
    else
    #endif
    {
      if(Ctl.Nor.ComCounter >= (u16)300)      /*CW-> U��  CCW-> U�� */
      {
        if(Ctl.Bemf.C3ComNumCur < Ctl.Bemf.C3ComNumTar)
        {
          Ctl.Bemf.C3ComNumCur++; 
        }
        else if(Ctl.Bemf.C3ComNumCur > Ctl.Bemf.C3ComNumTar)
        {
          if(Ctl.Bemf.C3ComNumCur > (u8)0)
          {
            Ctl.Bemf.C3ComNumCur--;
          }
        }
        else
        {
          ;
        }
        Ctl.Bemf.Angle_C2 = Ctl.Bemf.Angle_60 - Ctl.Bemf.C3ComNumCur ;
      }
      else
      {
	Ctl.Bemf.Angle_C2  = Ctl.Bemf.Angle_60; 
        Ctl.Bemf.C3ComNumTar = 0;
        Ctl.Bemf.C3ComNumCur = 0;
      }

      #if (BEMF_DETECTION_MODE == 0)
      #if(SL_RUN_STB3)
      if(Ctl.Nor.ComCounter > (u16)300)
      {
        if((Ctl.Bemf.E60CounterPre < Ctl.Bemf.E60CounterCur>>1)||(Ctl.Bemf.E60CounterCur < Ctl.Bemf.E60CounterPre>>1)) /*����ʱ60��ն���������٣�����ʹ������о�*/
        {
          /*Ctl.SysError.Code = E_STB3;*/                          /*��ת��ʧ�ٹ���*/
          Ctl.SysError.Code = E_STB3;
        }
      }
      #endif
      #endif
      if(Ctl.gDirectionC == CW)
      {
        Ctl.gStepCur += 1;
        if(Ctl.gStepCur > 12)
        {
          Ctl.gStepCur = 1;
        }
      }
      else
      {
         Ctl.gStepCur -= 1;
        if(Ctl.gStepCur <= 0)
        {
          Ctl.gStepCur  = 12;
        }
      }
      /* C3������ɣ��ȴ�C2���� 33����   1 3 5 7 9 11 */
      Ctl.Bemf.Status = BEMF_C2_W;
      Drv_Commutation(Ctl.gStepCur);
    }
    Ctl.Bemf.E60CounterPre = Ctl.Bemf.E60CounterCur;
    Ctl.Bemf.E60CounterCur = 0;
  }
  /*33���� end */

  /*
  ��������  ��BEMFͬ������
  */
  if(Ctl.Bemf.Status == BEMF_CC2_W)        /*�ȴ�C3����*/
  {
    if(Ctl.Bemf.E60CounterCur >= Ctl.Bemf.AngleCmpNum)
    {
      Ctl.Bemf.E60CounterCur = 0;

      if(Ctl.gStepCur != Ctl.Bemf.SingleBemfDetectionStepCur )
      {
        Ctl.Bemf.AngleCmpNum = Ctl.Bemf.Angle_C2;

        if(Ctl.gDirectionC == CW)
        {
          Ctl.gStepCur += 1;         /*2 4 6 8 10 12*/
          if(Ctl.gStepCur > 12)
          {
            Ctl.gStepCur = 2;
          }
        }
        else
        {
          Ctl.gStepCur -= 1;
          if(Ctl.gStepCur == 0)      /*4 2 12 10 8 6*/
          {
            Ctl.gStepCur = 12;
          }
        }
        Drv_Commutation(Ctl.gStepCur);
      }

      if(Ctl.gStepCur == Ctl.Bemf.SingleBemfDetectionStepCur)
      {
        Ctl.Bemf.Status = BEMF_DZ_W;
      }
      else
      {
        Ctl.Bemf.Status = BEMF_CC3_W;
      }
    }
  }
  else if(Ctl.Bemf.Status == BEMF_CC3_W)  /*�ȴ�C3����*/
  {
    if(Ctl.Bemf.E60CounterCur >= Ctl.Bemf.AngleCmpNum)
    {
      Ctl.Bemf.E60CounterCur = 0;

      /*if(Ctl.gStepCur < 12 ) */
      {
        /*Ctl.gStepCur += 1 ; */    /* �������� 3 5 7 9  11  */
        if(Ctl.gDirectionC == CW)
        {
          Ctl.gStepCur += 1;        /*�������� 3 5 7 9 11*/
          if(Ctl.gStepCur > 12)
          {
            Ctl.gStepCur = 2;
          }
        }
        else
        {
          Ctl.gStepCur -= 1;
          if(Ctl.gStepCur <= 0)      /*������ 3 1 11 9 7 */
          {
            Ctl.gStepCur  = 12;
          }
        }

        Ctl.Bemf.Angle_C3 = Ctl.Bemf.C3ComNumCur;

        if(Ctl.gStepCur == Ctl.Bemf.SingleBemfDetectionStepPre)
        {
          Ctl.Bemf.AngleCmpNum = Ctl.Bemf.C3Step11ComNumCur;  /*��11�����������࣬��Ҫ�������Ƽ������ʱ��*/
        }
        else
        {
          if(Ctl.Bemf.C3ComNumCur_L >= Ctl.gStepCur>>1)      /*��11�����������࣬����C3ComNumCur_L����������ÿ����������� ������*/
          {
            Ctl.Bemf.AngleCmpNum = Ctl.Bemf.Angle_C3+(u8)1;
          }
          else
          {
            Ctl.Bemf.AngleCmpNum = Ctl.Bemf.Angle_C3;
          }
        }
        Drv_Commutation(Ctl.gStepCur);
      }
      Ctl.Bemf.Status = BEMF_CC2_W;
    }
  }
  else if(Ctl.Bemf.Status == BEMF_C2_W)   /*�ȴ�C2����*/
  {
    if(Ctl.Bemf.E60CounterCur >= Ctl.Bemf.C3ComNumCur)
    {
      Ctl.Bemf.Status = BEMF_DZ_W;
      if(Ctl.gDirectionC == CW)
      {
        Ctl.gStepCur += 1;
        if(Ctl.gStepCur > 12)
        {
          Ctl.gStepCur = 2;
        }
      }
      else
      {
        Ctl.gStepCur -= 1;
        if(Ctl.gStepCur <= 0)
        {
          Ctl.gStepCur  = 12;
        }
      }
      Drv_Commutation(Ctl.gStepCur); /*2 4 6 8 10 12*/
    }
  }
  else
  {
    ;
  }
}

/**
  * @fn    Drv_BemfZeroCrossDetect
  * @brief ��������
  *
  * @retval None
  */
void Drv_BemfZeroCrossDetect(void)
{
  WORD tADC;
  tADC.W = 0;
  /*---------------------------
  BEMF���
  */
  if((Ctl.Bemf.Status == BEMF_DZ_W)||(Ctl.Bemf.Status == BEMF_DZ_D))
  {
    ADC2->CSR  = (u8)ADC2_CHANNEL_3;
    gAdcSampleCapacitorsDelay();             /*�β���u16 ��ʽ*/
    
    Drv_BemfPhaseChoice(Ctl.gStepCur);

    while((ADC2->CSR & (u8)0x80) == (u8)0x00){};
    ADC2->CSR &= ~(u8)0x80;

    tADC.B.L = ADC2->DRL;
    tADC.B.H = ADC2->DRH;
    Drv.AdcMeas.VmeasX  = tADC.W;

    if(Ctl.Bemf.RiseFallFlag == (u8)1)      /*--->�ж�������*/
    {
      if(Drv.AdcMeas.VmeasX < (Drv.AdcMeas.VdcAvgMeas - (u16)(VRiseSeta/VDCMEASEGAIN)))
      {
        Ctl.Bemf.DzNumCounter++;
        if(Ctl.Bemf.DzNumCounter >= (u8)2)
        {  
          Ctl.Bemf.Status = BEMF_DZ_D; /*�������*/
        }
      }
      if((Drv.AdcMeas.VmeasX > Drv.AdcMeas.VmeasRise)&&((Drv.AdcMeas.VmeasX < Drv.AdcMeas.VdcAvgMeas - (u16)(VRiseSeta/VDCMEASEGAIN))||(Ctl.Bemf.Status == BEMF_DZ_D))) 
      //if((Drv.AdcMeas.VmeasX > Drv.AdcMeas.VmeasRise)&&(Drv.AdcMeas.VmeasX < Drv.AdcMeas.VdcAvgMeas - (u16)(VRiseSeta/VDCMEASEGAIN)))
      //if((Drv.AdcMeas.VmeasX > Drv.AdcMeas.VmeasRise)&&(Ctl.Bemf.Status == BEMF_DZ_D))
      //if(Drv.AdcMeas.VmeasX > Drv.AdcMeas.VmeasRise)  
      {
         Ctl.Bemf.DzNumCounter = 0;
         Ctl.Bemf.RiseFallCounter++;
      }
      else
      {
        if(Ctl.Bemf.RiseFallCounter > 0)
        {
          Ctl.Bemf.RiseFallCounter--;
        }
      }
    }
    else                               /*--->�ж��½���*/
    {
      if(Drv.AdcMeas.VmeasX > (u16)(VFallSeta/VDCMEASEGAIN))
      {
        Ctl.Bemf.DzNumCounter++;
        if(Ctl.Bemf.DzNumCounter >= 2)
        {  
          Ctl.Bemf.Status = BEMF_DZ_D; /*�������*/
        }      
      }
        
      if((Drv.AdcMeas.VmeasX < Drv.AdcMeas.VmeasFall)&&(((Drv.AdcMeas.VmeasX > (u16)(VFallSeta/VDCMEASEGAIN)))||(Ctl.Bemf.Status == BEMF_DZ_D)))
      //if((Drv.AdcMeas.VmeasX < Drv.AdcMeas.VmeasFall)&&(Drv.AdcMeas.VmeasX > (u16)(VFallSeta/VDCMEASEGAIN)))
      //if((Drv.AdcMeas.VmeasX < Drv.AdcMeas.VmeasFall)&&(Ctl.Bemf.Status == BEMF_DZ_D))
      //if(Drv.AdcMeas.VmeasX < Drv.AdcMeas.VmeasFall)  
      {
        Ctl.Bemf.DzNumCounter = 0;
        Ctl.Bemf.RiseFallCounter++;
      }
      else
      {
        if(Ctl.Bemf.RiseFallCounter > 0)
        {
          Ctl.Bemf.RiseFallCounter--;
        }
      }
    }
  }
}

/**
  * @fn     Drv_SmartStartCalc
  * @brief  ��HALL��������
  *
  * @retval None
  */
   
void Drv_SmartStartCalc(void)
{
  SWORD tADC;
  tADC.W = 0;
  
  if(Ctl.Ramp.ComCounter < Ctl.Ramp.StartABSwitchNum)
  {
    if(Ctl.Ramp.StartRiseFallNumA == (u8)0)    /*��A״̬�� ����ⷴ���ƣ�����ForceComTimCurʱ�� ǿ�ƻ���*/
    {  
      Ctl.Bemf.RiseFallCounter = 0;            /*���� �½��ؼ�ʱ��*/
      Ctl.Bemf.E60CounterCur = 0;
    }
    else
    {  
      Ctl.Bemf.MaskComNum = Ctl.Ramp.StartMaskComNumA;
      Ctl.Bemf.RiseFallNum = Ctl.Ramp.StartRiseFallNumA;
    }
  }
  else
  {
    Ctl.Bemf.MaskComNum = Ctl.Ramp.StartMaskComNumB;
    Ctl.Bemf.RiseFallNum = Ctl.Ramp.StartRiseFallNumB;
  }

  /*
  20190719 
  �Ż����������� �Զ��жϻ�����ʱ�䵽
  */
  if(Ctl.Bemf.E60CounterCur > Ctl.Bemf.MaskComNum)   /*����ʱ����*/
  {
    Ctl.Bemf.Status = BEMF_DZ_D;
  }
  
  {
    ADC2->CSR  = (u8)ADC2_CHANNEL_3;
    
    gAdcSampleCapacitorsDelay();  /*һ����ʱ 1.62us�������� �ں��ʵĵ���*/
    gAdcSampleCapacitorsDelay();  
    
    Drv_BemfPhaseChoice(Ctl.gStepCur);

    while((ADC2->CSR & (u8)0x80) == (u8)0x00){};
    ADC2->CSR &= ~(u8)0x80;

    tADC.B.L = ADC2->DRL;
    tADC.B.H = ADC2->DRH;
    Drv.AdcMeas.VmeasX  = tADC.W;
    
    if(Ctl.Bemf.RiseFallFlag == (u8)1)     /*--->�ж�������*/
    {
      if((Drv.AdcMeas.VmeasX > (Drv.AdcMeas.VdcMeasHalf + Ctl.Bemf.StartVdcBemfOffsetCurRise)))
      {
        if(Ctl.Bemf.Status == BEMF_DZ_W)  /*�Զ����ż��*/
        {
          Ctl.Bemf.RiseFallCounter = 0;
        }
        else
        {
          Ctl.Bemf.RiseFallCounter++;
        }
      }
      else
      {
        Ctl.Bemf.Status = BEMF_DZ_D;
        if(Ctl.Bemf.RiseFallCounter > 0)
        {  
          Ctl.Bemf.RiseFallCounter--;
        }
      }
    }
    else
    {
      if(Drv.AdcMeas.VmeasX < (Drv.AdcMeas.VdcMeasHalf + Ctl.Bemf.StartVdcBemfOffsetCurFall))
      {
        if(Ctl.Bemf.Status == BEMF_DZ_W)
        {
          Ctl.Bemf.RiseFallCounter = 0;
        }
        else
        {
          Ctl.Bemf.RiseFallCounter++;
        }
      }
      else
      {
        Ctl.Bemf.Status = BEMF_DZ_D;
        if(Ctl.Bemf.RiseFallCounter > 0)
        {  
          Ctl.Bemf.RiseFallCounter--;
        }
      }
    }

    if(Ctl.Bemf.RiseFallCounter >= Ctl.Bemf.RiseFallNum)
    {
      Ctl.Bemf.RiseFallCounter = 0;

      if(Ctl.gStepCur == 12)
      {
        Ctl.Bemf.E360CounterPre = Ctl.Bemf.E360CounterCur;  /*������*/
        Ctl.Bemf.E360CounterCur = 0;
      }

      if(Ctl.gDirectionC == CW)
      {
        Ctl.gStepCur += 2;
        if(Ctl.gStepCur > 12)
        {
          Ctl.gStepCur = 2;
        }
      }
      else
      {
         Ctl.gStepCur -= 2;
        if(Ctl.gStepCur <= 0)
        {
          Ctl.gStepCur  = 12;
        }
      }
      
      Drv_Commutation(Ctl.gStepCur);
      Ctl.Bemf.Status = BEMF_DZ_W;
      Ctl.Ramp.ForceComTimCounter = 0;

      if((Ctl.Bemf.E60CounterPre > Ctl.Bemf.E60CounterCur>>1)&&(Ctl.Bemf.E60CounterCur > Ctl.Bemf.E60CounterPre>>1))
      {
        //FG_ONOFF;
        Ctl.Ramp.BemfTureCnt++;
        if(Ctl.Ramp.BemfErrCnt > (u8)0)
        {
          Ctl.Ramp.BemfErrCnt--;
        }

        if(Ctl.Ramp.BemfTureCnt > Ctl.Ramp.BemfTureNum)
        {
          Ctl.State = MOTOR_NORMAL;
          Ctl.Bemf.Status = BEMF_DZ_W;
        }
      }
      else
      {
        if(Ctl.Ramp.BemfTureCnt > 0)
        {
          Ctl.Ramp.BemfTureCnt--;  
        }
        //Ctl.Ramp.BemfErrCnt++;
        if(Ctl.Ramp.BemfErrCnt > Ctl.Ramp.BemfErrNum )      /*����ʧ�ܺ������������ٴ�����ʱɲ��1000ms 0.3�ĵ�ѹ */
        {
          /*Ctl.SysError.Code  = E_STA2;*/
          Ctl.Ramp.BemfErrCnt = 0;
          Ctl.Alig.TimCount = 0;
          //Ctl.Alig.timNms = 1000;
          Drv.PWM.DutyCur = IQ(0.2);
          Ctl.State = MOTOR_ALIGNMENGT;
        }
      }
      Ctl.Bemf.E60CounterPre = Ctl.Bemf.E60CounterCur;   /*����60�Ȼ���ʱ��*/
      Ctl.Bemf.E60CounterCur = 0;                        /*60�Ȼ���ʱ�䣬������*/
    }
  }
}

/**
  * @fn      Drv_PosTrack
  * @brief   start in motion
  *
  * @retval None
  */
#define BEMF_ZN_ERR  15
#if(1)
void Drv_PosTrack(void)
{
  s8 temp1;
  s16 tVerrA2B,tVerrA2C;      

  Ctl.Bemf.DetectDirectionCounterCur++;

  AdcSingleScanMode(); /*50us*/

  tVerrA2B = Drv.AdcMeas.VmeasA  - Drv.AdcMeas.VmeasB;
  tVerrA2C = Drv.AdcMeas.VmeasA  - Drv.AdcMeas.VmeasC;
  if(tVerrA2B > BEMF_ZN_ERR)
  {
    Ctl.Bemf.DetectDirectionArrayCur |= 0x02; 
  }
  else if(tVerrA2B < -BEMF_ZN_ERR)
  {
    Ctl.Bemf.DetectDirectionArrayCur &= (~0x02); 
  }
  else
  {
    ;
  }

  if(tVerrA2C > BEMF_ZN_ERR)
  {
    Ctl.Bemf.DetectDirectionArrayCur |= (s8)0x01;
  }
  else if(tVerrA2C < -BEMF_ZN_ERR)
  {
    Ctl.Bemf.DetectDirectionArrayCur &= (~0x01);
  }
  else
  {
    ;
  }

  if(Ctl.Bemf.DetectDirectionArrayCur != Ctl.Bemf.DetectDirectionArrayPre)
  {
    if(Ctl.Bemf.DetectDirectionArrayCur != 0)
    {
      Ctl.Bemf.DetectDirectionStepCounter++;
      temp1 = Ctl.Bemf.DetectDirectionArrayCur -  Ctl.Bemf.DetectDirectionArrayPre;
      Ctl.Bemf.DetectDirectionSum += temp1;
    }
    else
    {
      if(Ctl.Bemf.DetectDirectionStepCounter == (u8)3)
      {
        if(Ctl.Bemf.DetectDirectionSum == (s8)2)
        {
          Ctl.Bemf.DetectDirectionFR = CCW;      /*U�� ��*/

          Drv_Tim2CalcPeriod();
          
          Ctl.Bemf.E360CounterPre = Ctl.Bemf.DetectDirectionCounterCur;
          Ctl.Bemf.DetectDirectionCounterCur = 0;
          
          if(Ctl.Spd.EventPeriodErr > (u16)6000) /*6000  Ctl.Spd.EventPeriodErr �ٶ�С��һ��ֵ*/
          {
            Ctl.Bemf.DetectDirectionFR = 0;
          }
        }
        else if(Ctl.Bemf.DetectDirectionSum == (s8)1)
        {
          Ctl.Bemf.DetectDirectionFR = CW;
          Drv_Tim2CalcPeriod();
          Ctl.Bemf.E360CounterPre = Ctl.Bemf.DetectDirectionCounterCur;
          /*Ctl.Bemf.DetectDirectionCounterErr = Ctl.Bemf.DetectDirectionCounterCur; */
          Ctl.Bemf.DetectDirectionCounterCur = 0;
      
           
          if(Ctl.Spd.EventPeriodErr > (u16)6000) /*6000*/
          {
            Ctl.Bemf.DetectDirectionFR = 0;
          }         
        }
        else
        {
          //P4_OFF;
          Ctl.Spd.EventPeriodErr = 0;
          Ctl.Bemf.DetectDirectionFR = 0xE1;
          /*Ctl.Bemf.DetectDirectionCounterErr = 0; */
          Ctl.Bemf.DetectDirectionCounterCur = 0;
          Ctl.Bemf.DetectDirectionFR = 0;
        }
      }
      

      Ctl.Bemf.DetectDirectionStepCounter = 0;
      Ctl.Bemf.DetectDirectionSum = 0;
    }
    Ctl.Bemf.DetectDirectionArrayPre = Ctl.Bemf.DetectDirectionArrayCur;
  }

  if(Ctl.Bemf.DetectDirectionCounterCur > (u16)(500*(PWM_FREQUENCY/1000)))   /*100ms*/
  {
    //P4_OFF;
    Ctl.Bemf.DetectDirectionFR = 0xE2;
    Ctl.Spd.EventPeriodErr = 0;
    /*Ctl.Bemf.DetectDirectionCounterErr = 0;*/
    Ctl.Bemf.DetectDirectionStepCounter = 0;
    Ctl.Bemf.DetectDirectionCounterCur = 0;
  }
}

#else
void Drv_PosTrack(void)
{
  s8 temp1;
        
  Ctl.Bemf.DetectDirectionFR = 0;
  Ctl.Bemf.DetectDirectionCounterCur++;

  AdcSingleScanMode(); /*50us*/

  Drv.AdcMeas.VmeasZn = 0;
  Drv.AdcMeas.VmeasZn += Drv.AdcMeas.VmeasA;
  Drv.AdcMeas.VmeasZn += Drv.AdcMeas.VmeasB;
  Drv.AdcMeas.VmeasZn += Drv.AdcMeas.VmeasC;
  Drv.AdcMeas.VmeasZn = Drv.AdcMeas.VmeasZn/3;
//  Drv.AdcMeas.VmeasA = Drv.AdcMeas.VmeasA*3;
//  Drv.AdcMeas.VmeasB = Drv.AdcMeas.VmeasB*3;

  if((Drv.AdcMeas.VmeasA  - Drv.AdcMeas.VmeasZn) > BEMF_ZN_ERR)
  {
    //FG_ON;
    Ctl.Bemf.DetectDirectionArrayCur |= 0x02; 
  }
  else if((Drv.AdcMeas.VmeasA  - Drv.AdcMeas.VmeasZn) < -BEMF_ZN_ERR)
  {
    Ctl.Bemf.DetectDirectionArrayCur &= (~0x02); 
    //FG_OFF;
  }
  else
  {
    ;
  }

  if((Drv.AdcMeas.VmeasB  - Drv.AdcMeas.VmeasZn) > BEMF_ZN_ERR)
  {
    Ctl.Bemf.DetectDirectionArrayCur |= (s8)0x01;
  }
  else if((Drv.AdcMeas.VmeasB  - Drv.AdcMeas.VmeasZn) < -BEMF_ZN_ERR)
  {
    Ctl.Bemf.DetectDirectionArrayCur &= (~0x01);
  }
  else
  {
    ;
  }

  if(Ctl.Bemf.DetectDirectionArrayCur != Ctl.Bemf.DetectDirectionArrayPre)
  {
    if(Ctl.Bemf.DetectDirectionArrayCur != 0)
    {
      Ctl.Bemf.DetectDirectionStepCounter++;
      temp1 = (s8)Ctl.Bemf.DetectDirectionArrayCur -  (s8)Ctl.Bemf.DetectDirectionArrayPre;
      Ctl.Bemf.DetectDirectionSum += temp1;
    }
    else
    {
      if(Ctl.Bemf.DetectDirectionStepCounter == (u8)3)
      {
        if(Ctl.Bemf.DetectDirectionSum == (s8)2)
        {
          //P4_OFF;
          Ctl.Bemf.DetectDirectionFR = CCW;      /*U�� ��*/

          Drv_Tim2CalcPeriod();
          Ctl.Bemf.E360CounterPre = Ctl.Bemf.DetectDirectionCounterCur;
          Ctl.Bemf.DetectDirectionCounterCur = 0;
        }
        else if(Ctl.Bemf.DetectDirectionSum == (s8)1)
        {
          //P4_ON;

          Ctl.Bemf.DetectDirectionFR = CW;
          Drv_Tim2CalcPeriod();
          Ctl.Bemf.E360CounterPre = Ctl.Bemf.DetectDirectionCounterCur;
          /*Ctl.Bemf.DetectDirectionCounterErr = Ctl.Bemf.DetectDirectionCounterCur; */
          Ctl.Bemf.DetectDirectionCounterCur = 0;
        }
        else
        {
          //P4_OFF;
          Ctl.Spd.EventPeriodErr = 0;
          Ctl.Bemf.DetectDirectionFR = 0xE1;
          /*Ctl.Bemf.DetectDirectionCounterErr = 0; */
          Ctl.Bemf.DetectDirectionCounterCur = 0;
        }
      }
      Ctl.Bemf.DetectDirectionStepCounter = 0;
      Ctl.Bemf.DetectDirectionSum = 0;
    }
    Ctl.Bemf.DetectDirectionArrayPre = Ctl.Bemf.DetectDirectionArrayCur;
  }

  if(Ctl.Bemf.DetectDirectionCounterCur > (u16)(500*(PWM_FREQUENCY/1000)))   /*100ms*/
  {
    //P4_OFF;
    Ctl.Bemf.DetectDirectionFR = 0xE2;
    Ctl.Spd.EventPeriodErr = 0;
    /*Ctl.Bemf.DetectDirectionCounterErr = 0;*/
    Ctl.Bemf.DetectDirectionStepCounter = 0;
    Ctl.Bemf.DetectDirectionCounterCur = 0;
  }
}
#endif

/*
10�� nop ->1000ns
5��  nop ->795ns
3��  nop ->710ns
*/
#pragma optimize=none 
void  gAdcSampleCapacitorsDelay(void)
{
  nop();nop();nop();nop();nop();
  nop();nop();nop();nop();nop(); 
}
/******************* (C) COPYRIGHT 2018 JK *****END OF FILE****/
