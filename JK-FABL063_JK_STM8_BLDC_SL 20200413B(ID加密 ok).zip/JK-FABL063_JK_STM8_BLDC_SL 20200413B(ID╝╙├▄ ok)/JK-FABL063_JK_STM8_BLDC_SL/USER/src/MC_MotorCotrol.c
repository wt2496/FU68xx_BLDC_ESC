/**
  ******************************************************************************
  * @file    \USER\src\MC_MotorCotrol.c
  * @author  Application Team  Tom.wang
  * @version
  * @since
  * @date    2018-10-17
  * @note
  * @brief   ������Ʋ�
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "Bsp_Pwmin.h"
#include "Bsp_Uart3.h"
#include "MC_init.h"
#include "MC_DMC.h" 
#include "MC_UserInterface.h"
#include "MC_MotorCotrol.h"
#include "MC_MotorDrive.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/**
*  @brief  ������Ʋ�����ṹ��
*/
MCL_TypeDef  Ctl;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
void MainISR(void);
void MCL_Init(void);
void MCL_Ready(void);
void MCL_Precharge(void);
void MCL_Alignment(void);
void MCL_OpenLoop(void);
void MCL_Normal(void);
void MCL_Stop(void);
void MCL_Failure(void);

void U_Task_Ptr(void);
void A_Task_Ptr(void);
void B_Task_Ptr(void);
void C_Task_Ptr(void);
void D_Task_Ptr(void);

void SysTick_1ms(void);
void SysTick_100ms(void);

/**
  * @fn     void MCL_Function(void)
  * @brief
  * @retval None
  */
void MCL_Function(void)
{
  switch(Ctl.State)
  {
    case MOTOR_INIT:
      MCL_Init();
      break;
    case MOTOR_STOP:
      MCL_Stop();
      break;
    case MOTOR_READY:
      MCL_Ready();
      break;
    case MOTOR_PRECHARGE:
      MCL_Precharge();
      break;
    case MOTOR_ALIGNMENGT:
      MCL_Alignment();
      break;
    case MOTOR_OPENLOOP:
      MCL_OpenLoop();
      break;
    case MOTOR_NORMAL:
      MCL_Normal();
      break;
    case MOTOR_FAILURE:
      MCL_Failure();
      break;
    default:
      break;
  }
}

/**
  * @fn     void MCL_Init(void)
  * @brief  �ϵ��ʼ��
  *
  * @retval None
  */
void MCL_Init(void)
{
  MCL_ModuleInit();
  Ctl.State = MOTOR_STOP;
 
}

/**
  * @fn     void MCL_Stop(void)
  * @brief  STOP״̬
  *
  * @retval None
  */
void MCL_Stop(void)
{
  //P4_OFF;
  if((Ctl.gStopmodeC == FREE_DOWN)||(Ctl.gStopmodeC == SLOWING_DOWN))
  {
    #if(0)
    UVWH_PWM_OFF();
    UVWL_GPIO_OFF();
    Drv.PWM.DutyCur = 0;
    Drv_PwmUpdate();
    #else
    Drv.PWM.DutyCur = 0;
    if(Ctl.Vtim.BrakewaitNms < (u16)4)           /*R10.4a*/
    {
      UVWH_PWM_OFF();
      UVWL_GPIO_OFF();
    }
    else if(Ctl.Vtim.BrakewaitNms < (u16)BREAK_DOWN_TIM)  /*ɲ��3��*/
    {
      UVWL_GPIO_ON();
    }
    else
    {
      UVWL_GPIO_OFF();
      Ctl.Vtim.BrakewaitNms = BREAK_DOWN_TIM+2000;
    }
    #endif
  }
  else if(Ctl.gStopmodeC == BREAK_DOWN)
  {
    if(Ctl.Vtim.BrakewaitNms < (u16)3)   /*R10.4a*/
    {
      UVWH_PWM_OFF();
      UVWL_GPIO_OFF();
    }
    else
    {
      UVWL_GPIO_ON();
      //Ctl.Vtim.BrakewaitNms = 10;
    }
  }
  else
  {
    ;
  }

  
  if((Ctl.Vtim.BrakewaitNms == (u16)0)||(Ctl.Vtim.BrakewaitNms > (u16)BREAK_DOWN_TIM ))
  {  
    if(Ctl.gStartC == (s8)FALSE)
    {
      Ctl.gStepCur = 0;
      Ctl.Bemf.DetectDirectionFR = 0;
      Ctl.State = MOTOR_STOP;
    }
    else
    {
      Ctl.Bemf.DetectDirectionFR = 0;
      Ctl.Bemf.DetectDirectionVtim = 0;
      /*
      ���Drive����״̬
      */
      //MCL_ModuleDefault();
      Ctl.Spd.EventPeriodErr = 0;
      Ctl.Spd.EventPeriodErrAvg = 0;
      Ctl.Spd.EventPeriodErrSum = 0;     
      Ctl.State =  MOTOR_READY;
    }
  }
}

/**
  * @fn     void MCL_Ready(void)
  * @brief  ����ǰ����ر�������
  *
  * @retval None
  */
void MCL_Ready(void)
{
  if(Ctl.gStartC == (s8)FALSE)
  {
    Ctl.State = MOTOR_STOP;
  }
  else
  {
    Ctl.Vtim.SensorlessStartTimCounter = 0;
    //Ctl.Bemf.DetectDirectionVtim = 0;
    if(Ctl.Bemf.DetectDirectionVtim < STKNMS)
    {
      if((Ctl.Bemf.DetectDirectionFR == CCW)&&(Ctl.gDirectionC == CCW))
      {
        MCL_ModuleDefault();
        Ctl.gStepCur = 10;
        Ctl.Nor.ComCounter = 0;
        Ctl.Bemf.Status = BEMF_DZ_W;
        Ctl.Spd.RefCur = IQ(RAMP_DUTY); /*˳������ ����ջ�����*/
        Drv_PwmUpdate();
        Drv_Commutation(Ctl.gStepCur);
        Ctl.State = MOTOR_NORMAL;
      }
      else if((Ctl.Bemf.DetectDirectionFR == CW)&&(Ctl.gDirectionC == CW))
      {
        MCL_ModuleDefault();
        Ctl.gStepCur = 8;
        Ctl.Nor.ComCounter = 0;
        Ctl.Spd.RefCur = IQ(RAMP_DUTY); /*˳������ ����ջ�����*/
        Drv_PwmUpdate();
        Ctl.Bemf.Status = BEMF_DZ_W;
        Drv_Commutation(Ctl.gStepCur);

        Ctl.State = MOTOR_NORMAL;
      }
      else if(Ctl.Bemf.DetectDirectionFR == 0)
      {
        Ctl.Vtim.SensorlessStartTimCounter = 0;
      }
      else  /*�����෴,����STOP ɲ�� */
      {
        Ctl.Vtim.BrakeNum++;        /*����ɲ��3�Σ�����ɲ��ס��ֱ�ӽ��붨λ����*/
        if(Ctl.Vtim.BrakeNum < (u8)5)
        {  
          Ctl.Vtim.BrakewaitNms = 1;
          Ctl.State = MOTOR_STOP;
        }
        else
        {
          MCL_ModuleDefault();
          Ctl.State = MOTOR_PRECHARGE;        
        }
      }
    }
    else
    {
      MCL_ModuleDefault();
      Ctl.State = MOTOR_PRECHARGE;
    }
  }
}

/**
  * @fn     void MCL_Precharge(void)
  * @brief  �Ծٳ��
  *
  * @retval None
  */
void MCL_Precharge(void)
{
  /*u8 charge pump �����Ӿٳ��

  u8 temp = CHARGENMS;
  if(temp >= 10)
  {
    temp = 10;
  }

  Drv.PWM.DutyCur = CHARGEDUTY;
  Drv_PwmUpdate();

  UH_PWM_OFF();
  VH_PWM_OFF();
  WH_PWM_OFF();
  UL_GPIO_ON();
  VL_GPIO_OFF();
  WL_GPIO_OFF();
  gDelayms((u16)temp);
  
  UL_GPIO_OFF();
  VL_GPIO_ON();
  WL_GPIO_OFF();
  gDelayms((u16)temp);

  UL_GPIO_OFF();
  VL_GPIO_OFF();
  WL_GPIO_ON();
  gDelayms((u16)temp);

  UL_GPIO_OFF();
  VL_GPIO_OFF();
  WL_GPIO_OFF();
  gDelayms((u16)1);
  enableInterrupts();
  */
  if(Ctl.gStartC == (s8)FALSE)
  {
    Ctl.State = MOTOR_STOP;
  }
  else
  {
    Drv_MotorSelfInspection();
    
    if(Ctl.IPD.ErrCur == (u8)0)
    { 
      Ctl.IPD.ErrPre = 0;
      Ctl.State = MOTOR_ALIGNMENGT;
      Ctl.Alig.TimCount = 0;
      Drv.PWM.DutyCur = IQ(0);  /*��λ����*/
      Drv_PwmUpdate();
    }
    else
    {
      Ctl.IPD.ErrPre = Ctl.IPD.ErrCur; 
      Ctl.IPD.ErrCur = 0;
      Ctl.State = MOTOR_STOP;
    }
  }
}

/**
  * @fn      void MCL_Alignment(void)
  * @brief   ��λĿ�İ�ת������һ�� ��֪λ��
  *
  * @retval None
  */
void MCL_Alignment(void)
{
/*
  #if (DEBUG_WAIT_STATE == MOTOR_ALIGNMENGT)
  {
    Ctl.Alig.TimCount = 0;
  }
  #endif
*/
  if(Drv.PWM.DutyCur < IQ(0.05))
  {
    Drv.PWM.DutyCur = IQ(0.05);
  }
  
  if(Ctl.Alig.TimCount < Ctl.Alig.timNms>>1)
  {
    if(Drv.PWM.DutyCur < Ctl.Alig.duty1)
    {
      Drv.PWM.DutyCur += 1;
    }
    Drv_PwmUpdate();

    Ctl.gStepCur = 5;
    Drv_Commutation(Ctl.gStepCur); /*step 3  UH->VLWL */
  }
  else if(Ctl.Alig.TimCount < Ctl.Alig.timNms)
  {
    if(Drv.PWM.DutyCur < Ctl.Alig.duty2)
    {
      Drv.PWM.DutyCur += 1;
    }
    Drv_PwmUpdate();

    Ctl.gStepCur = 5;
    Drv_Commutation(Ctl.gStepCur); /*step 3  UH->VLWL */
  }
  else
  {
    UVWH_PWM_OFF();
    UVWL_GPIO_OFF();
    gDelayms((u16)1);                  /* 1ms */
    if(Ctl.gDirectionC == CW)
    {  
      Ctl.gStepCur = 6; //4
    }
    else
    {
      Ctl.gStepCur = 4; //2   
    }
    Ctl.Vtim.SensorlessStartTimCounter = 0;
    

    Ctl.Ramp.ForceComTimCur = Ctl.Ramp.ForceComTimCurT;
    Ctl.Ramp.ForceComTimCounter =  Ctl.Ramp.ForceComTimCur;
  
    Ctl.Ramp.ForceComTimTar = Ctl.Ramp.ForceComTimTarT;
    Ctl.Ramp.ForceComTimAcc = Ctl.Ramp.ForceComTimAccT;

    Ctl.State = MOTOR_OPENLOOP;
  }

  if(Ctl.gStartC == (s8)FALSE)
  {
    Ctl.State = MOTOR_STOP;
  }
}

/**
  * @fn     void MCL_OpenLoop(void)
  * @brief  �϶�״̬�£��������
  *
  * @retval None
  */
void MCL_OpenLoop(void)
{
  if(Ctl.Ramp.ForceComTimCounter >= Ctl.Ramp.ForceComTimCur) 
  {
    Ctl.Ramp.ForceComTimCounter = 0;
    #if(1)
    /*����ʽ�϶��� */
    Ctl.Ramp.ForceComTick++;
    if(Ctl.Ramp.ForceComTick >= (u8)0) /*���������*/
    {  
      Ctl.Ramp.ForceComTick = 0;
      if((Ctl.Ramp.ForceComTimCur - Ctl.Ramp.ForceComTimTar) > Ctl.Ramp.ForceComTimAcc) 
      {
        Ctl.Ramp.ForceComTimCur -= Ctl.Ramp.ForceComTimAcc;
        Ctl.Ramp.ComCounter = 0;
      }
      else if((Ctl.Ramp.ForceComTimTar - Ctl.Ramp.ForceComTimCur) > Ctl.Ramp.ForceComTimAcc) 
      {
        Ctl.Ramp.ForceComTimCur += Ctl.Ramp.ForceComTimAcc;
        Ctl.Ramp.ComCounter = 0;
      }
      else
      {
        Ctl.Ramp.ForceComTimCur = Ctl.Ramp.ForceComTimTar;
      }
    }
    #elif(1)
    /*�϶���2 -FABL029 NG*/
    if(Ctl.Ramp.ForceComTimCur == RAMP_FORCECOM_TIM_STA)
    {
      Ctl.Ramp.ForceComTimCur = RAMP_FORCECOM_TIM_STA>>1;
    }
    else
    {
      Ctl.Ramp.ForceComTimCur = RAMP_FORCECOM_TIM_STA;
    }
    #else
    Ctl.Ramp.ForceComTimCur = Ctl.Ramp.ForceComTimTarT;
    
    #endif 

    if(Ctl.gDirectionC == CW)
    {
      Ctl.gStepCur += 2;
      if(Ctl.gStepCur > 12)
      {
        Ctl.gStepCur = 2;
      }
    }
    else
    {
       Ctl.gStepCur -= 2;
      if(Ctl.gStepCur <= 0)
      {
        Ctl.gStepCur  = 12;
      }
    }
   
    Drv.PWM.DutyCur = Ctl.Ramp.ForceComDutyCur;
    
    Ctl.Bemf.E60CounterPre = 0;     /* ����ʱ�� */
    Ctl.Bemf.E60CounterCur = 0;     /* ����ʱ�� */
    Ctl.Bemf.Status = BEMF_DZ_W; 
    Ctl.Ramp.ComCounter++;
    Drv_PwmUpdate();
    
    Drv_Commutation(Ctl.gStepCur);
  }

  if(Ctl.gStartC == (s8)FALSE)
  {
    Ctl.State = MOTOR_STOP;
  }
}

/**
  * @fn      void MCL_Normal(void)
  * @brief   ��������״̬���������м�ʱ����������ϱ�־��
  *
  * @retval None
  */
void MCL_Normal(void)
{
  if(Ctl.Vtim.NormalTimCounter >= (u16)NOR_RUN_TIM)
  {
    Ctl.Vtim.FailureTimCounter = 0;
    Ctl.Vtim.SensorlessStartTimCounter = 0;
    Ctl.Fail.Sta1RestartNum = 0;
    //��� Ӳ����������
    Ctl.IPD.DsovRestartNum = 0;	 
  }
  if(Ctl.gStartC == (s8)FALSE)
  {
    Ctl.State = MOTOR_STOP;
  }
}

/**
  * @fn      void MCL_Failure(void)
  * @brief   ����״̬�£��ж������������Ƿ�����
  *
  * @retval None
  */
void MCL_Failure(void)
{
  UVWH_PWM_OFF();
  UVWL_GPIO_OFF();

  Drv.PWM.DutyCur = 0;
  Drv_PwmUpdate();

  Ctl.gStepCur = 0;
  Ctl.gStartC = (s8)FALSE;
/*-------------------------------------------------------
���ϼ�¼*/
  #if(FAILLOGEN)
  if(Ctl.E_message.ErrorF==0)
  {
    /* ������Ϣ��¼ */
    Ctl.E_message.ErrorF   = 1 ;
    Ctl.E_message.SysError.Code  = Ctl.SysError.Code ;
    /*Ctl.E_message.State  = Ctl.State ; */
    Ctl.E_message.FR       = Ui.flg.FR;
    /*Ctl.E_message.SpeedRef = pid_spd.Ref;*/
    Ctl.E_message.SpeedFdb = Ctl.Spd.FdbSpeedRpm;  
    Ctl.E_message.Duty     = Drv.PWM.DutyCur;
    Ctl.E_message.ImeasBus = Drv.AdcMeas.ImeasBus;
    Ctl.E_message.VdcMeas = Drv.AdcMeas.VdcAvgMeas;
    Ctl.E_message.Ibus     = Drv.AdcMeas.Ibus;
    Ctl.E_message.Vdc      = Drv.AdcMeas.Vdc;
/*-------------------------------------------------------
������Ϣflash �洢 */
    #if(FAILSTOREEN)
    if((Ctl.SysError.Code  != E_OV)&&(Ctl.SysError.Code != E_UV))
    { 
      //APP_Flash_Save_Data();
    }
    #endif
  }
  #endif

  if((Ctl.SysError.Code == E_STB3)||(Ctl.SysError.Code == E_STB1)||(Ctl.SysError.Code  == E_STA2)
     ||(Ctl.SysError.Code  == E_STA1)||(Ctl.SysError.Code == E_OC)||(Ctl.SysError.Code == E_8174)
     ||(Ctl.SysError.Code == E_ADC)||(Ctl.SysError.Code == E_ADC_V)||(Ctl.SysError.Code == E_ADC_T))
  {
    
    if(Ctl.SysError.Code == E_STA1)
    {
      if(Ctl.Fail.Sta1RestartNum == (u8)0)
      {
        Ctl.Vtim.STRestartTim = 5000;
      }
      else if(Ctl.Fail.Sta1RestartNum == (u8)1)
      {
        Ctl.Vtim.STRestartTim = 5000;
      }
      else if(Ctl.Fail.Sta1RestartNum == (u8)2)
      {
        Ctl.Vtim.STRestartTim = 12000;
      }
      else if(Ctl.Fail.Sta1RestartNum == (u8)3)
      {
        Ctl.Vtim.STRestartTim = 60000;
      }
      else if(Ctl.Fail.Sta1RestartNum == (u8)4)
      {
        Ctl.Vtim.STRestartTim = 60000;
      }
      else
      {
        Ctl.Vtim.STRestartTim = 60000;
      }
      
      if(Ctl.Vtim.STRestartCounter > Ctl.Vtim.STRestartTim)
      {
        if(Ctl.Fail.Sta1RestartNum < (u8)3)
        {  
          Ctl.Fail.Sta1RestartNum++;
        }          
        Ctl.SysError.Code  = NONE;
        Ctl.State = MOTOR_STOP;            /*MOTOR_READY*/
        Ctl.Vtim.STRestartCounter = 0;

        Ctl.Vtim.STB1TimCounter = 0;
        Ctl.Vtim.STA2TimCounter = 0;
      }
    }
    else
    {  
      if(Ctl.Vtim.STRestartCounter > SL_RESTART_TIM)
      {
        //Drv_7184ClearError();
        
        Ctl.SysError.Code  = NONE;
        Ctl.State = MOTOR_STOP; /*MOTOR_READY*/
        Ctl.Vtim.STRestartCounter = 0;

        Ctl.Vtim.STB1TimCounter = 0;
        Ctl.Vtim.STA2TimCounter = 0;
      }
    }
  }
}

/**
  * @fn     void MainISR(void)
  * @brief
  *         MainISR �� TIM1 CH4�ж��� 16K������Ƶ�ʡ�
  *         ������λ�ü�⣻
  *         �Ƴ�1ms��ʱ���׼���û� ��ʱ ���϶���ʱ��ļ�ʱ����ѹ��Ƿѹ��������
  *
  * @retval None
  */
void MainISR(void)
{
  Ctl.gIsrTicker++;
  Ctl.Vtim.MainLoopCounter++;
  
  Drv_BemftCalc();        /* ÿ���ز����һ�� */
  
  if(Ctl.gIsrTicker >= (u8)(PWM_FREQUENCY/1000))
  {
    SysTick_1ms();
    Ctl.gIsrTicker = 0;
  }
  else if(Ctl.gIsrTicker == (u8)1)
  {
    Ctl.Alig.TimCount++;
    Ctl.Ramp.ForceComTimCounter++;

    if(Ctl.State == MOTOR_NORMAL)
    {
      if(Ctl.Vtim.NormalTimCounter < (u16)30000)
      {  
        Ctl.Vtim.NormalTimCounter++;
      }
    }
    
    if(Ctl.State == MOTOR_OPENLOOP)
    {  
      /*if((Ctl.gStartC == (s8)TRUE)&&(Ctl.SysError.Code  == NONE))*/
      {
        Ctl.Vtim.SensorlessStartTimCounter++;
      }
    }
  }
  else if(Ctl.gIsrTicker == (u8)2)
  {
    if(Ctl.Spd.RampCounter > SPEED_TICKPEREN)
    {
      Drv_SpeedRampCale();
      pid_spd.Ref = Ctl.Spd.RefCur;
      Ctl.Spd.RampCounter = 0;
    }
  }
  else if(Ctl.gIsrTicker == (u8)3)
  {
    Ctl.Vtim.counterSpeed++;

    if(Ctl.State == MOTOR_NORMAL)
    {
      if(Ctl.Vtim.counterSpeed > SPEED_CTL_CNT)
      {
        #if(SPEED_CLOSE_EN)
          if(Drv.PWM.DutyLimitFlag == 0)
          { 
            #if(SPEED_CLOSE_EN==1)
            /*pid_spd.Ref = Ctl.Spd.RefCur;    ������ б�º��������*/
            /*pid_spd.Fdb = Ctl.Spd.FdbSpeed;  �ٶȼ���� ֱ�Ӹ�Fdb*/
            Dmc_SpdPidCalc();
            Drv.PWM.DutyCur = pid_spd.Out;      
            #elif(SPEED_CLOSE_EN==2)
            Drv_SpdClosed();
            #endif
          }
          
          Ctl.Bemf.C3ComNumTar = Ctl.Bemf.Angle_15; /* 5��       */
          Ctl.Bemf.RiseFallNum = Ctl.Bemf.Angle_15; /* 30�� 11�� */
            
          Drv_PwmUpdate();
          Ctl.Vtim.counterSpeed = 0;
        #else
          Ctl.Vtim.counterSpeed = 0;
          
          Ctl.Bemf.C3ComNumTar = Ctl.Bemf.Angle_15; /* 5��       */
          Ctl.Bemf.RiseFallNum = Ctl.Bemf.Angle_15; /* 30�� 11�� */
          
          //Ctl.Bemf.C3ComNumTar = Ctl.Bemf.Angle_15; /* 5��       */
          //Ctl.Bemf.RiseFallNum = Ctl.Bemf.Angle_30 - Ctl.Bemf.C3ComNumTar; /* 30�� 11�� */       

          Drv.PWM.DutyCur = Ctl.Spd.RefCur + IQ(0.05);
          Drv_PwmUpdate();
        #endif
      }
    }
  }
  else if(Ctl.gIsrTicker == (u8)4)
  {
    if((Ctl.Spd.InputSelect & (u8)0X01) == (u8)1)
    {
      Ctl.Spd.FdbSpeed = (s16)(Ctl.Spd.SpeedScaler/Ctl.Spd.EventPeriodErrAvg); /* 31.0us */
      Ctl.Spd.InputSelect &= (~(u8)0x01);
    }    
    U_Task_Ptr();
  }
  else if(Ctl.gIsrTicker == (u8)5)
  {
    A_Task_Ptr();
  }
  else if(Ctl.gIsrTicker == (u8)6)
  {
    if(Ctl.SysError.Code != E_ADC)
    {
      B_Task_Ptr();
    }
  }
  else if(Ctl.gIsrTicker == (u8)7)
  {
    if(Ctl.SysError.Code != E_ADC)
    {
      C_Task_Ptr();
    }
  }
  else if(Ctl.gIsrTicker == (u8)8)
  {
    if ((Ctl.SysError.Code  != NONE))
    {
      #if(FAILSTOREEN)
      if(Ctl.E_message.State == 0)
      {
       Ctl.E_message.State = Ctl.State;
      }
      #endif
      Ctl.State = MOTOR_FAILURE;
    }
  }
  else if(Ctl.gIsrTicker == (u8)9)
  {
    Ctl.Vtim.g1msTicker++;
    if(Ctl.Vtim.g1msTicker >= (u8)100)
    {
      Ctl.Vtim.g1msTicker = 0;
      SysTick_100ms();
    }
  }
  else
  {
    ;
  }
}

/**
  * @fn     void SysTick_1ms(void)
  * @brief  1ms ���ڼ�ʱ�� �������⣬Ƿѹ��ѹ��⣬���¼��ȣ��϶���ʱ��
  *
  * @retval None
  */
void SysTick_1ms(void)
{
  Ui.FaultLedTimCunter++;
  Ctl.Spd.RampCounter++;
  Ctl.Vtim.FG_1msCounter++;
  Ctl.Bemf.DetectDirectionVtim++;  
  Ctl.Vtim.FB_1msCounter++;
  gUart3.TxGapTimeCounter++;

  
  APP_PwminLostSignalCalc();
  /**/

  /*
    20190321 tom
    7184�����Ϻ󣬵ȴ�1�룬����С��120�棬������ϡ�
  */
  if((TLE7184_ERR_IDR & (u8)TLE7184_ERR_BIT) == TLE7184_ERR_BIT)
  {
    if(Drv.TLE7184.Errfilter < 10)
    {  
      Drv.TLE7184.Errfilter++;  /*10*/
    }
    else
    {
      if(Ctl.Vtim.OH7184ErrRstnms > 0)
      {  
        Ctl.Vtim.OH7184ErrRstnms--;
      }
    }
  }
  else
  {
    if(Drv.TLE7184.Errfilter > -10)
    {
      Drv.TLE7184.Errfilter--;   /*-10*/
    }
    else
    {
      if(Ctl.Vtim.OH7184Warnnms >= 50)
      {
        //Ctl.SysError.Code = E_8174;
        //Ctl.IPD.DsovRestartNum++;
        if(Ctl.Vtim.OH7184ErrRstnms < 1000)
        {
          Ctl.Vtim.OH7184ErrRstnms++;
        }
      }
    }
  }
}

/**
  * @fn     void SysTick_100ms(void)
  * @brief  100ms��ʱ��
  *
  * @retval Nonea
  */
void SysTick_100ms(void)
{
  Ctl.Vtim.OnOffTimCounter++;
  Ctl.Spd.Vtim100ms++;
  Ctl.IPD.DsovRestartTimCounter++;
  Ctl.Vtim.Ui100msPtr++;
  /*RTC*/
  if(Ctl.Vtim.RTC.Tick100msPtr < (u8)10) /*Tick100msPtr  Tick1sPtr Tick1minPtr */
  {
    Ctl.Vtim.RTC.Tick100msPtr++;
  }
  else
  {
    Ctl.Vtim.RTC.Tick100msPtr = 0;
    
    /*1��*/    
    if(Ctl.State == MOTOR_NORMAL)    /*����ʱ��*/
    {
      gUart3.TransmitBuffer.BufferByte.RunTim.W++;
    }
    else
    {
      gUart3.TransmitBuffer.BufferByte.RunTim.W = 0;
    }
      
    
    if(Ctl.Vtim.RTC.Tick1sPtr< (u8)60)
    {
      Ctl.Vtim.RTC.Tick1sPtr++;
    }
    else
    {
      Ctl.Vtim.RTC.Tick1sPtr = 0;
      
      if(Ctl.Vtim.RTC.Tick1minPtr < (u8)60) /*60�� 1����*/
      {
        Ctl.Vtim.RTC.Tick1minPtr++;
      }
      else
      {
        Ctl.Vtim.RTC.Tick1minPtr = 0;
      }
      /*1���� ����*/
      gUart3.TransmitBuffer.BufferByte.PowerOnTim.W++; /*�ϵ�ʱ��*/
    }  
  }
  if(Ui.flg.START == (u8)TRUE)
  {  
    Ctl.Vtim.FailureTimCounter++;
  }
  
  if((Ui.Pwmin.LostSignalFlag == 0x72)||(Ui.Pwmin.LostSignalFlag == 0x73))
  {  
    if(Ctl.Vtim.Tle7184SleepTimCounter < (u16)60000) /* 600.0*/
    {
      Ctl.Vtim.Tle7184SleepTimCounter++;
    }
  }    
}

/**
  * @fn     void U_Task_Ptr(void)
  * @brief  �û�����
  *
  * @retval None
  */
void U_Task_Ptr(void)
{
  ;
}

/**
  * @fn     void A_Task_Ptr(void)
  * @brief  A����
  *
  * @retval None
  */
void A_Task_Ptr(void)
{
  if(Ctl.Vtim.SensorlessStartTimCounter > (u16)SL_START_STA1) /* ������ʱ���� */
  {
    Ctl.SysError.Code = E_STA1;
  }

  if(Ctl.State == MOTOR_NORMAL)
  {
    Ctl.Vtim.STA2TimCounter++;
    if(Ctl.Vtim.STA2TimCounter > (u16)SL_RUN_STA2) /*����㳤ʱ��û�������� */
    {
      Ctl.SysError.Code  = E_STA2;
    }
/*
    if(Ctl.Spd.EventPeriodErr < SL_RUN_STB1_CON)
    {
      Ctl.Vtim.STB1TimCounter++;
      if(Ctl.Vtim.STB1TimCounter > 500)
      {
        Ctl.SysError.Code  = E_STB1;
      }
    }
*/
  }
  else if(Ctl.State == MOTOR_STOP)  
  {
    if(Ctl.Vtim.BrakewaitNms >= (u16)1)
    {  
      Ctl.Vtim.BrakewaitNms++;
    }
    Ctl.Spd.CwCCwSwitchNms++;
  }
  /* �������� ��ʱ�� */
  if(Ctl.SysError.Code != NONE)
  {  
    if((Ctl.SysError.Code == E_STB3)||(Ctl.SysError.Code == E_STB1)||(Ctl.SysError.Code == E_STA2)||(Ctl.SysError.Code == E_STA1)||(Ctl.SysError.Code  == E_OC)||(Ctl.SysError.Code == E_8174))
    {
      Ctl.Vtim.STRestartCounter++;
    }
  }
}

/**
  * @fn     void B_Task_Ptr(void)
  * @brief  B���񣺱�������
  *
  * @retval None
  */
void B_Task_Ptr(void)
{
  #if((OVERVOLTAGE_EN)||(UNDERVOLTAGE_EN)||(VBUSRECOVER_EN))
  if(Drv.AdcMeas.VdcAvgMeas != 0)
  {
    if(Drv.AdcMeas.VdcAvgMeas > MECAS_OVERVOLTAGE)
    {
      if(Ctl.Vtim.UVnms > (u16)0)
      {
        Ctl.Vtim.UVnms--;
      }
      if(Ctl.Vtim.Nonms > (u16)0)
      {
        Ctl.Vtim.Nonms--;
      }

      if(Ctl.Vtim.OVnms < OVNMS)    /* ��ѹ */
      {  
        Ctl.Vtim.OVnms++;
      }
      else   
      {
        #if(OVERVOLTAGE_EN)
        Ctl.SysError.Code = E_OV;
        #endif
      }
    }
    else if (Drv.AdcMeas.VdcAvgMeas < MECAS_UNDERVOLTAGE)
    {
      if(Ctl.Vtim.OVnms > (u16)0)
      {
        Ctl.Vtim.OVnms--;
      }      
      if(Ctl.Vtim.Nonms > (u16)0)
      {
        Ctl.Vtim.Nonms--;
      }
      
      if(Ctl.Vtim.UVnms < UVNMS)
      {  
        Ctl.Vtim.UVnms++;
      }      
      else
      {
        #if(UNDERVOLTAGE_EN)
        Ctl.SysError.Code = E_UV;
        #endif
      }
     
    }
    else if ((Drv.AdcMeas.VdcAvgMeas < MECAS_OVREVOLTAGE_RE)&&(Drv.AdcMeas.VdcAvgMeas > MECAS_UNRERVOLTAGE_RE))
    {
      if(Ctl.Vtim.OVnms > (u16)0)
      {
        Ctl.Vtim.OVnms--;
      }
      if(Ctl.Vtim.UVnms  > (u16)0)
      {
        Ctl.Vtim.UVnms--;
      }
      if(Ctl.Vtim.Nonms < NONMS)
      {
        Ctl.Vtim.Nonms++;
      }
    }
    else
    {
      ;
    }
  }
  #endif

  #if(CURRENT_LIMIT_EN)
  if(Drv.AdcMeas.ImeasBus >  Drv.PWM.DutyLimitMaxRefH)//Drv.PWM.DutyLimitMaxRefH)  DutyLimitValue
  {
    Drv.PWM.DutyLimitFlag = 0x01;
  }
  else if(Drv.AdcMeas.ImeasBus <  Drv.PWM.DutyLimitMaxRefL)
  {
    Drv.PWM.DutyLimitFlag &= (~0x1);
  }
  #endif
  
  #if(OVERCURRENT_EN)
  if(Drv.AdcMeas.ImeasBus > MECASEOVERCURRENT)
  {
    Ctl.Vtim.OCnms++;
    if(Ctl.Vtim.OCnms >= OCNMS)      /*����*/
    {
      Ctl.SysError.Code  = E_OC;
      //Ctl.SysError.Bit.E_OC = 1; 
    }
  }
  else
  {
    if(Ctl.Vtim.OCnms > 0)
    {
      Ctl.Vtim.OCnms--;
    }
  }
  #endif
}

/**
  * @fn     C_Task_Ptr(void)
  * @brief  C�����¶ȱ���
  *
  * @retval None
  */
void C_Task_Ptr(void)
{
  #if(OH1_EN)
  /*
  L99: 100 ->409��   300->284��  713-> 28��
  TLE7184; 
  */
  if(Drv.AdcMeas.Vth1Meas < (u16)((300 - TH_B)/TH_A))       /**/
  {
    if(Drv.AdcMeas.Vth1Meas < OH7184_WARNE_MEAS)
    {
      if(Ctl.Vtim.OH7184Warnnms < 100)
      {  
        Ctl.Vtim.OH7184Warnnms++;
      }
    }
    else
    {
      if(Ctl.Vtim.OH7184Warnnms > 0)
      {
        Ctl.Vtim.OH7184Warnnms--;
      }
    }
    
    if(Drv.AdcMeas.Vth1Meas > OH1MEAS)       /*����135*/
    {
      if(Ctl.Vtim.OH1nms < OHNMS)
      {  
        Ctl.Vtim.OH1nms++;
      }
      else
      {
        Ctl.SysError.Code = E_OH1;   
        Ctl.Fail.OHLevel = 0xF1;
      }
        
    }
    else if(Drv.AdcMeas.Vth1Meas > OH2MEAS)       /*����135*/
    {
      if(Ctl.Vtim.OH1nms > (s16)0)
      {
        Ctl.Vtim.OH1nms--;
      }
      
      if(Ctl.Vtim.OH2nms <  OHNMS)
      {  
        Ctl.Vtim.OH2nms++;
      }
      else
      {
        Ctl.Fail.OHLevel = 0xF2;
      } 
    }
    else if(Drv.AdcMeas.Vth1Meas > OH3MEAS)       /*����135*/
    {
      if(Ctl.Vtim.OH1nms > (s16)0)
      {
        Ctl.Vtim.OH1nms--;
      }
      if(Ctl.Vtim.OH2nms > (s16)0)
      {
        Ctl.Vtim.OH2nms--;
      }
      if(Ctl.Vtim.OH3nms <  OHNMS)
      {  
        Ctl.Vtim.OH3nms++;
      }  
      else
      {
        Ctl.Fail.OHLevel = 0xF3;
      }
    }
    else if(Drv.AdcMeas.Vth1Meas > OH4MEAS)       /*����135*/
    {
      if(Ctl.Vtim.OH1nms > (s16)0)
      {
        Ctl.Vtim.OH1nms--;
      }
      if(Ctl.Vtim.OH2nms > (s16)0)
      {
        Ctl.Vtim.OH2nms--;
      }  
      if(Ctl.Vtim.OH3nms > (s16)0)
      {
        Ctl.Vtim.OH3nms--;
      }  
      if(Ctl.Vtim.OH4nms < OHNMS)
      {  
        Ctl.Vtim.OH4nms++;
      }
      else
      {
        Ctl.Fail.OHLevel = 0xF4;
      }
      if(Ctl.Vtim.OH5nms > (s16)0)
      {
        Ctl.Vtim.OH5nms--;
      }          
    }
    else if(Drv.AdcMeas.Vth1Meas < OH5MEAS)       /*����135*/
    {
      if(Ctl.Vtim.OH1nms > (s16)0)
      {
        Ctl.Vtim.OH1nms--;
      }
      if(Ctl.Vtim.OH2nms > (s16)0)
      {
        Ctl.Vtim.OH2nms--;
      }  
      if(Ctl.Vtim.OH3nms > (s16)0)
      {
        Ctl.Vtim.OH3nms--;
      }     
      if(Ctl.Vtim.OH4nms > (s16)0)
      {
        Ctl.Vtim.OH4nms--;
      }  
      if(Ctl.Vtim.OH5nms < OHNMS)
      {
        Ctl.Vtim.OH5nms++;
      }
      else
      {
        Ctl.Fail.OHLevel = 0xF5;
      }
    }
    else
    {
     ;
    }

  }
  #endif
}