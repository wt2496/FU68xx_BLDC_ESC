/**
  ******************************************************************************
  * @file    \USER\src\Bsp_Uart3.c
  * @author  tom.wang Application Team
  * @version
  * @since
  * @date    2019-01-25
  * @note
  * @brief   ����3������ �˻���������
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2019 JK </center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "Bsp_Uart3.h"
#include "MC_UserInterface.h"
#include "MC_MotorCotrol.h"

/* External variables --------------------------------------------------------*/
Uart3_Type gUart3;
/* Private typedef -----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void Uart3_Config(void);
void UART3_send_string(uint8_t *Buffer);
void APP_Uart3_Task(void);
uint8_t Uart3Checksum (uint8_t* Checksum_Buffer, uint8_t Data_Number);
void Arraycpy (u8* ReceiveBuffer,u8* SendBuffer ,u8 Data_Number);


/* Private functions ---------------------------------------------------------*/

/**
* @brief  < Add here the function description >
* @note   < OPTIONAL: add here global note >
* @param  None
* @retval None
*/ 
void Uart3_Config(void)
{
  gUart3.TransmitBuffer.BufferByte.MHR = 0x55;
  gUart3.TransmitBuffer.BufferByte.Class = PM_CLASS;
  gUart3.TransmitBuffer.BufferByte.PM = PM_NUMBER;
  gUart3.TransmitBuffer.BufferByte.HvSv = HW_VERSION*16+SW_VERSION;
  gUart3.TransmitBuffer.BufferByte.Ibus = 0;
  gUart3.TransmitBuffer.BufferByte.Vbus = 0;
  gUart3.TransmitBuffer.BufferByte.Temp = 0;
  gUart3.TransmitBuffer.BufferByte.Sref.W = 0;
  gUart3.TransmitBuffer.BufferByte.Fbd.W = 0;
  gUart3.TransmitBuffer.BufferByte.PowerOnTim.W = 0;
  gUart3.TransmitBuffer.BufferByte.RunTim.W = 0;
  gUart3.TransmitBuffer.BufferByte.ErrorCode = 0;  

  gUart3.TransmitNum = 20;
  
  GPIO_Init(GPIOD, GPIO_PIN_5, GPIO_MODE_OUT_PP_HIGH_FAST);
  //GPIO_Init(GPIOD, GPIO_PIN_6, GPIO_MODE_IN_PU_NO_IT);        /*RX GPIO_MODE_IN_PU_NO_IT  GPIO_MODE_IN_FL_IT*/
  UART3_DeInit();   
  UART3_Init((u32)9600,UART3_WORDLENGTH_8D,UART3_STOPBITS_1,UART3_PARITY_NO ,UART3_MODE_TXRX_ENABLE); /*�������ã�������115200���ֽ���8��1��ֹͣλ������żЧ��λ����ͬ��ģʽ���������ܺͷ���*/
  UART3_Cmd(ENABLE ); 

  ITC_SetSoftwarePriority(ITC_IRQ_UART3_RX,ITC_PRIORITYLEVEL_1); /* �����ж� ���ȼ�1*/

  /* Enable UART3 Receive interrupt */
  UART3_ITConfig(UART3_IT_RXNE_OR, DISABLE);
}

void UART3_send_string(uint8_t *Buffer) //����һ���ַ�
{
  uint8_t *String;
  String=Buffer;
  while(*String!='\0')
  {
    UART3_SendData8(*String);
    while (UART3_GetFlagStatus(UART3_FLAG_TXE)==RESET){};
    String++;
  }
}
    

/**
* @brief  < Add here the function description >
* @note   < OPTIONAL: add here global note >
* @param  None
* @retval None

  UART3_send_string("12345");
  UART3_SendData8('\n');
  while (UART3_GetFlagStatus(UART3_FLAG_TXE)==RESET)
  {
    ;
  }
*/
void APP_Uart3_Task(void)
{
  if(gUart3.TxGapTimeCounter >= (u16)1000)
  {    
    if(UART3_GetFlagStatus(UART3_FLAG_TXE)==SET)
    {  
      //gUart3.Checksum = Uart3Checksum(gUart3.ReceiveBuffer,19);
      
      if(gUart3.TransmitDataByteIndex < gUart3.TransmitNum)
      {
        UART3_SendData8(gUart3.TransmitArray[gUart3.TransmitDataByteIndex]);
        gUart3.TransmitDataByteIndex++;
        //while (UART3_GetFlagStatus(UART3_FLAG_TXE)==RESET);
        gUart3.TxGapTimeCounter = 1000;
      }
      else
      {
        gUart3.TransmitDataByteIndex = 0;
        gUart3.TxGapTimeCounter = 0;
        if(gUart3.TransmitNum >= 1)
        {  
          Arraycpy(gUart3.TransmitArray,gUart3.TransmitBuffer.Array,gUart3.TransmitNum-(u8)1);                            /*���鿽��*/
          gUart3.TransmitArray[gUart3.TransmitNum-(u8)1] = Uart3Checksum(gUart3.TransmitArray,gUart3.TransmitNum-(u8)1);  /*У���*/
        }
      }
    }
  }
  else
  {
    gUart3.TransmitDataByteIndex = 0;
  }
}

/**
  * @fn    void Arraycpy(void)
  * @brief ���鿽������
  * @par Parameters:
  * @retval void None
  */
void Arraycpy (uint8_t* ReceiveBuffer,uint8_t* SendBuffer,u8 Data_Number)
{
  u8 i;
  for(i = 0;i < Data_Number;i++)
  {
    *(ReceiveBuffer+i) = *(SendBuffer+i);
  }
}

  /**
  * @brief  < Add here the function description >
  * @note   < OPTIONAL: add here global note >
  * @param  Param1     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @param  Param2     < Add here the parameter description >
  * @note   < OPTIONAL: add here specific note for this parameter >
  * @retval returntype < Add here the description of the returned value >
  */
  uint8_t Uart3Checksum (uint8_t* Checksum_Buffer, uint8_t Data_Number)
  {
    uint8_t i=0;
    uint8_t Sum8=0;
    
    for(i = 0;i < Data_Number;i++)
    {
      Sum8 +=  *(Checksum_Buffer+i);
    }

    return (uint8_t)(Sum8);
  }

/**
  * @fn    void MCL_ModuleInit(void)
  * @brief �������ģ���ʼ��
  * @par Parameters:
  * @retval void None
  */

void APP_Uart3_Calc(void)
{  
  /*
  ���յ�0x55��ʼ��ʱ������50ms ��λIndex
  */
  if(gUart3.ReceptionTimeoutValue > (u8)50)
  {
    gUart3.ReceiveDataByteIndex = 0;
  }
  
  if(gUart3.ErrTimeoutValue > (u16)(1*1000)) /*���ճ�ʱ��ͣ��*/
  {
    gUart3.SpeedRef.W = 0;
    gUart3.ReceiveBuffer[0] = 0;      /*������ݣ����½���*/
    gUart3.ReceiveBuffer[1] = 0;    
    gUart3.ReceiveDataByteIndex = 0;  /*���ճ���9�����ݣ����´� 0���ݿ�ʼ����*/    
  }
  
  if (gUart3.DataReceived)
  {
    gUart3.DataReceived = 0;      
    
    if(gUart3.ReceiveDataByteIndex == (u8)0)
    {
      if(gUart3.ReceiveBuffer[gUart3.ReceiveDataByteIndex] == (u8)0x55)
      {  
        gUart3.ReceiveDataByteIndex = 1;
      }
    }
    else 
    {
      if(gUart3.ReceiveDataByteIndex < (u8)9)
      {  
        gUart3.ReceiveBuffer[gUart3.ReceiveDataByteIndex]=gUart3.UART3Data;
        gUart3.ReceiveDataByteIndex++;
      }
      else
      {
        gUart3.ReceiveBuffer[0] = 0;      /*������ݣ����½���*/
        gUart3.ReceiveBuffer[1] = 0;    
        gUart3.ReceiveDataByteIndex = 0;  /*���ճ���9�����ݣ����´� 0���ݿ�ʼ����*/
      }
      
      /*
       20191111
      gUart1.TransmitBuffer[1] = (u8)Ctl.WorkMode + (Ctl.Funmode<<2)+(gUart1.TransmitCommand<<5);  
      gUart1.TransmitBuffer[1] = (u8)Ctl.WorkMode + (Ctl.Funmode<<2);
      */
      
      if(gUart3.ReceiveDataByteIndex == (u8)8)
      {
        gUart3.Checksum = Uart3Checksum(gUart3.ReceiveBuffer,8);
        if(gUart3.ReceiveBuffer[8] == gUart3.Checksum)
        {
          gUart3.ErrTimeoutValue = 0;
          //gUart3.SpeedRef.B.H = gUart3.ReceiveBuffer[Ui.Fun.SlaveNumber]; //
          //gUart3.SpeedRef.B.L = gUart3.ReceiveBuffer[Ui.Fun.SlaveNumber+1]; //Ui.Fun.SlaveNumber
          //Ui.Fun.WorkMode = (WorkMode_TypeDef)(gUart3.ReceiveBuffer[1]&0x03); 
          //Ui.Fun.Funmode = (FunMode_TypeDef)((gUart3.ReceiveBuffer[1]>>2)&0x07);
        }
      }
    }   
  }
}

/**
* @brief  UART3 RX interrupt routine.
* @param  None
* @retval None
*/
INTERRUPT_HANDLER(UART3_RX_IRQHandler, 21)
{
  /* In order to detect unexpected events during development,
  it is recommended to set a breakpoint on the following instruction.
  */
  gUart3.UART3_SR_Buf = UART3->SR;
  gUart3.UART3Data = UART3->DR;

  /* Data received ? �Ƿ���ܵ�����*/
  if (gUart3.UART3_SR_Buf & UART3_SR_RXNE)
  {
    gUart3.DataReceived = 1;
    if(gUart3.ReceiveDataByteIndex == (u8)0)
    {  
      if(gUart3.UART3Data == (u8)0x55)
      {
        gUart3.ReceiveBuffer[gUart3.ReceiveDataByteIndex] = gUart3.UART3Data;   
        gUart3.ReceptionTimeoutValue = 1;
        gUart3.ErrTimeoutValue = 0;

      }
    }
  }
}
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/



