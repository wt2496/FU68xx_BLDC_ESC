/**
  ******************************************************************************
  * @file    \USER\src\MC_Pwimin.c 
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2019-01-25
  * @note    
  * @brief   PWMռ�ձȼ���
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2019 JK </center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "Bsp_Pwmin.h"
#include "MC_UserInterface.h"
#include "MC_MotorCotrol.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
PWMINCAP_TypeDef gPwminCap;
extern u8 tUiRefTarMaxFilter;
u8 tPowerOnFlag; /*JK-FABL039 ��ʱ�����������ж��ϵ�PWMIN������ �ϵ�X��5%��������*/
extern s8 gKL15Counter,gKL15Flag;
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
void APP_PwminDetection(void);
void tUiRefTarMaxFilterCalc(void);
void APP_PwminLostSignalCalc(void);
void APP_FeedbackFlagSignalCalc(void);
extern void gDelayms(u16 timer);
/**
  * @fn     void BSP_PwmIn_Init(void)    
  * @brief  

  * 24Mhz �ⲿ����64��Ƶ 
  * PWMIN����Ӳ������������Ҫ�����͵�ƽ��ռ�ձȡ�
  * TIM3_CH1  �½��غ������ش����жϣ��½���ʱ��λ��������
  * ���ʱ��174.76ms�����������Ϊ�źŶ�ʧ��0.5��
  *
  *
  * PWMIN���� Ƶ��
  * 7hz   -> 10hz  -> 100hz  -> 1khz -> 2khz
  * 53614 -> 37506 -> 3748   -> 373  -> 185

  * 50%ռ�ձ�ʱ��ƫ��
  * 26602  ->18611  -> 1863  ->189      -> 96
  * 49.61% ->49.62% -> 49.7% ->50.6~50.9->51.89 
  */
#define PWMIN_F_MIN      (4.0)       /* PWMNIN ��СƵ��*/
#define PWMIN_F_MAX      (310.5)       /* PWMIN ���Ƶ��*/

#define PWMIN_PERIOD_MAX (24000000/128/PWMIN_F_MIN)
#define PWMIN_PERIOD_MIN (24000000/128/PWMIN_F_MAX)



void BSP_PwmIn_Init(void)
{  
  GPIO_Init(PWMIN_PORT, PWMIN_BIT, GPIO_MODE_OUT_PP_LOW_FAST);   //
    
  TIM3_DeInit();                                         /*tim3 ��ʱ���Ĵ���ȫ����λ */
  TIM3_TimeBaseInit(TIM3_PRESCALER_128, 65535);
  TIM3_PWMIConfig(TIM3_CHANNEL_1, TIM3_ICPOLARITY_RISING, TIM3_ICSELECTION_DIRECTTI, TIM3_ICPSC_DIV1, 0x00); 
  //ѡ��TI1���������ش��� ѡ��TI2�����½��ش��� ���벶׽Ԥ������  ���˲�
  
  //ITC_SetSoftwarePriority(ITC_IRQ_TIM3_CAPCOM,ITC_PRIORITYLEVEL_1);
  //ITC_SetSoftwarePriority(ITC_IRQ_TIM3_OVF,ITC_PRIORITYLEVEL_1);
  ITC_SetSoftwarePriority(ITC_IRQ_TIM3_CAPCOM,ITC_PRIORITYLEVEL_1);
  TIM3_ClearFlag(TIM3_FLAG_CC1);                       
  TIM3_ClearFlag(TIM3_FLAG_CC2);                       
  TIM3_ITConfig( TIM3_IT_CC1, ENABLE);                 
  TIM3_ITConfig( TIM3_IT_CC2, ENABLE);                  
  TIM3_CCxCmd(TIM3_CHANNEL_1, ENABLE);                
  TIM3_CCxCmd(TIM3_CHANNEL_2, ENABLE);                 
  TIM3_Cmd(ENABLE);   
  gDelayms(7);
  
  GPIO_Init(PWMIN_PORT, PWMIN_BIT, GPIO_MODE_IN_PU_NO_IT);	    /*PD2 ��?��?   */
}


/**
  * @fn     INTERRUPT_HANDLER
  * @brief  �����ж�ִ��ʱ��4.44us *Time
  * @note   None
  * @retval None
  */
INTERRUPT_HANDLER(TIM3_CAP_COM_IRQHandler, 16)
{
  if((TIM3->SR1)&(u8)TIM3_IT_CC2)   /*�����ж���Ҫʱ�� ����1*/ 
  {  
    TIM3->CNTRH =  (uint8_t)0;      
    TIM3->CNTRL =  (uint8_t)0;     
    gPwminCap.TimOvCounter = 0;
    gPwminCap.Data1.B.H = TIM3->CCR2H;
    gPwminCap.Data1.B.L = TIM3->CCR2L;
    gPwminCap.Period = gPwminCap.Data1.W+(u8)8;
    
    TIM3_ClearITPendingBit(TIM3_IT_CC2);      
  }
  
  if((TIM3->SR1)&(u8)TIM3_IT_CC1) 
  { 
    gPwminCap.Pulse = 0x7F;
    gPwminCap.Data2.B.H = TIM3->CCR1H;
    gPwminCap.Data2.B.L = TIM3->CCR1L;
    gPwminCap.H_Cur = gPwminCap.Data2.W+(u8)8;
    
    TIM3_ClearITPendingBit(TIM3_IT_CC1); 
  }
}

/**
  * @fn     BSP_PwminCap_Calc
  * @brief  ����ģʽ����ռ�ձ�

  * gPwminCap.SignaCounter �����ж��ź�PWM�Ƿ�ʧ��
  *  �߼����ж�PWMIN��λ��gPwminCap.SignaCounter == 10��->  PWMIN��ʧ
  * @note   None
  * @retval None
  */

s8 tSpefMaxFilterCounter,tSpefMaxFlag;

void APP_PwminCap_Calc(void)
{
  s16 temp,tUiRefTar,i;
    
  if((TIM3->SR1)&(u8)0x01)                               /* TIM3_UIF ����жϱ�־*/
  {  
    TIM3->SR1  &= (uint8_t)(~(uint8_t)((uint8_t)1<<0));  /*�����־*/
    if(gPwminCap.TimOvCounter < (u8)1)
    {  
      gPwminCap.TimOvCounter++;
      gPwminCap.H_Cur = 0;
    }
    else
    {
       //Ui.OnOffFilterCounter--;
       Ui.KLPwmPCT3Counter = 0;
       Ui.KLPwmPCT97Counter = 0;
       if(gPwminCap.SignaCounter == 10)  /*����PWM�ź�*/
       {
         /*
         �źŶ�ʧ����ͣ���ź�
         */
       }
    }
  }
  else                                  /*KL.PWM û�����*/
  {   
    if(gKL15Flag != 0x7F)               /*KL15 ����*/
    {  
      if(gPwminCap.Pulse == (u8)0x7F)   /*��KL.PWM �ź�*/
      {  
        gPwminCap.Pulse  = (u8)0xFF;
        Ui.Pwmin.LostSignalFlag = (s8)0xFF;
        Ui.Pwmin.L_Cur = (u8)0;           /*PWMIN���ź����룬�������*/
        Ui.Pwmin.H_Cur = (u8)0;           /*PWMIN���ź����룬�������*/
        
        temp = gPwminCap.H_Cur - gPwminCap.H_Per;
        gPwminCap.H_Per = gPwminCap.H_Cur;
          
        if((temp < (s16)(30))&&(temp >(s16)(-30)))  /*�˲������źţ�����ֵ ����5*/
        {  
          if(gPwminCap.SignaCounter < (s8)10)
          {  
            gPwminCap.SignaCounter++;
          }
          
          if((gPwminCap.Period < PWMIN_PERIOD_MAX)&&(gPwminCap.Period > PWMIN_PERIOD_MIN)) /*Ƶ�ʷ�Χ��*/
          {  
            Ctl.Vtim.Tle7184SleepTimCounter = 0;
            
            gPwminCap.L_Cur = gPwminCap.Period - gPwminCap.H_Cur;
            
            if(gPwminCap.H_Cur < gPwminCap.Period)      /*������ȷ��x*/
            {  
              gPwminCap.Duty = ((u32)gPwminCap.H_Cur*4095/gPwminCap.Period);
              #if(1)
              gPwminCap.fDuty = ((float) gPwminCap.H_Cur / gPwminCap.Period); 
              #endif
              
              gPwminCap.DutyAvg = gPwminCap.Duty;
//                
//              gPwminCap.DutySum += gPwminCap.Duty ;
//              gPwminCap.DutyAvg = gPwminCap.DutySum>>1;
//              gPwminCap.DutySum -= gPwminCap.DutyAvg ;     
              
              if((gPwminCap.DutyAvg >= IQ(0.04)) && (gPwminCap.DutyAvg < IQ(0.952)))
              {
                 if(tSpefMaxFilterCounter < 10)
                 {
                   tSpefMaxFilterCounter++;
                 }
                 else
                 {
                   Ctl.Vtim.Ui100msPtr = 120; /*�˲����*/
                   tSpefMaxFlag = 0x7F;       /* �ϵ��Ƿ��� 4%~96% ����*/
                 }
              }
              else
              {
                 if(tSpefMaxFilterCounter > -10)
                 {
                   tSpefMaxFilterCounter--;
                 }
                 else
                 {
                    if(Ctl.Vtim.Ui100msPtr >= 120)
                    {
                      Ctl.Vtim.Ui100msPtr = 120; 
                      tSpefMaxFlag = 0x7F;                   
                    }                    
                 }
              }
              
              if(gPwminCap.DutyAvg < IQ(0.04))    /* X>91.5%*/
              {
                if((gKL15Flag == 0x7F)||(tSpefMaxFlag != 0x7F ))               /*KL15����*/
                {  
                   Ui.OnOffFilterCounter--;
                }
                else
                {
                  if( Ui.flg.START == (u8)FALSE)
                  {
                    Ui.OnOffFilterCounter++;            
                  }
                  tUiRefTarMaxFilterCalc(); 
                }
              }                   
              else if(gPwminCap.DutyAvg < IQ(0.148))    /* <0.095*/
              {
                Ui.OnOffFilterCounter--;
                if(tUiRefTarMaxFilter > 0)
                {
                  tUiRefTarMaxFilter--;
                }
              }
              else if(gPwminCap.DutyAvg < IQ(0.149)) /* <0.095*/
              {
                ;
              }          
              else if(gPwminCap.DutyAvg < IQ(0.880)) /* 0.1 <X < 0.9*/
              {
                Ui.OnOffFilterCounter++;
                
                tUiRefTar = IQmpy(gPwminCap.DutyAvg,SPEED_SCALER_A)+ SPEED_SCALER_B; /*D*0.5677+0.414 -> D*1793+1242*/

                if(tUiRefTar > IQ(2400.0/3000.0))
                {
                  Ctl.Spd.UiRefTar = IQ(2400.0/3000.0);
                }
                else
                {  
                  Ctl.Spd.UiRefTar = tUiRefTar;
                }
               
                if(tUiRefTarMaxFilter > (u8)0)
                {
                  tUiRefTarMaxFilter--;
                }
              }
              else if(gPwminCap.DutyAvg < IQ(0.885))   
              {
                Ui.OnOffFilterCounter++;
                if(Ctl.Spd.UiRefTar != SPEED_MAX_SEF_TEMP)
                {
                  Ctl.Spd.UiRefTar = SPEED_MAX_SEF_TEMP;
                }  
                else
                {
                  Ctl.Spd.UiRefTar = IQ(2400.0/3000.0); 
                }
              }
              else if(gPwminCap.DutyAvg < IQ(0.89))  
              {
                ;
              }
              else if(gPwminCap.DutyAvg < IQ(0.96))
              {
                if(gKL15Flag == 0x7F)               /*KL15����*/
                {  
                   Ui.OnOffFilterCounter--;
                }
                else
                {  
                  if( Ui.flg.START == (u8)FALSE)
                  {
                    Ui.OnOffFilterCounter++;            
                  }
                  tUiRefTarMaxFilterCalc();
                }
              }
              else
              {
                 if((gKL15Flag == 0x7F)||(tSpefMaxFlag != 0x7F ))               /*KL15����*/
                {  
                   Ui.OnOffFilterCounter--;
                }
                else
                {
                  if( Ui.flg.START == (u8)FALSE)
                  {
                    Ui.OnOffFilterCounter++;            
                  }
                  tUiRefTarMaxFilterCalc(); 
                }             
              }
              
              /*�����ж�*/
              APP_FeedbackFlagSignalCalc();
            }
          }
          else  /*��������Ƶ�ʣ����ٵ����ת��*/
          {
            if(gKL15Flag == 0x7F)               /*KL15����*/
            {  
               Ui.OnOffFilterCounter--;
            }
            else
            {
              if(Ui.flg.START == (u8)FALSE)    /*KL15δ����*/
              {
                Ui.OnOffFilterCounter++;            
              }
              tUiRefTarMaxFilterCalc(); 
            }
          }
        }			
      }
      else /*��PWM����*/
      {
        //Ui.OnOffFilterCounter--;
      }
    }
    else  /*KL15 ����*/
    {
      //Ui.OnOffFilterCounter--;
    }
  }
}

/**
  * @fn     tUiRefTarMaxFilterCalc
  * @brief  �������ת�� �˲��������ж� �Ƿ�������ת�ٵ���
  * @note   None
  * @retval None
  */
void tUiRefTarMaxFilterCalc(void)
{
  if(tUiRefTarMaxFilter < (u8)20)
  {
    tUiRefTarMaxFilter++;     
  }  
  
  if(tUiRefTarMaxFilter > (u8)15)
  {  
    Ctl.Spd.UiRefTar = SPEED_MAX_SEF_TEMP;
  }         
  else if(tUiRefTarMaxFilter < (u8)10)
  {
    Ctl.Spd.UiRefTar = IQ(2590.0/3000.0);   
  }
  else
  {
   ;
  }
}


/**
  * @fn     APP_PwminLostSignalCalc
  * @brief 
  * gPwminCap.SignaCounter �����ж��ź�PWM�Ƿ�ʧ��
  *  �߼����ж�PWMIN��λ��gPwminCap.SignaCounter == 10��->  PWMIN��ʧ
  * @note   None
  * @retval None
  */
void APP_PwminLostSignalCalc(void)
{
  /*���FB������ */
  if((FBIN_IDR & (u8)FBIN_BIT) == FBIN_BIT)
  {
    if(gKL15Counter < 10)
    {
      gKL15Counter++;
    }
    else
    {
      gKL15Flag = 0xFF;
    }
  }
  else
  {
    if(gKL15Counter > -10)
    {
      gKL15Counter--;
    }
    else
    {
      gKL15Flag = 0x7F;  /*KL15����*/
    }
  }
    
  if(FB_IDR&FB_BIT)
  {
  
  }
  else
  { 
    if((PWMIN_IDR & (u8)PWMIN_BIT) == PWMIN_BIT)
    {
      Ui.Pwmin.L_Cur = 0;
      if(Ui.Pwmin.H_Cur < (u8)250)
      {  
        Ui.Pwmin.H_Cur++;                /*PWMIN�ź���*/
      }
      else
      {
        Ui.Pwmin.LostSignalFlag = 0x72; 
      }
    }
    else
    {
      Ui.Pwmin.H_Cur = 0;
      if(Ui.Pwmin.L_Cur < (u8)250)
      {  
        Ui.Pwmin.L_Cur++;
      }
      else
      {
        Ui.OnOffFilterCounter--;         /*PWMIN û�н� ͣ�� FABL029 */
        Ui.Pwmin.LostSignalFlag = 0x73;  /*PWMIN 7F->�źŶ�ʧ   FF->�ź���λ*/
      }
    }
    
    if((Ui.Pwmin.LostSignalFlag == 0x72)||(Ui.Pwmin.LostSignalFlag == 0x73))
    {
      if(Ui.flg.START == (u8)FALSE)    /*KL15δ����*/
      {
        Ui.OnOffFilterCounter++;            
      }
      tUiRefTarMaxFilterCalc();   
    }
  }
   
  #if(0)
  if(Ui.Pwmin.LostSignalFlag == 0x7F)        /*PWMIN �źŶ�ʧ*/
  {  
    /* 20190221
     �쳣�ź���������
     a��PWMIN �ӵأ���Ϊ�ڲ������� 50ms
     b��FB �Ӹ� ���ⲿ������ 50ms
     c��PWMIN ��ʧ 50ms
     */
    if((Ui.Pwmin.SignalTimCunter == (s8)30)||(Ui.Fb.LostSignalFlag == (s8)0x71)||(Ui.Pwmin.H_Cur >= (u8)200)) /*PWMIN������λ������FB��λ*/
    {  
      Ui.Pwmin.LostSignalTimCunter++;
    }
  }
  else      
  {
    if(Ui.Pwmin.SignalTimCunter < (s8)30) /*�ж�PWMIN �ź���λʱ��30ms*/
    {
      Ui.Pwmin.SignalTimCunter++;
    }
    
    if( Ui.Pwmin.LostSignalTimCunter > 0)
    {  
      Ui.Pwmin.LostSignalTimCunter--;
    }
  }
  #endif
}


/**
  * @fn     APP_FeedbackFlagSignalCalc
  * @brief 
  * gPwminCap.SignaCounter �����ж��ź�PWM�Ƿ�ʧ��
  *  �߼����ж�PWMIN��λ��gPwminCap.SignaCounter == 10��->  PWMIN��ʧ
  * @note   None
  * @retval None
  */
void APP_FeedbackFlagSignalCalc(void)
{
  #if(0)
  /*JK-FABL039 ���з���ģʽ*/
  if(Ui.flg.START == (u8)FALSE)
  {
    if(gPwminCap.DutyAvg > IQ(1.0-0.065))
    {
      Ui.KLPwmFeedbackFlag = 0x72;
    }
    else
    {
      Ui.KLPwmFeedbackFlag = 0x70;
    }
  }
  else
  {
    Ui.KLPwmFeedbackFlag = 0x70;
  }
  
  /*�ж��Ƿ��״�С��4.5%*/
  if(gPwminCap.DutyAvg >= IQ(1.0-0.045))
  {
    tPowerOnFlag = 0x7F;
  }
  #endif

  #if(0)
  /*
  20190821 PWMС�ڵ���4%�� 
  0x70 ����
  0x71 3%
  0x72 97%
  0x73 ���ڷ���
  */     
  if((gPwminCap.DutyAvg >= IQ(0.025))&&(gPwminCap.DutyAvg <= IQ(0.035)))      /*97%*/
  {
    if(Ui.KLPwmPCT3Counter < 10)
    {  
      Ui.KLPwmPCT3Counter++;
    }    
    else
    {
      if(Ui.KLPwmFeedbackFlag != 0x73)
      {  
        Ui.KLPwmFeedbackFlag = 0x71;     /**/
      }
    } 
   
    if(Ui.KLPwmPCT97Counter > -10)
    {  
      Ui.KLPwmPCT97Counter--;
    }                     
  }            

  if(gPwminCap.DutyAvg >= IQ(1.0-0.045))   
  {
    if(Ui.KLPwmPCT97Counter < 10)
    {  
      Ui.KLPwmPCT97Counter++;
    }    
    else
    {
      tPowerOnFlag = 0x7F;
      if(Ui.KLPwmFeedbackFlag != 0x73)
      {  
        Ui.KLPwmFeedbackFlag  = 0x72;     /**/
      }
    }    
    
    if(Ui.KLPwmPCT3Counter > -10)
    {  
      Ui.KLPwmPCT3Counter--;
    }     
  }
  else
  {
    Ui.KLPwmFeedbackFlag  = 0x70;

    if(Ui.KLPwmPCT3Counter > -10)
    {  
      Ui.KLPwmPCT3Counter--;
    }                
  
    if(Ui.KLPwmPCT97Counter > -10)
    {  
      Ui.KLPwmPCT97Counter--;
    }                
  }
  #endif
}
/*
INTERRUPT_HANDLER(TIM3_UPD_OVF_BRK_IRQHandler, 15)
{
}

INTERRUPT_HANDLER(TIM3_CAP_COM_IRQHandler, 16)
{
}
*/



