/**
  ******************************************************************************
  * @file    \USER\src\MC_Dmc.c  
  * @author  tom.wang Application Team
  * @version        
  * @since
  * @date    2018-10-17
  * @note    
  * @brief   ��ѧ����
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "Bsp_Uart3.h"
#include "MC_DMC.h" 
#include "MC_MotorCotrol.h"  
#include "MC_MotorDrive.h"  
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
PIDREG  pid_spd ; 

extern s16 gEventPeriodErr;
/* Private function prototypes -----------------------------------------------*/
void Dmc_SpdPidInit(void);
void Dmc_SpdPidDefault(void);
void Dmc_SpdPidCalc(void);
void Dmc_GetConversionValue(void);
/* Private functions ---------------------------------------------------------*/





/**
  * @fn     void AdcGetConversionValue(void)    
  * @brief  
  * @retval None
  */

/*
20191129 tom
ʹ��ʱע��ѣ��ٶȼ��� ���ȼ�����Ϊ1��2
1��ʵ���¶ȼ���   ����
2��ʵ�ʵ�ѹ����   ����˷�
3��ʵ�ʵ�������   ����˷�
4���ٶȼ��� ��ôֵ  �������
5���ٶȼ��� ʵ��ֵ  ����˷�
6��
7��

*/
void Dmc_GetConversionValue(void)
{ 
  if(Drv.MduCalcFlag < (u8)20)
  {
    Drv.MduCalcFlag++;
  }
  else
  {
    Drv.MduCalcFlag = 1;
  }
  
  if(Drv.MduCalcFlag == (u8)3)
  {
    #if (OH1_EN == 2)
    /*Drv.AdcMeas.Th1 = TH_B - Drv.AdcMeas.Vth1Meas*TH_A;*/
    /*Drv.AdcMeas.Th2 = 496 - (((u32)2547*Drv.AdcMeas.Vth1Meas)>>12);*/   /* Th2 s16*/
    Drv.AdcMeas.Th2 = Drv.AdcMeas.Vth1Meas - 279;
    #endif
  }
  else if(Drv.MduCalcFlag == (u8)4)
  {
    #if (VBUS_CALC_EN==2)
    Drv.AdcMeas.Vdc = Drv.AdcMeas.VdcAvgMeas*VDCMEASEGAIN;
    #endif
  }
  else if(Drv.MduCalcFlag == (u8)5)
  {
    Drv.AdcMeas.Ibus = Drv.AdcMeas.ImeasBus*IBUSMEASGAIN; /*Drv.AdcMeas.IBusMeasGain; */
  }
  else if(Drv.MduCalcFlag == (u8)6)
  {
    gUart3.TransmitBuffer.BufferByte.Temp = Drv.AdcMeas.Th2;
    if(gUart3.TransmitBuffer.BufferByte.PowerOnTim.W >= (u16)65500)
    {
      gUart3.TransmitBuffer.BufferByte.PowerOnTim.W = (u16)65500;
    }
    if(gUart3.TransmitBuffer.BufferByte.RunTim.W >= (u16)65500)
    {
      gUart3.TransmitBuffer.BufferByte.RunTim.W = (u16)65500;
    }    
  }
  else if(Drv.MduCalcFlag == (u8)7)
  {
    gUart3.TransmitBuffer.BufferByte.Sref.W = Ctl.Spd.RefCur;
  }
  else if(Drv.MduCalcFlag == (u8)8)
  {
    gUart3.TransmitBuffer.BufferByte.Ibus = Drv.AdcMeas.Ibus*2;   /*����0.1A*/
  }
  else if(Drv.MduCalcFlag == (u8)9)
  {
    gUart3.TransmitBuffer.BufferByte.Vbus = Drv.AdcMeas.Vdc*5;    /*��ѹ 0.2V*/
  }
  else if(Drv.MduCalcFlag == (u8)10)
  {
    gUart3.TransmitBuffer.BufferByte.Fbd.W = Ctl.Spd.FdbSpeedRpm;
    gUart3.TransmitBuffer.BufferByte.ErrorCode = Ctl.SysError.Code;
    gUart3.TransmitBuffer.BufferByte.State = Ctl.State;
  }
  else
  {
  
  }
  
  
}
/**
  * @fn     void Dmc_SpdPidInit(void)    
  * @brief  �ٶȱջ�PI��ʼ��   
  * @retval None
  */

#define SPEED_KD  IQ(0.1)    
#define SPEED_KC  IQ(0.1)
    
void Dmc_SpdPidInit(void)
{
  pid_spd.Ref  = IQ(0.5);
  pid_spd.Fdb  = 0;
  pid_spd.Kp   = SPEED_KP;
  pid_spd.Ki   = SPEED_KI;
  pid_spd.Kc   = SPEED_KC;
  pid_spd.Kd   = SPEED_KD;  
  pid_spd.Out  = 0;
  pid_spd.Up   = 0;
  pid_spd.Ui   = 0;
  pid_spd.OutPreSat = 0;
  pid_spd.OutMax = IQ(1.0);
  pid_spd.OutMin = IQ(0.01);
  pid_spd.Err = 0; 
  pid_spd.Err_1 = 0; 
}

void Dmc_SpdPidDefault(void)
{
  pid_spd.Fdb  = 0;
//  pid_spd.Kp   = SPEED_KP;
//  pid_spd.Ki   = SPEED_KI;
//  pid_spd.Ki_p = SPEED_KI_P;//pid_spd.Ki;//IQ(1.0);
//  pid_spd.Ki_n = SPEED_KI_N;//pid_spd.Ki;//IQ(0.05);
//  pid_spd.Kc   = SPEED_KC;
//  pid_spd.Kd   = SPEED_KD;  
  pid_spd.Out  = 0;
  pid_spd.Up   = 0;
  pid_spd.Ui   = 0;
  pid_spd.OutPreSat = 0;
  pid_spd.OutMax = IQ(1.0);
  pid_spd.OutMin = IQ(0.01);
  pid_spd.Err = 0; 
  pid_spd.Err_1 = 0; 
}

/**
  * @fn     void Dmc_SpdPidCalc(void)    
  * @brief  ����ʽPI���� 
  *         ��ʽIQ12��ʽ
  *         ������Ref��Fdb��KP��KI
  *               KD,KC
  *         ��Uk = Uk - U��k-1�� = Aek + B*e��k-1��* Ce(k-2)
  * @retval None
  */
#if(0)
void Dmc_SpdPidCalc(void)   
{
  s16 tErr_I,tErr_D;
  
  /* Compute the error */
  pid_spd.Err = pid_spd.Ref - pid_spd.Fdb ;

  tErr_I = pid_spd.Err - pid_spd.Err_1;
  
  /* Compute the proportional output  */
  pid_spd.Up = IQmpy(pid_spd.Kp,tErr_I);

  /* Compute the integral output 
  pid_spd.Ui = IQmpy(pid_spd.Ki,pid_spd.Err)+IQmpy(pid_spd.Kc,pid_spd.SatErr);
  */
  pid_spd.Ui = IQmpy(pid_spd.Ki,pid_spd.Err);
  
  /*
  if(pid_spd.Err > 0)
  pid_spd.Ui = IQmpy(pid_spd.Ki_p,pid_spd.Err);
  else
  pid_spd.Ui = IQmpy(pid_spd.Ki_n,pid_spd.Err); 
  */
  
  /*Compute the derivative output */
  
  /*
  ����Ud ���㣺

  tErr_D = pid_spd.Err - pid_spd.Err_1*2 + pid_spd.Err_2;
  pid_spd.Ud = IQmpy(pid_spd.Kd,tErr_D);
  pid_spd.Err_2 = pid_spd.Err_1;

  �򻯵�Ud ���㣺

  pid_spd.Ud = IQmpy(pid_spd.Kd,pid_spd.Err_2);
  pid_spd.Err_2 = pid_spd.Err_1;
  */

  pid_spd.Err_1 =  pid_spd.Err;
  
  /* Compute the pre-saturated output */
  pid_spd.OutPreSat = pid_spd.Out + pid_spd.Up + pid_spd.Ui;

  /* Saturate the output */
  if (pid_spd.OutPreSat > pid_spd.OutMax) 
  { 
    pid_spd.Out =  pid_spd.OutMax;
  }
  else if (pid_spd.OutPreSat < pid_spd.OutMin)
  {
    pid_spd.Out =  pid_spd.OutMin;  
  }
  else
  {
    pid_spd.Out = pid_spd.OutPreSat;                     
  }

  /* Kc 
  pid_spd.SatErr = pid_spd.Out - pid_spd.OutPreSat;
  
  pid_spd.UpPre =  pid_spd.Up;
  */
  
  Drv.PWM.DutyCur = pid_spd.Out;
 
}
#else 
/*
PI����ʱ�� 56us 
û��KC,pid_spd.SatErr

������һ���˷������㡣
*/
void Dmc_SpdPidCalc(void)   
{
  /* Compute the error */
  pid_spd.Err = pid_spd.Ref - pid_spd.Fdb;

  /*Compute the proportional output*/
  pid_spd.Up = IQmpy(pid_spd.Kp,pid_spd.Err);

  /* Compute the integral output */
  pid_spd.Ui = pid_spd.Ui + IQmpy(pid_spd.Ki,pid_spd.Up);// + IQmpy(pid_spd.Kc,pid_spd.SatErr);

  /* �����޷������������*/
  if(pid_spd.Ui < -IQ(1.0))
  {
    pid_spd.Ui = -IQ(1.0);
  }
  else if(pid_spd.Ui > IQ(1.0))
  {
    pid_spd.Ui = IQ(1.0);
  }
  else
  {
  
  }
  /* Compute the derivative output*/
  //pid_spd.Ud = IQmpy(pid_spd.Kd,(pid_spd.Up - pid_spd.UpPre));

  /* Compute the pre-saturated output */
  pid_spd.OutPreSat = pid_spd.Up + pid_spd.Ui;// + pid_spd.Ud;     

  /* Saturate the output */
  if (pid_spd.OutPreSat > pid_spd.OutMax)  
  { 
    pid_spd.Out =  pid_spd.OutMax;
  }
  else if (pid_spd.OutPreSat < pid_spd.OutMin)
  { 
    pid_spd.Out =  pid_spd.OutMin;
  }
  else
  {  
    pid_spd.Out = pid_spd.OutPreSat;
  }

  /* Compute the saturate difference */
  //pid_spd.SatErr = pid_spd.Out - pid_spd.OutPreSat;     

  /* Update the previous proportional output */
  //pid_spd.UpPre = pid_spd.Up;   
}
#endif



#if(0)
void Dmc_SpdPidCalc(void)   
{
  s16 tErr_I,tErr_D;
  
  /* Compute the error */
  pid_spd.Err = pid_spd.Ref - pid_spd.Fdb ;
 
  tErr_I = pid_spd.Err - pid_spd.Err_1;
  
  pid_spd.Err_1 =  pid_spd.Err;
   
  /* Compute the proportional output */
  pid_spd.Up = IQmpy(pid_spd.Kp,tErr_I);

  /* Compute the integral output */
  pid_spd.Ui = IQmpy(pid_spd.Ki,pid_spd.Err);
  
  /* Compute the pre-saturated output */
  pid_spd.OutPreSat = pid_spd.Out + pid_spd.Up + pid_spd.Ui;

  /* Saturate the output */
  if (pid_spd.OutPreSat > pid_spd.OutMax) 
  { 
    pid_spd.Out =  pid_spd.OutMax;
  }
  else if (pid_spd.OutPreSat < pid_spd.OutMin)
  {
    pid_spd.Out =  pid_spd.OutMin;  
  }
  else
  {
    pid_spd.Out = pid_spd.OutPreSat;                     
  }
  
  Drv.PWM.DutyCur = pid_spd.Out;
  
}



void Dmc_SpdPidCalc(void)   
{
  /* Compute the error */
  pid_spd.Err = pid_spd.Ref - pid_spd.Fdb;

  /*Compute the proportional output*/
  pid_spd.Up = IQmpy(pid_spd.Kp,pid_spd.Err);

  /* Compute the integral output */
  pid_spd.Ui = pid_spd.Ui + IQmpy(pid_spd.Ki,pid_spd.Up) + IQmpy(pid_spd.Kc,pid_spd.SatErr);

  /* Compute the derivative output*/
  pid_spd.Ud = IQmpy(pid_spd.Kd,(pid_spd.Up - pid_spd.UpPre));

  /* Compute the pre-saturated output */
  pid_spd.OutPreSat = pid_spd.Up + pid_spd.Ui + pid_spd.Ud;     

  /* Saturate the output */
  if (pid_spd.OutPreSat > pid_spd.OutMax)                   
    pid_spd.Out =  pid_spd.OutMax;
  else if (pid_spd.OutPreSat < pid_spd.OutMin)
    pid_spd.Out =  pid_spd.OutMin;  
  else
    pid_spd.Out = pid_spd.OutPreSat;                   

  /* Compute the saturate difference */
  pid_spd.SatErr = pid_spd.Out - pid_spd.OutPreSat;     

  /* Update the previous proportional output */
  pid_spd.UpPre = pid_spd.Up;   
  
  Drv.PWM.DutyCur = pid_spd.Out; 
}
#endif


/*
s16 Pid_calc(PIDREG *v)   
{
  / Compute the error
  v->Err = v->Ref - v->Fdb;

  // Compute the proportional output
  v->Up = v->Kp*v->Err;

  // Compute the integral output
  v->Ui = v->Ui + v->Ki*v->Up + v->Kc*v->SatErr;

  // Compute the derivative output
  v->Ud = v->Kd*(v->Up - v->Up1);

  // Compute the pre-saturated output
  v->OutPreSat = v->Up + v->Ui + v->Ud;     

  // Saturate the output
  if (v->OutPreSat > v->OutMax)                   
    v->Out =  v->OutMax;
  else if (v->OutPreSat < v->OutMin)
    v->Out =  v->OutMin;  
  else
    v->Out = v->OutPreSat;                   

  // Compute the saturate difference
  v->SatErr = v->Out - v->OutPreSat;     

  // Update the previous proportional output 
  v->Up1 = v->Up;   

  return v->Out;
}
*/

