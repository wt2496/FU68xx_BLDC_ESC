/**
  ******************************************************************************
  * @file    \USER\src\MC_UserInterface.c
  * @author  Application Team  Tom.wang
  * @version
  * @since
  * @date    2018-10-17
  * @note
  * @brief   �˻�������
  ******************************************************************************
  * @attention
  * <h2><center>&copy; COPYRIGHT 2018 JK </center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm8s_conf.h"
#include "user_conf.h"
#include "Bsp_Pwmin.h"
#include "Bsp_Uart3.h"
#include "MC_init.h"
#include "MC_DMC.h" 
#include "MC_UserInterface.h"
#include "MC_MotorCotrol.h"
#include "MC_MotorDrive.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

#define LEDFAULTDIS_EN    0 /*����LEDָʾ*/

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
  /**
  *  @brief �˻�����������ṹ��
  */
  Ui_TypeDef  Ui;

  /**
  *  @brief
  */

u8  tFG_25or75Flag;
u8  tFG_25or75Error;
u8  tUiRefTarMaxFilter;
s8  gKL15Counter,gKL15Flag;


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
void Ui_Function(void);
void Drv_Handle(void);
void APP_UserCmdSrefIn(void);
void APP_FaultLed(void);
void APP_FGoutHandle(void);
void APP_ONOFF_TEST(void);
void APP_UserCmdHandle(void);
void APP_ErrRecoverHandle(void);
void APP_UserCmdSetOnoff(void);
void APP_DeratingOut(void);

/**
  * @fn     void Ui_Function(void)
  * @brief  1��PWM�ٶȸ���
  *         2����ͣ�źŸ���
  * @retval None
  */
void Ui_Function(void)
{
  /*��·���ϼ�� ���ϻָ�*/
  Drv_Handle();            /*�������� */     
 
  Drv_SpeedClac();         /*�ٶȼ���*/

  Dmc_GetConversionValue(); /*ʵ��ֵת��*/
  
  APP_ErrRecoverHandle();  /*Vbus �ָ����*/
  
  /*APP_FaultLed(); */         /*����ָʾ */
  
  //APP_FGoutHandle();       /*FG��� */
   
  /*������� ��ͣ���ٶȣ�����ת*/
  /*Ui.flg.FR = CW;*/
  APP_PwminCap_Calc();   /*����ģʽ�����ٶ�*/
  
  APP_UserCmdSrefIn();   /*�ٶȸ�������*/
    
 #if (0)                 
  APP_ONOFF_TEST();       /*�Զ���ͣ����*/
 #else  
  APP_UserCmdSetOnoff();   /*�����������*/
 #endif

  /* ����������ִ��  */
  APP_UserCmdHandle();
  
  //APP_Uart3_Task();
}

/**
  * @fn     void APP_UserCmdHandle(void)
  * @brief  �û�����ִ��
  * @retval None
  */
void APP_UserCmdHandle(void)
{
  if((Ui.flg.START == (u8)TRUE)&&(Ui.flg.FR != (u8)NONE))
  {
    if(Ctl.gStartC == (s8)FALSE)
    {
      Ui.Fb.LostSignalFlag = 0x71;   /*�����������PWM����FB�н�ECU*/
      Ctl.gStartC = (s8)TRUE;
      Ctl.gDirectionC = Ui.flg.FR;
    }
    Ctl.Spd.SlowingDownFlag = 0X7F;
  }
  else if(Ui.flg.START == (u8)FALSE)
  {
    if(Ctl.gStopmodeC == FREE_DOWN)
    {
      Ctl.gStartC = (s8)FALSE;
    }
    else if(Ctl.gStopmodeC == BREAK_DOWN)
    {
      Ctl.gStartC = (s8)FALSE;
    }
    else if(Ctl.gStopmodeC == SLOWING_DOWN)
    {
      if(Ctl.State == MOTOR_NORMAL)
      {
        Ctl.Spd.RefTar = 0;
        Ctl.Spd.SlowingDownFlag = 0XFF;
        #if(SPEED_CLOSE_EN)
        if(Ctl.Spd.RefCur <= SPEED_MIN_SEF_TEMP)
        {
          Ctl.Spd.SlowingDownFlag = 0X7F;
          Ctl.gStartC = (s8)FALSE;
        }
        #else
        if(Ctl.Spd.RefCur <= IQ(RAMP_DUTY))
        {
          Ctl.Spd.SlowingDownFlag = 0X7F;
          Ctl.gStartC = (s8)FALSE;
        }
        #endif
      }
      else
      {
        Ctl.gStartC = (s8)FALSE;
      }
    }
    else
    {
      ;
    }
  }
  else
  {
    ;
  }
}

/**
  * @fn     void APP_ErrRecoverHandle(void)
  * @brief  �������
  * @retval None
  */
void APP_ErrRecoverHandle(void)
{
  /*Ƿ��ѹ���ϣ���� */
  if((Ctl.SysError.Code  != NONE)&&(Ctl.SysError.Code  < E_8174))
  {
    if((Ctl.SysError.Code  == E_OV)||(Ctl.SysError.Code  == E_UV))
    {
      if(Ctl.Vtim.Nonms == NONMS)
      {
        Ctl.SysError.Code = NONE;
        Ctl.State = MOTOR_STOP;
      }
    }
  }
  
  /*���±������ϣ��Զ�������� */
  if(Ctl.SysError.Code == E_OH1)
  {
    if(Ctl.Fail.OHLevel > 0xF2)
    {
      Ctl.SysError.Code = NONE;
      Ctl.State = MOTOR_STOP; /*MOTOR_READY*/;
    }
  }

  /*
  TOM 20190617
  �Լ�ʱ7184���ϣ���������10��
  5��һ�Σ�����һ����
  */
  if(Ctl.SysError.Code == E_8174)
  {  
    if(Ctl.IPD.DsovRestartNum < 12)
    {
      if(Ctl.IPD.DsovRestartTimCounter > 50)     /*5�� �ָ�����*/
      {
        Ctl.IPD.DsovRestartTimCounter = 0;
        Drv_7184ClearError();        
        Ctl.SysError.Code = NONE;   
        Ctl.State = MOTOR_STOP;
      }
    }
    else
    {
      Ctl.SysError.Code = E_IPD;
    }
  }
}

/**
  * @fn     void APP_FaultLed(void)
  * @brief  ����ָʾ����˸��ͬ������������ͬ���� OK
  * @retval None
  */
void APP_FaultLed(void)
{
  #if(LEDFAULTDIS_EN)
  u8 value;
  u16 temp1,temp2;

  if(Ui.Fb.LostSignalFlag != 0)       /*�Ѿ��ж���� FB�Ƿ��ECU*/
  {  
    if(Ctl.SysError.Code == E_8174)
    {  
      value = (u8)Ctl.SysError.Code; 
      temp1 = 1000;
      temp2 = 450;      
    }
    else
    {
      value = (u8)Ctl.SysError.Code;
      temp1 = 1000;
      temp2 = 239;
    }
    
    if(value != (u8)0)
    {
      if(Ui.FaultLedTimCunter > temp1)
      {
        if(Ui.FaultLedNumCunter <= ((value<<(u8)1) - (u8)1))
        {
          if(Ui.FaultLedTimCunter > (temp1 + (u16)temp2))
          {
            Ui.FaultLedTimCunter = temp1;
            Ui.FaultLedNumCunter++;

            FAULT_ONOFF;
          }
        }
        else
        {
          #if(0)
          FAULT_ONOFF;
          Ui.FaultLedTimCunter = 0;
          #else
          FAULT_OFF;
          if(Ui.FaultLedTimCunter>temp1+(u16)2000)
          {
            Ui.FaultLedTimCunter = 0;
            Ui.FaultLedNumCunter = 0;
          }
          #endif
        }
      }
    }
    else
    {
      Ui.FaultLedNumCunter = 0;
    }
  }
  #else
  
  /*
    20190320 
   ע�⣺FG�� MCL_Normal ����λ�������ͣ����ԭ����������ر�Ҳ����������
   ����Ƿ��ѹ���ϣ���������60��󣬱����ϡ�
   ��������1����������.
  */
  
//  if(Ctl.Vtim.FailureTimCounter >= 600) /*60�� ������*/
//  {
//    FG_ON;
//    Ctl.Vtim.FailureTimCounter = 600;
//  }
//  
//  if(Ctl.Vtim.NormalTimCounter >= (u16)1000) /*��������1����������*/
//  {
//    FG_OFF;
//  }
  #endif
}

/**
  * @fn     void APP_UserCmdSrefIn(void)
  * @brief  �û������������
  * @retval None
  */
void APP_UserCmdSrefIn(void)
{
  #if(SPEED_CLOSE_EN)
  Ctl.Spd.RefTar = Ctl.Spd.UiRefTar;
  
  APP_DeratingOut();/* ���ݵ�ѹ���¶ȵȽ������  ���ƴ˱��������ֵ  Ctl.Spd.UiRefMax*/

  if(Ctl.Spd.UiRefTar > Ctl.Spd.UiRefMax)
  {
    Ctl.Spd.UiRefTar = Ctl.Spd.UiRefMax;
  }
  
  if(Ctl.Spd.RefTar < SPEED_MIN_SEF_TEMP)
  {
    Ctl.Spd.RefTar = SPEED_MIN_SEF_TEMP;
  }
  else if(Ctl.Spd.RefTar > SPEED_MAX_SEF_TEMP)
  {
    Ctl.Spd.RefTar = SPEED_MAX_SEF_TEMP;
  }
  else
  {
    ;
  }
  #else
  Ctl.Spd.RefTar = gPwminCap.DutyAvg+IQ(0.05);
  //Ctl.Spd.RefTar = Ctl.Spd.UiRefTar;
  if(Ctl.Spd.RefCur < IQ(RAMP_DUTY))
  {
    Ctl.Spd.RefCur = IQ(RAMP_DUTY);
  }
  #endif    
}


/**
  * @fn     void APP_ONOFF_TEST(void)
  * @brief     20180907  ONOFF�Զ�ѭ������
  *            -> ͣ��20s -> 1600rpm 20s -> 2000rpm 20s -> 2600rpm 20s->2000rpm 20s-> 1600rpm 20s
  * ͣ10s~11s~12s~13s����40s~10s
  * @retval None
  */

u8 tValue;
void APP_ONOFF_TEST(void)
{ 
  if(tValue <(u8)25)
  {
    tValue = 25; 
  }
  else if(tValue > (u8)45)
  {
    tValue = 45;
  }  
  else
  {
  
  }
  tValue = 45;
  if(Ctl.Vtim.OnOffTimCounter < (u8)tValue*(u8)10)  /*30*10*/
  {
    Ctl.Spd.RefTar = 0;
    if(Ui.flg.START == (u8)TRUE)
    {  
      Ui.flg.START = (u8)FALSE;
//      tValue += 2;
//      if(tValue > (u8)40)
//      {
//        tValue = 10;
//      }  
    }

    if((Ctl.SysError.Code != NONE)&&(Ctl.SysError.Code < E_8174))
    {
      if((Ctl.SysError.Code == E_OV)||(Ctl.SysError.Code == E_UV))
      {
        if(Ctl.Vtim.Nonms == NONMS)
        {
          Ctl.SysError.Code = NONE;
          Ctl.State = MOTOR_STOP;
        }
      }
      else
      {
        Ctl.SysError.Code = NONE;
        Ctl.State = MOTOR_STOP;
      }
    }
  }
  else if(Ctl.Vtim.OnOffTimCounter < (u8)120*(u8)10) /*50*10*/
  {
    if(Ctl.Vtim.Nonms == NONMS)
    {
      if(Ui.flg.START == (u8)FALSE)
      {          
        Ui.flg.START = (u8)TRUE;
      }
    }
  }
  else
  {
    Ctl.Vtim.OnOffTimCounter = 0;
  }
}


/**
  * @fn     void APP_DeratingOut(void)
  * @brief  �������
  * @retval None
  */
void APP_DeratingOut(void) 
{
  /*�޷����*/
  /*���� 30�� ��20%*/  
  #if(1)
  if(Ctl.Spd.Vtim100ms > (u16)100)       /*10��*/   
  {
    Ctl.Spd.Vtim100ms = 0;
    if(Ctl.Fail.OHLevel <= (u8)0xF2)     /*130��*/
    {
      if(Ctl.Spd.UiRefMax > SPEED_MIN_SEF_TEMP)
      {
        Ctl.Spd.UiRefMax -=  IQ(0.2);
      }
    }
    else if(Ctl.Fail.OHLevel >= (u8)0xF3)/*120��*/
    {
      if( Ctl.Spd.UiRefMax < SPEED_MAX_SEF_TEMP)
      {
        Ctl.Spd.UiRefMax +=  IQ(0.1);
      }
    }
    else
    {
      ;
    }

    if(Ctl.Spd.UiRefMax < SPEED_MIN_SEF_TEMP)
    {
      Ctl.Spd.UiRefMax = SPEED_MIN_SEF_TEMP;
    }
  }
  #endif
  
  /*
  �����¶����������� 
  */
  #if(0)
  if(Ctl.Fail.OHLevel == 0xF1)   
  {
    Ctl.Spd.UiRefMax = IQ(800.0/BASE_SPEED);
  }
  else if(Ctl.Fail.OHLevel == 0xF2)
  {
    Ctl.Spd.UiRefMax = IQ(800.0/BASE_SPEED);
  }  
  else if(Ctl.Fail.OHLevel == 0xF3)
  {
    Ctl.Spd.UiRefMax = IQ(1500.0/BASE_SPEED);
  }
  else if(Ctl.Fail.OHLevel == 0xF4)
  {
    Ctl.Spd.UiRefMax = IQ(2000.0/BASE_SPEED);
  }
  else if(Ctl.Fail.OHLevel == 0xF5)
  {
    Ctl.Spd.UiRefMax = IQ(2400.0/BASE_SPEED);
  }
  else
  {
    Ctl.Spd.UiRefMax = IQ(2600.0/BASE_SPEED);
  }
  
  if(Ctl.Spd.UiRefMax < SPEED_MIN_SEF_TEMP)
  {
    Ctl.Spd.UiRefMax = SPEED_MIN_SEF_TEMP;
  }
  #endif

  /*��ѹ���٣��ٶȸ������*/
  #if(1)
  if(Ctl.Spd.SlowingDownFlag != (u8)0xFF)
  {
    if(Drv.AdcMeas.VdcAvgMeas > (u16)(MECAS_DC_DERATED*1.05))      /* > 10.05V*/
    {
      Ctl.Spd.Shift = (u8)3;
    }
    else if(Drv.AdcMeas.VdcAvgMeas > (u16)(MECAS_DC_DERATED*0.95)) /* 9.5V~10.0V */
    {
     ;
    }
    else if(Drv.AdcMeas.VdcAvgMeas > (u16)(MECAS_DC_DERATED*0.90)) /* 8.5V~9.5V */
    {
      Ctl.Spd.Shift = (u8)2;
    }
    else if(Drv.AdcMeas.VdcAvgMeas > (u16)(MECAS_DC_DERATED*0.85)) /* 8.5V~9.0V */
    {
      ;
    } 
    else
    {
      Ctl.Spd.Shift = (u8)1;
    }
  }

  
  if(Ctl.Spd.Shift == (u8)1)
  {
    Ctl.Spd.RefTar = Ctl.Spd.UiRefTar>>2;  
  }
  else if(Ctl.Spd.Shift == (u8)2)
  {
    Ctl.Spd.RefTar = Ctl.Spd.UiRefTar>>1;                        /*9.2V 10A  �з�������λ���� */  
  }
  else
  {
    Ctl.Spd.RefTar = Ctl.Spd.UiRefTar;
  } 
  #endif
}

  
/**
  * @fn     void APP_UserCmdSetOnoff(void)
  * @brief  
  * @retval None
  */
void APP_UserCmdSetOnoff(void)
{
  if(Ui.OnOffFilterCounter >= ONOFFFILTER_NUM)   /*���������ź�*/
  {
    Ui.OnOffFilterCounter = ONOFFFILTER_NUM;
    if(Ctl.Vtim.Nonms == NONMS)
    {
      if(Ui.flg.START != (u8)TRUE)
      {
        Ui.flg.START = (u8)TRUE;      
      }
    }
  }
  else if(Ui.OnOffFilterCounter <= -ONOFFFILTER_NUM)
  {
    Ui.OnOffFilterCounter = -ONOFFFILTER_NUM;
    if(Ui.flg.START != (u8)FALSE)
    {  
      Ui.flg.START = (u8)FALSE;
    }
  }
  else
  {

  }
}
/**
  * @fn     void APP_FGoutHandle(void)
  * @brief  �����ź�
  * @retval None
  */
void APP_FGoutHandle(void)
{
  if(Ctl.SysError.Code == NONE)
  {
    if(Ctl.gStepCur <= 6)
    {
      FG_OFF;
    }
    else
    {
      FG_ON;
    }
  }
  
  /*
  20190821
  1.���յ� Ui.KLPwmFeedbackFlag  == 0x71 ����󣬰� FB����1250ms��
  2.Ȼ��� Ui.KLPwmFeedbackFlag  = 0x73 
  3.PWM����5%ʱ����gF029_FB_Flag = 0x72

  JK-FABL039 ͣ��ʱ����������1800ms����ת��������6.2�� 
  JK-FABL038 <5% ����400ms����ת��������
  */
  
  #if(1) 
  if(Ui.KLPwmFeedbackFlag == 0x71)
  {  
    /*
    if(Ctl.Vtim.FB_1msCounter < 400)
    {
      FB_ON;
    }
    else if(Ctl.Vtim.FB_1msCounter < 400+500)
    {
      Ui.KLPwmFeedbackFlag = 0x73;
      FB_OFF;
    }
    else
    {
      Ctl.Vtim.FB_1msCounter = 0;
    }
    */
  }
  else if(Ui.KLPwmFeedbackFlag == 0x72)  /*<5% ����400ms*/
  {  
    if(Ctl.Vtim.FB_1msCounter < (u16)1800)
    {
      FB_ON;
    }
    else if(Ctl.Vtim.FB_1msCounter < (u16)(1800+1800))
    {
      FB_OFF;
    }
    else
    {
      Ctl.Vtim.FB_1msCounter = 0;
    }    
    /*
    if(Ctl.Vtim.FB_1msCounter < 400)
    {
      FB_ON;
    }
    else if(Ctl.Vtim.FB_1msCounter < 400+400)
    {
      Ui.KLPwmFeedbackFlag = 0x73;
      FB_OFF;
    }
    else
    {
      Ctl.Vtim.FB_1msCounter = 0;
    }
    */
  } 
  else
  {    
    if(Ctl.Fail.Sta1RestartNum == (u8)3)
    {
      if(Ctl.Vtim.FB_1msCounter < (u16)6200)
      {
        FB_ON;
      }
      else if(Ctl.Vtim.FB_1msCounter < (u16)(36200))
      {
        FB_OFF;
      }
      else
      {
        if(Ctl.Vtim.STRestartCounter < (u16)10000)
        {  
          Ctl.Vtim.FB_1msCounter = 0;
        }
        else
        {
          Ctl.Vtim.FB_1msCounter = (u16)(36200);
        }
      }
    }
    else
    {
      FB_OFF;
      Ctl.Vtim.FB_1msCounter = 0;
    }  
  }
  #endif
}
/**
  * @fn     void Drv_Handle(void)
  * @brief  �������������
  * @retval None
  */

void Drv_Handle(void)
{  
  if(Ctl.Nor.ComCounter > (u16)10000)
  {
    Ctl.Nor.ComCounter = 10000;
  }
  /*
  20190816
  ִ��7184˯�߳���
  */
  if(Ui.flg.START == (u8)FALSE)
  {
    if(Ctl.Vtim.Tle7184SleepTimCounter > (u16)600) /*60��*/
    {
      Ctl.Vtim.Tle7184SleepTimCounter = 0;
      disableInterrupts();
      TLE7184_RGS_OFF;
      gDelayus(50);            /*20us ~ 50us*/
      TLE7184_RGS_ON;          /* 7184���� ˯��ģʽ */
      enableInterrupts();    
    }
  }
  else
  {
    Ctl.Vtim.Tle7184SleepTimCounter = 0;
  }
      	
  if(Ctl.Bemf.E360CounterAvg < (u16)60)
  {
    Ctl.Bemf.E360CounterAvg = 60;
  }

  if(Ctl.Bemf.C3Step11ComNumCur > Ctl.Bemf.Angle_C3)
  {
    Ctl.Bemf.C3Step11ComNumCur = Ctl.Bemf.Angle_C3;
  }

  Ctl.Bemf.Angle_60 = Ctl.Bemf.E360CounterPre/(u8)6;
  Ctl.Bemf.Angle_30 = Ctl.Bemf.Angle_60>>1;
  Ctl.Bemf.Angle_15 = Ctl.Bemf.Angle_30>>1;
  Ctl.Bemf.Angle_7 = Ctl.Bemf.Angle_15>>1;
  Ctl.Bemf.Angle_22 = Ctl.Bemf.Angle_15 + Ctl.Bemf.Angle_7;

  /*bemf ���+ƫ�� 360/1024*5.0 = 1.757V������12V 0.83*/

  Drv.AdcMeas.VdcMeasHalf = (u16)(Drv.AdcMeas.VdcAvgMeas>>1);
  Drv.AdcMeas.VdcBemfOffsetTar = VDC_OFFSETT_SET;
  Drv.AdcMeas.VdcBemfOffsetCur = VDC_OFFSETT_SET;

  if(Drv.AdcMeas.VdcBemfOffsetCur > (Drv.AdcMeas.VdcMeasHalf - 50))
  {
    Drv.AdcMeas.VmeasFall = Drv.AdcMeas.VdcAvgMeas - (u16)(0.8/VDCMEASEGAIN);
    Drv.AdcMeas.VmeasRise = (u16)(0.2/VDCMEASEGAIN);
  }
  else
  {
    Drv.AdcMeas.VmeasRise = Drv.AdcMeas.VdcMeasHalf + Drv.AdcMeas.VdcBemfOffsetCur;
    Drv.AdcMeas.VmeasFall = Drv.AdcMeas.VdcMeasHalf - Drv.AdcMeas.VdcBemfOffsetCur;
  }

  if(Drv.AdcMeas.VmeasRise < (u16)(0.2/VDCMEASEGAIN))
  {
    Drv.AdcMeas.VmeasRise = (u16)(0.2/VDCMEASEGAIN);
  }

  /*
  20190719 �Զ���������������;����������������20%��
  */
  //if(Ctl.State == MOTOR_ALIGNMENGT)
  {
     Ctl.Ramp.ForceComDutyGain = MECAS_DCVOLTAGE/(float)Drv.AdcMeas.VdcAvgMeas; 
      
     if(Ctl.Fail.Sta1RestartNum >= 1)
     {
       Ctl.Ramp.ForceComDutyCur = (u16)(IQ(ALIGNMENTDUTY)*Ctl.Ramp.ForceComDutyGain); /**/
     }
     else
     {
        Ctl.Ramp.ForceComDutyCur = (u16)(IQ(ALIGNMENTDUTY)*Ctl.Ramp.ForceComDutyGain);
     }

     if(Ctl.Ramp.ForceComDutyCur > IQ(0.2))
     {
       Ctl.Ramp.ForceComDutyCur = IQ(0.2);
     }
     Ctl.Alig.duty1 =  Ctl.Ramp.ForceComDutyCur*5/10; /*��һ�ζ�λ*/
     Ctl.Alig.duty2 =  Ctl.Ramp.ForceComDutyCur;      /*�ڶ��ζ�λ*/
  }
//  else
//  {
//    Drv.PWM.DutyMin = (u16)(IQ(ALIGNMENTDUTY)*ftemp1);
//  }
}
